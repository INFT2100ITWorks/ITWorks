# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2014-02-13 19:12:17', '2014-02-13 19:12:17', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------


#
# Delete any existing table `wp_duplicator_packages`
#

DROP TABLE IF EXISTS `wp_duplicator_packages`;


#
# Table structure of table `wp_duplicator_packages`
#

CREATE TABLE `wp_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_duplicator_packages (0 records)
#

#
# End of data contents of table wp_duplicator_packages
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_filemeta`
#

DROP TABLE IF EXISTS `wp_filemeta`;


#
# Table structure of table `wp_filemeta`
#

CREATE TABLE `wp_filemeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `file_id` (`file_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_filemeta (7 records)
#
 
INSERT INTO `wp_filemeta` VALUES (3, 1, 'jobify-child-style.css', 'a:3:{s:4:"date";s:26:"February 28, 2014, 4:50 am";s:7:"message";s:13:"Thurs, Feb 27";s:7:"version";s:4214:"/*n Theme Name:   Jobify Childn Theme URI:    http://example.com/twenty-fourteen-child/n Description:  Capstone version of the JOBIFY Themen Author:       Ryan Mahoneyn Author URI:   http://example.comn Template:     jobifyn Version:      1.0.0n Tags:         light, dark, two-columns, right-sidebar, responsive-layout, accessibility-readyn Text Domain:  jobify-childn*/nn@import url(\\"../jobify/style.css\\");nn/* General */nnn/* =Theme customization starts here */n/*--------------------------HEADER----------------------------*/n.buffer-top {n	margin-top: 34px;n}n#metaslider_widget-2 .homepage-widget-title {n	display: none !important;n}nn.homepage-widget{n	margin: 50px !important;n}n.site-headern{n	background-color:#205291 !important;n	padding-bottom: 25px !important;n	padding-top: 35px !important;n}nn.sub-menun{n	background-color:#205291 !important;n}n.sub-menu li a:hovern{n	background-color:#5194e8 !important;n}nn/*--------------------------JOB-TYPE---------------------------*/nn/*--test---*/nnli.job-type.part-timen{n	background-color:#008DA8;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; nn}nli.job-type.internshipn{n	background-color:#51B948;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida 	Grande\\", sans-serif; nn}nli.job-type.freelancen{n	background-color:#FCB814;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif;n}nnli.job-type.full-timen{n	background-color:#EE2E22;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n}nnli.job-type.temporaryn{n	background-color:#7307FF;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n}nn/*------------------------HOMEPAGE-----------------------------*/nn.homepage-widget-title, .homepage-widget-description, .copyrightn{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n}nn.site-brandingn{n	padding-bottom:15px !important;n}nn/*----------------------------LINKS----------------------------*/nna, .load_more_jobs, .buttonn{n	color: white;n	border-style:none;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n}nna:hover, .load_more_jobs:hovern{n	color:#FF7300!important;n	border-color:#FF7300;n	text-decoration:none !important;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n	n}nn.load_more_jobs:hover, .button:hovern{n	border-style:solid !important;n	border-color:#FF7300 !important;n	background-color:#f2f2f2 !important;n}nn#submitcomment:hovern{n	color:#FF7300 !important;n	text-decoration:none !important;n	border-color:#FF7300 !important;n	background-color:#f2f2f2 !important;n}nn#submitcommentn{n	background-color:#0c2a50 !important;n}nn/*--------------------------HEADING----------------------------*/nn.page-headern{n	background-color: #grey!important;n}nn.page-titlen{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n	color: #0C2A50!important;n}nn/*---------------------------BODY-------------------------------*/nn.content-arean{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif !important; n	font-weight:bold !important;n	font-size:100%;n}nn/*--------------------------FOOTER------------------------------*/nn.footer-cta h2, .footer-cta pn{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif !important; n	font-weight:bold !important;n}nn.footer-ctan{n	background-color:#5194E8 !important;n}";}') ; 
INSERT INTO `wp_filemeta` VALUES (4, 1, 'jobify-child-style.css', 'a:3:{s:4:"date";s:26:"February 28, 2014, 2:58 pm";s:7:"message";s:12:"friday feb28";s:7:"version";s:4249:"/*n Theme Name:   Jobify Childn Theme URI:    http://example.com/twenty-fourteen-child/n Description:  Capstone version of the JOBIFY Themen Author:       Ryan Mahoneyn Author URI:   http://example.comn Template:     jobifyn Version:      1.0.0n Tags:         light, dark, two-columns, right-sidebar, responsive-layout, accessibility-readyn Text Domain:  jobify-childn*/nn@import url(\\"../jobify/style.css\\");nn/* General */nnn/* =Theme customization starts here */n/*--------------------------HEADER----------------------------*/n.buffer-top li{n	margin-top: 34px;n	padding-left:75%;n	width:100%;n}nn#metaslider_widget-2 .homepage-widget-title {n	display: none !important;n}nn.homepage-widget{n	margin: 50px !important;n}n.site-headern{n	background-color:#205291 !important;n	padding-bottom: 25px !important;n	padding-top: 35px !important;n}nn.sub-menun{n	background-color:#205291 !important;n}n.sub-menu li a:hovern{n	background-color:#5194e8 !important;n}nn/*--------------------------JOB-TYPE---------------------------*/nn/*--test---*/nnli.job-type.part-timen{n	background-color:#008DA8;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; nn}nli.job-type.internshipn{n	background-color:#51B948;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida 	Grande\\", sans-serif; nn}nli.job-type.freelancen{n	background-color:#FCB814;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif;n}nnli.job-type.full-timen{n	background-color:#EE2E22;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n}nnli.job-type.temporaryn{n	background-color:#7307FF;n	color:white;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n}nn/*------------------------HOMEPAGE-----------------------------*/nn.homepage-widget-title, .homepage-widget-description, .copyrightn{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n}nn.site-brandingn{n	padding-bottom:15px !important;n}nn/*----------------------------LINKS----------------------------*/nna, .load_more_jobs, .buttonn{n	color: white;n	border-style:none;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n}nna:hover, .load_more_jobs:hovern{n	color:#FF7300!important;n	border-color:#FF7300;n	text-decoration:none !important;n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n	n}nn.load_more_jobs:hover, .button:hovern{n	border-style:solid !important;n	border-color:#FF7300 !important;n	background-color:#f2f2f2 !important;n}nn#submitcomment:hovern{n	color:#FF7300 !important;n	text-decoration:none !important;n	border-color:#FF7300 !important;n	background-color:#f2f2f2 !important;n}nn#submitcommentn{n	background-color:#0c2a50 !important;n}nn/*--------------------------HEADING----------------------------*/nn.page-headern{n	background-color: #grey!important;n}nn.page-titlen{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif; n	font-weight:bold;n	color: #0C2A50!important;n}nn/*---------------------------BODY-------------------------------*/nn.content-arean{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif !important; n	font-weight:bold !important;n	font-size:100%;n}nn/*--------------------------FOOTER------------------------------*/nn.footer-cta h2, .footer-cta pn{n	font-family:\\"HelveticaNeue-Light\\", \\"Helvetica Neue Light\\", \\"Helvetica Neue\\", Helvetica, Arial, \\"Lucida Grande\\", sans-serif !important; n	font-weight:bold !important;n}nn.footer-ctan{n	background-color:#5194E8 !important;n}";}') ; 
INSERT INTO `wp_filemeta` VALUES (5, 1, 'jobify-job-application.php', 'a:3:{s:4:"date";s:23:"March 20, 2014, 2:44 am";s:7:"message";s:7:"working";s:7:"version";s:1174:"<?php if ( $apply = get_the_job_application_method() ) :n	?>n	<div class=\\"application\\">n		<input class=\\"application_button\\" type=\\"button\\" value=\\"<?php esc_attr_e( \\\'Apply\\\', \\\'jobify\\\' ); ?>\\" />nn		<div class=\\"application_details animated\\">n			<h2 class=\\"modal-title\\"><?php _e( \\\'Apply\\\', \\\'jobify\\\' ); ?></h2>nn			<div class=\\"application-content\\">n			<?phpn				switch ( $apply->type ) {n					case \\\'email\\\' :nn						if ( get_option( \\\'job_manager_gravity_form\\\' ) && function_exists( \\\'gravity_form\\\' ) ) :n							gravity_form( get_option( \\\'job_manager_gravity_form\\\' ), false, false, false, null, true );n						else :n							echo \\\'<p>\\\' . sprintf( __( \\\'To apply for this job <strong>email your details to</strong> <a class=\\"job_application_email\\" href=\\"mailto:%1$s%2$s\\">%1$s</a>\\\', \\\'jobify\\\' ), $apply->email, \\\'?subject=\\\' . rawurlencode( $apply->subject ) ) . \\\'</p>\\\';n						endif;nn					break;n					case \\\'url\\\' :n						echo \\\'<p>\\\' . sprintf( __( \\\'To apply for this job please visit the following URL: <a href=\\"%1$s\\">%1$s &rarr;</a>\\\', \\\'jobify\\\' ), $apply->url ) . \\\'</p>\\\';n					break;n				}n			?>n			</div>n		</div>n	</div>n<?php endif; ?>";}') ; 
INSERT INTO `wp_filemeta` VALUES (6, 1, 'jobify-content-single-job_listing.php', 'a:3:{s:4:"date";s:23:"March 20, 2014, 4:18 pm";s:7:"message";s:0:"";s:7:"version";s:5149:"<?phpn/**n * Job Contentn *n * @package Jobifyn * @since Jobify 1.0n */nnglobal $job_manager;n?>nn<div class=\\"single_job_listing\\">n	<?php if ( $post->post_status == \\\'expired\\\' ) : ?>nn		<div class=\\"job-manager-info\\"><?php _e( \\\'This job listing has expired\\\', \\\'jobify\\\' ); ?></div>nn	<?php else : ?>nn		<?php if ( is_position_filled() ) : ?>n			<div class=\\"job-manager-error\\"><?php _e( \\\'This position has been filled\\\', \\\'jobify\\\' ); ?></div>n		<?php endif; ?>nn		<div class=\\"job-overview-content\\">n			<div class=\\"job-overview<?php echo \\\'\\\' == jobify_get_the_company_description() ? \\\' no-company-desc\\\' : null; ?>\\">n				<h2 class=\\"job-overview-title\\"><?php _e( \\\'Overview\\\', \\\'jobify\\\' ); ?></h2>nn				<?php echo apply_filters( \\\'the_job_description\\\', get_the_content() ); ?>n			</div>nn			<?php if ( \\\'\\\' != jobify_get_the_company_description() ) : ?>n			<div class=\\"job-company-about\\">n				<h2 class=\\"job-overview-title\\" itemscope itemtype=\\"http://data-vocabulary.org/Organization\\"><?php printf( __( \\\'About %s\\\', \\\'jobify\\\' ), get_the_company_name() ); ?></h2>nn				<?php jobify_the_company_description(); ?>n			</div>n			<?php endif; ?>nn			<div class=\\"job-meta\\">n				<ul class=\\"meta\\">n					<li>n						<?phpn							if ( class_exists( \\\'Astoundify_Job_Manager_Companies\\\' ) && \\\'\\\' != get_the_company_name() ) :n								$companies   = Astoundify_Job_Manager_Companies::instance();n								$company_url = esc_url( $companies->company_url( get_the_company_name() ) );n						?>n						<a href=\\"<?php echo $company_url; ?>\\" target=\\"_blank\\"><?php the_company_logo(); ?></a>n						<?php else : ?>n							<?php the_company_logo(); ?>n						<?php endif; ?>n					</li>nn					<li class=\\"job-type <?php echo get_the_job_type() ? sanitize_title( get_the_job_type()->slug ) : \\\'\\\'; ?>\\"><?php the_job_type(); ?></li>nn					<?php if ( ! is_position_filled() && $post->post_status !== \\\'preview\\\' ) : ?><li><?php get_job_manager_template( \\\'job-application.php\\\' ); ?></li><?php endif; ?>nn					<li>n						<h4 class=\\"company-social-title\\"><?php _e( \\\'Company Details\\\', \\\'jobify\\\' ); ?></h4>nn						<?php do_action( \\\'job_listing_company_details_before\\\' ); ?>nn						<ul class=\\"company-social\\">n							<?php do_action( \\\'job_listing_company_social_before\\\' ); ?>nn							<?php if ( get_the_company_website() ) : ?>n							<li><a href=\\"<?php echo get_the_company_website(); ?>\\" target=\\"_blank\\" itemprop=\\"url\\">n								<i class=\\"icon-link\\"></i>n								<?php _e( \\\'Website\\\', \\\'jobify\\\' ); ?>n							</a></li>n							<?php endif; ?>nn							<?php if ( get_the_company_twitter() ) : ?>n							<li><a href=\\"http://twitter.com/<?php echo get_the_company_twitter(); ?>\\">n								<i class=\\"icon-twitter\\"></i>n								<?php _e( \\\'Twitter\\\', \\\'jobify\\\' ); ?>n							</a></li>n							<?php endif; ?>nn							<?php if ( jobify_get_the_company_facebook() ) : ?>n							<li><a href=\\"http://facebook.com/<?php echo jobify_get_the_company_facebook(); ?>\\">n								<i class=\\"icon-facebook\\"></i>n								<?php _e( \\\'Facebook\\\', \\\'jobify\\\' ); ?>n							</a></li>n							<?php endif; ?>nn							<?php if ( jobify_get_the_company_gplus() ) : ?>n							<li><a href=\\"http://plus.google.com/<?php echo jobify_get_the_company_gplus(); ?>\\">n								<i class=\\"icon-gplus\\"></i>n								<?php _e( \\\'Google+\\\', \\\'jobify\\\' ); ?>n							</a></li>n							<?php endif; ?>nn							<?php do_action( \\\'job_listing_company_social_after\\\' ); ?>n						</ul>nn						<?php if ( class_exists( \\\'Astoundify_Job_Manager_Companies\\\' ) || get_option( \\\'job_manager_enable_categories\\\' ) ) : ?>n						<ul class=\\"company-social\\">n							<?php if ( class_exists( \\\'Astoundify_Job_Manager_Companies\\\' ) && \\\'\\\' != get_the_company_name() ) : ?>n							<li>n								<a href=\\"<?php echo $company_url; ?>\\" title=\\"<?php printf( __( \\\'More jobs by %s\\\', \\\'jobify\\\' ), get_the_company_name() ); ?>\\"><i class=\\"icon-newspaper\\"></i> <?php _e( \\\'More Jobs\\\', \\\'jobify\\\' ); ?></a>n							</li>n							<?php endif; ?>nn							<?phpn								if ( get_option( \\\'job_manager_enable_categories\\\' ) ) :n									$categories = get_the_terms( $post->ID, \\\'job_listing_category\\\' );nn									if ( $categories ) :n										$category = current( $categories );n							?>nn							<?php if ( class_exists( \\\'WP_Job_Manager_Cat_Colors\\\' ) ) : ?>n								<li><a href=\\"<?php echo get_term_link( $category, \\\'job_listing_category\\\' ); ?>\\" class=\\"job-category <?php echo get_the_job_category() ? sanitize_title( get_the_job_category()->slug ) : \\\'\\\'; ?>\\"><?php the_job_category(); ?></a></li>n							<?php else : ?>n								<li><a href=\\"<?php echo get_term_link( $category, \\\'job_listing_category\\\' ); ?>\\"><i class=\\"icon-tag\\"></i> <?php echo $category->name; ?></a></li>n							<?php endif; ?>nn								<?php endif; ?>n							<?php endif; ?>n						</ul>n						<?php endif; ?>nn						<?php get_template_part( \\\'content-share\\\' ); ?>nn						<?php do_action( \\\'job_listing_company_details_after\\\' ); ?>n					</li>n				</ul>n			</div>n		</div>nn	<?php endif; ?>n</div>nn<script>n  n  jQuery(\\\'#apply-btn\\\').on(\\\'click\\\', function()n						  {n							n						  }n  n</script>";}') ; 
INSERT INTO `wp_filemeta` VALUES (7, 1, 'jobify-page-templates/map-jobs.php', 'a:3:{s:4:"date";s:22:"April 2, 2014, 3:56 pm";s:7:"message";s:0:"";s:7:"version";s:959:"<?phpn/**n * Template Name: Map + Jobsn *n * @package Jobifyn * @since Jobify 1.0n */nnget_header(); ?>nn	<div id=\\"primary\\" class=\\"content-area\\">n		<div id=\\"content\\" class=\\"homepage-content\\" role=\\"main\\">n			<?phpn				the_widget(n					\\\'Jobify_Widget_Map\\\',n					array(n						\\\'search\\\' => \\\'off\\\',n						\\\'zoom\\\'   => \\\'auto\\\',n						\\\'center\\\' => nulln					),n					array(n						\\\'before_widget\\\' => sprintf( \\\'<section id=\\"%1$s\\" class=\\"homepage-widget %2$s\\">\\\', \\\'jobify_widget_map\\\', \\\'jobify_widget_map\\\' ),n						\\\'after_widget\\\'  => \\\'</section>\\\',n						\\\'before_title\\\'  => \\\'<h3 class=\\"homepage-widget-title\\">\\\',n						\\\'after_title\\\'   => \\\'</h3>\\\',n						\\\'widget_id\\\' => \\\'jobify_widget_map-999\\\'n					)n				);n			?>nn			<div class=\\"site-content full\\">n				<div class=\\"entry-content\\">n					<?php echo do_shortcode( \\\'[jobs]\\\' ); ?>n				</div>n			</div>nn		</div><!-- #content -->n	</div><!-- #primary -->nn<?php get_footer(); ?>";}') ; 
INSERT INTO `wp_filemeta` VALUES (8, 1, 'jobify-job-application.php', 'a:3:{s:4:"date";s:23:"April 17, 2014, 3:56 pm";s:7:"message";s:5:"Final";s:7:"version";s:610:"<?php if ( $apply = get_the_job_application_method() ) :n	?>n	<div class=\\"application\\">n		<input class=\\"application_button\\" type=\\"button\\" value=\\"<?php esc_attr_e( \\\'Apply\\\', \\\'jobify\\\' ); ?>\\" />nn		<div class=\\"application_details animated\\">n			<h2 class=\\"modal-title\\"><?php _e( \\\'Apply\\\', \\\'jobify\\\' ); ?></h2>nn			<div class=\\"application-content\\">n			  <h3> Apply for this job:</h3>n			  <ul>n			    <li>Company:  <?php the_company_name(); ?> </li>n				<li>Email:  </li>n			  </ul>n			  <input type=\\"button\\" value=\\"Apply\\" id=\\"apply-button\\" />n			n			</div>n		</div>n	</div>n<?php endif; ?>";}') ; 
INSERT INTO `wp_filemeta` VALUES (9, 1, 'jobify-job-application.php', 'a:3:{s:4:"date";s:23:"April 17, 2014, 3:58 pm";s:7:"message";s:0:"";s:7:"version";s:0:"";}') ;
#
# End of data contents of table wp_filemeta
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------


#
# Delete any existing table `wp_maxbuttons_buttons`
#

DROP TABLE IF EXISTS `wp_maxbuttons_buttons`;


#
# Table structure of table `wp_maxbuttons_buttons`
#

CREATE TABLE `wp_maxbuttons_buttons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `text` varchar(100) DEFAULT NULL,
  `text_font_family` varchar(50) DEFAULT NULL,
  `text_font_size` varchar(10) DEFAULT NULL,
  `text_font_style` varchar(10) DEFAULT NULL,
  `text_font_weight` varchar(10) DEFAULT NULL,
  `text_color` varchar(10) DEFAULT NULL,
  `text_color_hover` varchar(10) DEFAULT NULL,
  `text_shadow_offset_left` varchar(10) DEFAULT NULL,
  `text_shadow_offset_top` varchar(10) DEFAULT NULL,
  `text_shadow_width` varchar(10) DEFAULT NULL,
  `text_shadow_color` varchar(10) DEFAULT NULL,
  `text_shadow_color_hover` varchar(10) DEFAULT NULL,
  `text_padding_top` varchar(10) DEFAULT NULL,
  `text_padding_bottom` varchar(10) DEFAULT NULL,
  `text_padding_left` varchar(10) DEFAULT NULL,
  `text_padding_right` varchar(10) DEFAULT NULL,
  `border_radius_top_left` varchar(10) DEFAULT NULL,
  `border_radius_top_right` varchar(10) DEFAULT NULL,
  `border_radius_bottom_left` varchar(10) DEFAULT NULL,
  `border_radius_bottom_right` varchar(10) DEFAULT NULL,
  `border_style` varchar(10) DEFAULT NULL,
  `border_width` varchar(10) DEFAULT NULL,
  `border_color` varchar(10) DEFAULT NULL,
  `border_color_hover` varchar(10) DEFAULT NULL,
  `box_shadow_offset_left` varchar(10) DEFAULT NULL,
  `box_shadow_offset_top` varchar(10) DEFAULT NULL,
  `box_shadow_width` varchar(10) DEFAULT NULL,
  `box_shadow_color` varchar(10) DEFAULT NULL,
  `box_shadow_color_hover` varchar(10) DEFAULT NULL,
  `gradient_start_color` varchar(10) DEFAULT NULL,
  `gradient_start_color_hover` varchar(10) DEFAULT NULL,
  `gradient_end_color` varchar(10) DEFAULT NULL,
  `gradient_end_color_hover` varchar(10) DEFAULT NULL,
  `gradient_stop` varchar(2) DEFAULT NULL,
  `gradient_start_opacity` varchar(3) DEFAULT NULL,
  `gradient_end_opacity` varchar(3) DEFAULT NULL,
  `gradient_start_opacity_hover` varchar(3) DEFAULT NULL,
  `gradient_end_opacity_hover` varchar(3) DEFAULT NULL,
  `new_window` varchar(10) DEFAULT NULL,
  `container_enabled` varchar(5) DEFAULT NULL,
  `container_width` varchar(5) DEFAULT NULL,
  `container_margin_top` varchar(5) DEFAULT NULL,
  `container_margin_right` varchar(5) DEFAULT NULL,
  `container_margin_bottom` varchar(5) DEFAULT NULL,
  `container_margin_left` varchar(5) DEFAULT NULL,
  `container_alignment` varchar(25) DEFAULT NULL,
  `container_center_div_wrap_enabled` varchar(5) DEFAULT NULL,
  `nofollow` varchar(5) DEFAULT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'publish',
  `external_css` varchar(5) DEFAULT NULL,
  `important_css` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_maxbuttons_buttons (3 records)
#
 
INSERT INTO `wp_maxbuttons_buttons` VALUES (1, 'Post A Job', '', 'http://capstone.jonny.me/post-a-job/', 'Post A Job', 'Arial', '16px', 'normal', 'bold', '#ffffff', '#000000', '-1px', '-1px', '0px', '#000000', '#ffffff', '15px', '15px', '25px', '25px', '4px', '4px', '4px', '4px', 'solid', '1px', '#ffffff', '#0f2557', '0px', '0px', '2px', '#ffffff', '#ffffff', '#00418c', '#ffffff', '#00418c', '#ffffff', '45', '100', '100', '100', '100', '', 'on', '', '', '0px', '', '500px', 'display: inline-block', '', '', 'publish', '', 'on') ; 
INSERT INTO `wp_maxbuttons_buttons` VALUES (2, 'Post A Job', '', 'http://capstone.jonny.me/post-a-job/', 'Post A Job', 'Arial', '16px', 'normal', 'bold', '#ffffff', '#fce93e', '-1px', '-1px', '0px', '#618926', '#12295d', '15px', '15px', '25px', '25px', '4px', '4px', '4px', '4px', 'solid', '1px', '#618926', '#0f2557', '0px', '0px', '2px', '#333333', '#333333', '#00418c', '#ffffff', '#00418c', '#ffffff', '45', '100', '100', '100', '100', '', 'on', '', '0px', '0px', '', '', 'display: inline-block', 'on', '', 'trash', NULL, NULL) ; 
INSERT INTO `wp_maxbuttons_buttons` VALUES (3, 'Post Résumé', '', 'http://capstone.jonny.me/post-a-job/', 'Post Résumé', 'Arial', '16px', 'normal', 'bold', '#ffffff', '#000000', '-1px', '-1px', '0px', '#000000', '#ffffff', '15px', '15px', '25px', '25px', '4px', '4px', '4px', '4px', 'solid', '1px', '#ffffff', '#0f2557', '0px', '0px', '2px', '#ffffff', '#ffffff', '#00418c', '#ffffff', '#00418c', '#ffffff', '45', '100', '100', '100', '100', '', 'on', '', '', '', '', '', 'display: inline-block', '', '', 'publish', '', 'on') ;
#
# End of data contents of table wp_maxbuttons_buttons
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------


#
# Delete any existing table `wp_nextend_smartslider_layouts`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_layouts`;


#
# Table structure of table `wp_nextend_smartslider_layouts`
#

CREATE TABLE `wp_nextend_smartslider_layouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `slide` longtext,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_nextend_smartslider_layouts (0 records)
#

#
# End of data contents of table wp_nextend_smartslider_layouts
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------


#
# Delete any existing table `wp_nextend_smartslider_sliders`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_sliders`;


#
# Table structure of table `wp_nextend_smartslider_sliders`
#

CREATE TABLE `wp_nextend_smartslider_sliders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `type` varchar(30) NOT NULL,
  `params` text NOT NULL,
  `generator` text NOT NULL,
  `slide` longtext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_nextend_smartslider_sliders (3 records)
#
 
INSERT INTO `wp_nextend_smartslider_sliders` VALUES (1, 'Example', 'simple', '{"size":"550|*|300|*|0","responsive":"1|*|0","globalfontsize":"12|*|16|*|20","margin":"0|*|0|*|0|*|0|*|px","simplebackgroundimage":"","simplebackgroundimagesize":"auto","simplepadding":"0|*|0|*|0|*|0","simpleborder":"0|*|3E3E3Eff","simpleborderradius":"0|*|0|*|0|*|0","simpleresponsivemaxwidth":"3000","improvedtouch":"0","simpleskins":"","simpleslidercss":"","simpleanimation":"horizontal","simpleanimationproperties":"1100|*|0|*|easeInOutCubic|*|1","simplebackgroundanimation":"0|*|bars","fadeonload":"1|*|0","playfirstlayer":"0","mainafterout":"0","inaftermain":"1","controls":"0|*|horizontal|*|0","blockrightclick":"0","randomize":"0","autoplay":"1|*|5000","autoplayfinish":"0|*|loop|*|current","stopautoplay":"1|*|1|*|1","resumeautoplay":"0|*|1|*|0","widgetarrow":"transition","widgetarrowdisplay":"1|*|always|*|1|*|0","previousposition":"left|*|0|*|%|*|top|*|45|*|%","previous":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/previous\\/square.png","nextposition":"right|*|0|*|%|*|top|*|45|*|%","next":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/next\\/square.png","arrowbackground":"00000033","arrowbackgroundhover":"00000070","widgetbullet":"transition","widgetbulletdisplay":"1|*|always|*|0|*|0","bulletposition":"left|*|0|*|%|*|bottom|*|1|*|%","bulletwidth":"100%","bulletorientation":"horizontal","bulletalign":"center","bullet":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetbullet\\/transition\\/transition\\/bullets\\/simple-mini.png","bulletbackground":"00000000","bulletbackgroundhover":"ffffffff","bulletborder":"00000078","bulletborderhover":"ffffffff","bulletshadow":"none","bulletbar":"none","bulletbarcolor":"00000040","bullethumbnail":"1|*|top","thumbnailsizebullet":"50|*|50","bulletthubmnail":"00000036","widgetautoplay":"image","widgetautoplaydisplay":"0|*|always|*|0|*|0","autoplayimageposition":"left|*|0|*|%|*|top|*|50|*|%","autoplayimage":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetautoplay\\/image\\/image\\/play\\/cream-button-minii.png","widgetindicator":"pie","widgetindicatordisplay":"0|*|always|*|0|*|0","indicatorposition":"right|*|5|*|%|*|top|*|5|*|%","indicatorskin":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetindicator\\/pie\\/pie\\/pie\\/default.png","indicatorcolor":"ffffffff|*|00000080","indicatorsize":"25","indicatorthickness":"0.5","indicatorlinecap":"butt","widgetbar":"colored","widgetbardisplay":"0|*|always|*|0|*|0","barcoloredposition":"left|*|0|*|%|*|top|*|0|*|%","barcolored":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetbar\\/colored\\/colored\\/colored\\/colored.png","barcoloredwidth":"200","barcoloredpadding":"1","barcoloredborderradius":"0|*|0|*|0|*|0","barcoloredtitlefont":"sliderfont5","barcoloreddescriptionfont":"sliderfont7","barbackground":"00000080","widgetthumbnail":"gallery","widgetthumbnaildisplay":"0|*|always|*|0|*|0","thumbnailgalleryposition":"left|*|0|*|%|*|bottom|*|0|*|px","thumbnailgalleryoutersize":"100%|*|auto","thumbnailgallerypadding":"5|*|5|*|5|*|5","thumbnailgalleryborderradius":"0|*|0|*|0|*|0","thumbnailgallerybackground":"EEEEEEFF","thumbnailgallerysize":"100|*|60","thumbnailgallerymargin":"0|*|1|*|1|*|0","thumbnail":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetthumbnail\\/gallery\\/gallery\\/thumbnails\\/aligncenter.png","widgetshadow":"shadow","widgetshadowdisplay":"0|*|always|*|0|*|0","shadowposition":"left|*|0|*|%|*|top|*|height|*|%","shadowwidth":"width","shadowcss":"","widgethtml":"html","widgethtmldisplay":"0|*|always|*|0|*|0","htmlposition":"left|*|0|*|px|*|top|*|0|*|px","widgethtmlcontent":"","widgets":"arrow"}', '', '') ; 
INSERT INTO `wp_nextend_smartslider_sliders` VALUES (2, 'Example', 'simple', '{"size":"550|*|300|*|0","responsive":"1|*|0","globalfontsize":"12|*|16|*|20","margin":"0|*|0|*|0|*|0|*|px","simplebackgroundimage":"","simplebackgroundimagesize":"auto","simplepadding":"0|*|0|*|0|*|0","simpleborder":"0|*|3E3E3Eff","simpleborderradius":"0|*|0|*|0|*|0","simpleresponsivemaxwidth":"3000","improvedtouch":"0","simpleskins":"","simpleslidercss":"","simpleanimation":"horizontal","simpleanimationproperties":"1100|*|0|*|easeInOutCubic|*|1","simplebackgroundanimation":"0|*|bars","fadeonload":"1|*|0","playfirstlayer":"0","mainafterout":"0","inaftermain":"1","controls":"0|*|horizontal|*|0","blockrightclick":"0","randomize":"0","autoplay":"1|*|5000","autoplayfinish":"0|*|loop|*|current","stopautoplay":"1|*|1|*|1","resumeautoplay":"0|*|1|*|0","widgetarrow":"transition","widgetarrowdisplay":"1|*|always|*|1|*|0","previousposition":"left|*|0|*|%|*|top|*|45|*|%","previous":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/previous\\/square.png","nextposition":"right|*|0|*|%|*|top|*|45|*|%","next":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/next\\/square.png","arrowbackground":"00000033","arrowbackgroundhover":"00000070","widgetbullet":"transition","widgetbulletdisplay":"1|*|always|*|0|*|0","bulletposition":"left|*|0|*|%|*|bottom|*|1|*|%","bulletwidth":"100%","bulletorientation":"horizontal","bulletalign":"center","bullet":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetbullet\\/transition\\/transition\\/bullets\\/simple-mini.png","bulletbackground":"00000000","bulletbackgroundhover":"ffffffff","bulletborder":"00000078","bulletborderhover":"ffffffff","bulletshadow":"none","bulletbar":"none","bulletbarcolor":"00000040","bullethumbnail":"1|*|top","thumbnailsizebullet":"50|*|50","bulletthubmnail":"00000036","widgetautoplay":"image","widgetautoplaydisplay":"0|*|always|*|0|*|0","autoplayimageposition":"left|*|0|*|%|*|top|*|50|*|%","autoplayimage":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetautoplay\\/image\\/image\\/play\\/cream-button-minii.png","widgetindicator":"pie","widgetindicatordisplay":"0|*|always|*|0|*|0","indicatorposition":"right|*|5|*|%|*|top|*|5|*|%","indicatorskin":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetindicator\\/pie\\/pie\\/pie\\/default.png","indicatorcolor":"ffffffff|*|00000080","indicatorsize":"25","indicatorthickness":"0.5","indicatorlinecap":"butt","widgetbar":"colored","widgetbardisplay":"0|*|always|*|0|*|0","barcoloredposition":"left|*|0|*|%|*|top|*|0|*|%","barcolored":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetbar\\/colored\\/colored\\/colored\\/colored.png","barcoloredwidth":"200","barcoloredpadding":"1","barcoloredborderradius":"0|*|0|*|0|*|0","barcoloredtitlefont":"sliderfont5","barcoloreddescriptionfont":"sliderfont7","barbackground":"00000080","widgetthumbnail":"gallery","widgetthumbnaildisplay":"0|*|always|*|0|*|0","thumbnailgalleryposition":"left|*|0|*|%|*|bottom|*|0|*|px","thumbnailgalleryoutersize":"100%|*|auto","thumbnailgallerypadding":"5|*|5|*|5|*|5","thumbnailgalleryborderradius":"0|*|0|*|0|*|0","thumbnailgallerybackground":"EEEEEEFF","thumbnailgallerysize":"100|*|60","thumbnailgallerymargin":"0|*|1|*|1|*|0","thumbnail":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetthumbnail\\/gallery\\/gallery\\/thumbnails\\/aligncenter.png","widgetshadow":"shadow","widgetshadowdisplay":"0|*|always|*|0|*|0","shadowposition":"left|*|0|*|%|*|top|*|height|*|%","shadowwidth":"width","shadowcss":"","widgethtml":"html","widgethtmldisplay":"0|*|always|*|0|*|0","htmlposition":"left|*|0|*|px|*|top|*|0|*|px","widgethtmlcontent":"","widgets":"arrow"}', '', '') ; 
INSERT INTO `wp_nextend_smartslider_sliders` VALUES (3, 'Example', 'simple', '{"size":"550|*|300|*|0","responsive":"1|*|0","globalfontsize":"12|*|16|*|20","margin":"0|*|0|*|0|*|0|*|px","simplebackgroundimage":"","simplebackgroundimagesize":"auto","simplepadding":"0|*|0|*|0|*|0","simpleborder":"0|*|3E3E3Eff","simpleborderradius":"0|*|0|*|0|*|0","simpleresponsivemaxwidth":"3000","improvedtouch":"0","simpleskins":"","simpleslidercss":"","simpleanimation":"horizontal","simpleanimationproperties":"1100|*|0|*|easeInOutCubic|*|1","simplebackgroundanimation":"0|*|bars","fadeonload":"1|*|0","playfirstlayer":"0","mainafterout":"0","inaftermain":"1","controls":"0|*|horizontal|*|0","blockrightclick":"0","randomize":"0","autoplay":"1|*|5000","autoplayfinish":"0|*|loop|*|current","stopautoplay":"1|*|1|*|1","resumeautoplay":"0|*|1|*|0","widgetarrow":"transition","widgetarrowdisplay":"1|*|always|*|1|*|0","previousposition":"left|*|0|*|%|*|top|*|45|*|%","previous":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/previous\\/square.png","nextposition":"right|*|0|*|%|*|top|*|45|*|%","next":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetarrow\\/transition\\/transition\\/next\\/square.png","arrowbackground":"00000033","arrowbackgroundhover":"00000070","widgetbullet":"transition","widgetbulletdisplay":"1|*|always|*|0|*|0","bulletposition":"left|*|0|*|%|*|bottom|*|1|*|%","bulletwidth":"100%","bulletorientation":"horizontal","bulletalign":"center","bullet":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetbullet\\/transition\\/transition\\/bullets\\/simple-mini.png","bulletbackground":"00000000","bulletbackgroundhover":"ffffffff","bulletborder":"00000078","bulletborderhover":"ffffffff","bulletshadow":"none","bulletbar":"none","bulletbarcolor":"00000040","bullethumbnail":"1|*|top","thumbnailsizebullet":"50|*|50","bulletthubmnail":"00000036","widgetautoplay":"image","widgetautoplaydisplay":"0|*|always|*|0|*|0","autoplayimageposition":"left|*|0|*|%|*|top|*|50|*|%","autoplayimage":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetautoplay\\/image\\/image\\/play\\/cream-button-minii.png","widgetindicator":"pie","widgetindicatordisplay":"0|*|always|*|0|*|0","indicatorposition":"right|*|5|*|%|*|top|*|5|*|%","indicatorskin":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetindicator\\/pie\\/pie\\/pie\\/default.png","indicatorcolor":"ffffffff|*|00000080","indicatorsize":"25","indicatorthickness":"0.5","indicatorlinecap":"butt","widgetbar":"colored","widgetbardisplay":"0|*|always|*|0|*|0","barcoloredposition":"left|*|0|*|%|*|top|*|0|*|%","barcolored":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetbar\\/colored\\/colored\\/colored\\/colored.png","barcoloredwidth":"200","barcoloredpadding":"1","barcoloredborderradius":"0|*|0|*|0|*|0","barcoloredtitlefont":"sliderfont5","barcoloreddescriptionfont":"sliderfont7","barbackground":"00000080","widgetthumbnail":"gallery","widgetthumbnaildisplay":"0|*|always|*|0|*|0","thumbnailgalleryposition":"left|*|0|*|%|*|bottom|*|0|*|px","thumbnailgalleryoutersize":"100%|*|auto","thumbnailgallerypadding":"5|*|5|*|5|*|5","thumbnailgalleryborderradius":"0|*|0|*|0|*|0","thumbnailgallerybackground":"EEEEEEFF","thumbnailgallerysize":"100|*|60","thumbnailgallerymargin":"0|*|1|*|1|*|0","thumbnail":"\\/plugins\\/nextend-smart-slider2-full\\/plugins\\/nextendsliderwidgetthumbnail\\/gallery\\/gallery\\/thumbnails\\/aligncenter.png","widgetshadow":"shadow","widgetshadowdisplay":"0|*|always|*|0|*|0","shadowposition":"left|*|0|*|%|*|top|*|height|*|%","shadowwidth":"width","shadowcss":"","widgethtml":"html","widgethtmldisplay":"0|*|always|*|0|*|0","htmlposition":"left|*|0|*|px|*|top|*|0|*|px","widgethtmlcontent":"","widgets":"arrow"}', '', '') ;
#
# End of data contents of table wp_nextend_smartslider_sliders
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------


#
# Delete any existing table `wp_nextend_smartslider_slides`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_slides`;


#
# Table structure of table `wp_nextend_smartslider_slides`
#

CREATE TABLE `wp_nextend_smartslider_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext,
  `description` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `background` varchar(300) NOT NULL,
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_nextend_smartslider_slides (9 records)
#
 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (1, 'Slide 1', 1, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;First Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  First Slide
                </h1></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t1.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg1.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"1\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"1\\",\\"slider\\":100022}","ordering":"1","slider":1}', 1, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (2, 'Slide 2', 1, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 42.182%; height: 15.334%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;Second Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  Second Slide
                </h1></div></div>                    <div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer #2" class="smart-slider-layer" style="top: 52.667%; left: 12.364%; width: 17.455%; height: 16%; position: absolute; z-index: 2; display: block;" data-animation="slide"><div style="" class="smart-slider-items" data-item="button" data-itemvalues="{&quot;content&quot;:&quot;Read more&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;skins&quot;:&quot;0&quot;,&quot;buttonclass&quot;:&quot;black-opacity-button&quot;,&quot;css&quot;:&quot;padding: 5% 0;\\nbackground: #000000;\\ntext-transform: uppercase;\\nbackground: rgba(0, 0, 0, 0.2);\\n-webkit-transition: all 0.2s ease-in-out 0s;\\n-moz-transition: all 0.2s ease-in-out 0s;\\n-ms-transition: all 0.2s ease-in-out 0s;\\n-o-transition: all 0.2s ease-in-out 0s;\\ntransition: all 0.2s ease-in-out 0s;\\n&quot;,&quot;csshover&quot;:&quot;background: #000000;background: rgba(0, 0, 0, 0.3);\\n              &quot;,&quot;fontclass&quot;:&quot;sliderfontcustom6&quot;,&quot;class&quot;:&quot;&quot;}"><div class="nextend-smartslider-button-black-opacity-button-container sliderfontcustom6" style="cursor:pointer; width: 100%;">
    <a href="#" onclick="if(this.getAttribute(\'href\') == \'#\') return false;" target="_self" style="display: block;" class="nextend-smartslider-button-black-opacity-button ">
      Read more
    </a>
</div>
<style type="text/css">
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button{
        padding: 5% 0;
background: #000000;
text-transform: uppercase;
background: rgba(0, 0, 0, 0.2);
-webkit-transition: all 0.2s ease-in-out 0s;
-moz-transition: all 0.2s ease-in-out 0s;
-ms-transition: all 0.2s ease-in-out 0s;
-o-transition: all 0.2s ease-in-out 0s;
transition: all 0.2s ease-in-out 0s;

    }
    
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:HOVER,
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:FOCUS,
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:ACTIVE{
        background: #000000;background: rgba(0, 0, 0, 0.3);
              
    }
</style></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t2.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg2.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"2\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"2\\",\\"slider\\":100022}","ordering":"2","slider":1}', 2, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (3, 'Slide 3', 1, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;Third Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  Third Slide
                </h1></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t3.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg3.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"3\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"3\\",\\"slider\\":100022}","ordering":"3","slider":1}', 3, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (4, 'Slide 1', 2, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;First Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  First Slide
                </h1></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t1.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg1.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"1\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"1\\",\\"slider\\":100022}","ordering":"1","slider":2}', 1, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (5, 'Slide 2', 2, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 42.182%; height: 15.334%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;Second Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  Second Slide
                </h1></div></div>                    <div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer #2" class="smart-slider-layer" style="top: 52.667%; left: 12.364%; width: 17.455%; height: 16%; position: absolute; z-index: 2; display: block;" data-animation="slide"><div style="" class="smart-slider-items" data-item="button" data-itemvalues="{&quot;content&quot;:&quot;Read more&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;skins&quot;:&quot;0&quot;,&quot;buttonclass&quot;:&quot;black-opacity-button&quot;,&quot;css&quot;:&quot;padding: 5% 0;\\nbackground: #000000;\\ntext-transform: uppercase;\\nbackground: rgba(0, 0, 0, 0.2);\\n-webkit-transition: all 0.2s ease-in-out 0s;\\n-moz-transition: all 0.2s ease-in-out 0s;\\n-ms-transition: all 0.2s ease-in-out 0s;\\n-o-transition: all 0.2s ease-in-out 0s;\\ntransition: all 0.2s ease-in-out 0s;\\n&quot;,&quot;csshover&quot;:&quot;background: #000000;background: rgba(0, 0, 0, 0.3);\\n              &quot;,&quot;fontclass&quot;:&quot;sliderfontcustom6&quot;,&quot;class&quot;:&quot;&quot;}"><div class="nextend-smartslider-button-black-opacity-button-container sliderfontcustom6" style="cursor:pointer; width: 100%;">
    <a href="#" onclick="if(this.getAttribute(\'href\') == \'#\') return false;" target="_self" style="display: block;" class="nextend-smartslider-button-black-opacity-button ">
      Read more
    </a>
</div>
<style type="text/css">
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button{
        padding: 5% 0;
background: #000000;
text-transform: uppercase;
background: rgba(0, 0, 0, 0.2);
-webkit-transition: all 0.2s ease-in-out 0s;
-moz-transition: all 0.2s ease-in-out 0s;
-ms-transition: all 0.2s ease-in-out 0s;
-o-transition: all 0.2s ease-in-out 0s;
transition: all 0.2s ease-in-out 0s;

    }
    
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:HOVER,
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:FOCUS,
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:ACTIVE{
        background: #000000;background: rgba(0, 0, 0, 0.3);
              
    }
</style></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t2.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg2.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"2\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"2\\",\\"slider\\":100022}","ordering":"2","slider":2}', 2, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (6, 'Slide 3', 2, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;Third Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  Third Slide
                </h1></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t3.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg3.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"3\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"3\\",\\"slider\\":100022}","ordering":"3","slider":2}', 3, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (7, 'Slide 1', 3, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;First Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  First Slide
                </h1></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t1.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg1.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"1\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"1\\",\\"slider\\":100022}","ordering":"1","slider":3}', 1, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (8, 'Slide 2', 3, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 42.182%; height: 15.334%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;Second Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  Second Slide
                </h1></div></div>                    <div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer #2" class="smart-slider-layer" style="top: 52.667%; left: 12.364%; width: 17.455%; height: 16%; position: absolute; z-index: 2; display: block;" data-animation="slide"><div style="" class="smart-slider-items" data-item="button" data-itemvalues="{&quot;content&quot;:&quot;Read more&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;skins&quot;:&quot;0&quot;,&quot;buttonclass&quot;:&quot;black-opacity-button&quot;,&quot;css&quot;:&quot;padding: 5% 0;\\nbackground: #000000;\\ntext-transform: uppercase;\\nbackground: rgba(0, 0, 0, 0.2);\\n-webkit-transition: all 0.2s ease-in-out 0s;\\n-moz-transition: all 0.2s ease-in-out 0s;\\n-ms-transition: all 0.2s ease-in-out 0s;\\n-o-transition: all 0.2s ease-in-out 0s;\\ntransition: all 0.2s ease-in-out 0s;\\n&quot;,&quot;csshover&quot;:&quot;background: #000000;background: rgba(0, 0, 0, 0.3);\\n              &quot;,&quot;fontclass&quot;:&quot;sliderfontcustom6&quot;,&quot;class&quot;:&quot;&quot;}"><div class="nextend-smartslider-button-black-opacity-button-container sliderfontcustom6" style="cursor:pointer; width: 100%;">
    <a href="#" onclick="if(this.getAttribute(\'href\') == \'#\') return false;" target="_self" style="display: block;" class="nextend-smartslider-button-black-opacity-button ">
      Read more
    </a>
</div>
<style type="text/css">
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button{
        padding: 5% 0;
background: #000000;
text-transform: uppercase;
background: rgba(0, 0, 0, 0.2);
-webkit-transition: all 0.2s ease-in-out 0s;
-moz-transition: all 0.2s ease-in-out 0s;
-ms-transition: all 0.2s ease-in-out 0s;
-o-transition: all 0.2s ease-in-out 0s;
transition: all 0.2s ease-in-out 0s;

    }
    
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:HOVER,
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:FOCUS,
    div#nextend-smart-slider-0 div.nextend-smartslider-button-black-opacity-button-container a.nextend-smartslider-button-black-opacity-button:ACTIVE{
        background: #000000;background: rgba(0, 0, 0, 0.3);
              
    }
</style></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t2.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg2.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"2\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"2\\",\\"slider\\":100022}","ordering":"2","slider":3}', 2, 0) ; 
INSERT INTO `wp_nextend_smartslider_slides` VALUES (9, 'Slide 3', 3, '2014-02-09 12:12:46', '2024-02-10 12:12:46', 1, 0, '<div data-parallaxout="0.45" data-delayout="0" data-easingout="linear" data-durationout="500" data-animationout="0" data-playoutafter="0" data-parallaxin="0.45" data-delayin="0" data-easingin="linear" data-durationin="500" data-animationin="0" data-name="Layer for heading" class="smart-slider-layer" style="top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);" data-animation="slide"><div style="" class="smart-slider-items" data-item="heading" data-itemvalues="{&quot;priority&quot;:&quot;1&quot;,&quot;heading&quot;:&quot;Third Slide&quot;,&quot;link&quot;:&quot;#|*|_self&quot;,&quot;url&quot;:&quot;#&quot;,&quot;target&quot;:&quot;_self&quot;,&quot;fontclass&quot;:&quot;sliderfontcustom5&quot;,&quot;fontsize&quot;:&quot;auto&quot;,&quot;fontsizer&quot;:&quot;&quot;,&quot;fontcolor&quot;:&quot;0|*|000000&quot;,&quot;fontcolorr&quot;:&quot;&quot;,&quot;skins&quot;:&quot;&quot;,&quot;css&quot;:&quot;padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;&quot;,&quot;class&quot;:&quot;&quot;}"><h1 class="sliderfontcustom5 " style="padding: 0;
                      margin: 0;
                      background: none;
                      box-shadow: none;">
                  Third Slide
                </h1></div></div>', '', 'http://www.nextendweb.com/demo/smartslider2/images/FREE/t3.png', 'ffffff00|*|http://www.nextendweb.com/demo/smartslider2/images/FREE/bg3.png', '{"params":"{\\"params\\":\\"{\\\\\\"publish_up\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"publish_down\\\\\\":\\\\\\"0000-00-00 00:00:00\\\\\\",\\\\\\"params\\\\\\":\\\\\\"{\\\\\\\\\\\\\\"link\\\\\\\\\\\\\\":\\\\\\\\\\\\\\"\\\\\\\\\\\\\\"}\\\\\\",\\\\\\"ordering\\\\\\":\\\\\\"3\\\\\\",\\\\\\"slider\\\\\\":15}\\",\\"ordering\\":\\"3\\",\\"slider\\":100022}","ordering":"3","slider":3}', 3, 0) ;
#
# End of data contents of table wp_nextend_smartslider_slides
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------


#
# Delete any existing table `wp_nextend_smartslider_storage`
#

DROP TABLE IF EXISTS `wp_nextend_smartslider_storage`;


#
# Table structure of table `wp_nextend_smartslider_storage`
#

CREATE TABLE `wp_nextend_smartslider_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(200) NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_nextend_smartslider_storage (11 records)
#
 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (1, 'layout', '{"size":"2048|*|1536"}') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (2, 'settings', '{"debugmessages":"1","slideeditoralert":"1","translateurl":"|*|","jquery":"1","placeholder":"http:\\/\\/www.nextendweb.com\\/static\\/placeholder.png","tidy-input-encoding":"utf8","tidy-output-encoding":"utf8"}') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (3, 'font', '{"sliderfont1customlabel":"Heading light","sliderfont1":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"320||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":1,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"},\\"Link:Hover\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"}}","sliderfont2customlabel":"Heading dark","sliderfont2":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"320||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":1,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont3customlabel":"Subheading light","sliderfont3":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"170||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont4customlabel":"Subheading dark","sliderfont4":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"170||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont5customlabel":"Paragraph light","sliderfont5":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"114||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.4\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"justify\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont6customlabel":"Paragraph dark","sliderfont6":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"114||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.4\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"justify\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont7customlabel":"Small text light","sliderfont7":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"90||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont8customlabel":"Small text dark","sliderfont8":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"90||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.1\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont9customlabel":"Handwritten light","sliderfont9":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"140||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Pacifico);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont10customlabel":"Handwritten dark","sliderfont10":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"140||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Pacifico);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont11customlabel":"Button light","sliderfont11":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"100||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfont12customlabel":"Button dark","sliderfont12":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"000000db\\",\\"size\\":\\"100||%\\",\\"tshadow\\":\\"0|*|1|*|0|*|ffffff33\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"},\\"Link:Hover\\":{\\"paddingleft\\":0,\\"size\\":\\"100||%\\"}}","sliderfontcustom1customlabel":"My first custom font","sliderfontcustom1":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"1abc9cff\\",\\"size\\":\\"360||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Pacifico);),Arial\\",\\"lineheight\\":\\"1.3\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"left\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfontcustom2customlabel":"My second custom font","sliderfontcustom2":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"ffffffff\\",\\"size\\":\\"140||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfontcustom3customlabel":"My third custom font","sliderfontcustom3":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"1abc9cff\\",\\"size\\":\\"120||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"center\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}","sliderfontcustom4customlabel":"My fourthcustom font ","sliderfontcustom4":"{\\"firsttab\\":\\"Text\\",\\"Text\\":{\\"color\\":\\"1abc9cff\\",\\"size\\":\\"120||%\\",\\"tshadow\\":\\"0|*|1|*|1|*|000000c7\\",\\"afont\\":\\"google(@import url(http:\\/\\/fonts.googleapis.com\\/css?family=Open Sans);),Arial\\",\\"lineheight\\":\\"1.2\\",\\"bold\\":0,\\"italic\\":0,\\"underline\\":0,\\"align\\":\\"right\\",\\"paddingleft\\":0},\\"Link\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0},\\"Link:Hover\\":{\\"size\\":\\"100||%\\",\\"paddingleft\\":0}}"}') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (4, 'sliderchanged1', '0') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (5, 'font1', '{"sliderfont1customlabel":"Heading light","sliderfont1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0=","sliderfont2customlabel":"Heading dark","sliderfont2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont3customlabel":"Subheading light","sliderfont3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont4customlabel":"Subheading dark","sliderfont4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont5customlabel":"Paragraph light","sliderfont5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont6customlabel":"Paragraph dark","sliderfont6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont7customlabel":"Small text light","sliderfont7":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwxfCp8MDAwMDAwYzciLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont8customlabel":"Small text dark","sliderfont8":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwwfCp8ZmZmZmZmMzMiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont9customlabel":"Handwritten light","sliderfont9":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont10customlabel":"Handwritten dark","sliderfont10":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont11customlabel":"Button light","sliderfont11":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont12customlabel":"Button dark","sliderfont12":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom1customlabel":"My first custom font","sliderfontcustom1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMzYwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom2customlabel":"My second custom font","sliderfontcustom2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom3customlabel":"My third custom font","sliderfontcustom3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom4customlabel":"My fourthcustom font ","sliderfontcustom4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJyaWdodCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom5customlabel":"Example heading","sliderfontcustom5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzAwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9Um9ib3RvKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMyIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom6customlabel":"Example small","sliderfontcustom6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDB8KnwwfCp8ZmZmZmZmMDAiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Sb2JvdG8pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0="}') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (6, 'sliderchanged2', '0') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (7, 'font2', '{"sliderfont1customlabel":"Heading light","sliderfont1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0=","sliderfont2customlabel":"Heading dark","sliderfont2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont3customlabel":"Subheading light","sliderfont3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont4customlabel":"Subheading dark","sliderfont4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont5customlabel":"Paragraph light","sliderfont5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont6customlabel":"Paragraph dark","sliderfont6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont7customlabel":"Small text light","sliderfont7":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwxfCp8MDAwMDAwYzciLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont8customlabel":"Small text dark","sliderfont8":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwwfCp8ZmZmZmZmMzMiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont9customlabel":"Handwritten light","sliderfont9":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont10customlabel":"Handwritten dark","sliderfont10":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont11customlabel":"Button light","sliderfont11":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont12customlabel":"Button dark","sliderfont12":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom1customlabel":"My first custom font","sliderfontcustom1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMzYwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom2customlabel":"My second custom font","sliderfontcustom2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom3customlabel":"My third custom font","sliderfontcustom3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom4customlabel":"My fourthcustom font ","sliderfontcustom4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJyaWdodCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom5customlabel":"Example heading","sliderfontcustom5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzAwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9Um9ib3RvKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMyIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom6customlabel":"Example small","sliderfontcustom6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDB8KnwwfCp8ZmZmZmZmMDAiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Sb2JvdG8pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0="}') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (8, 'sliderchanged3', '1') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (9, 'font3', '{"sliderfont1customlabel":"Heading light","sliderfont1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0=","sliderfont2customlabel":"Heading dark","sliderfont2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMzIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjoxLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont3customlabel":"Subheading light","sliderfont3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont4customlabel":"Subheading dark","sliderfont4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTcwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJsZWZ0IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont5customlabel":"Paragraph light","sliderfont5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont6customlabel":"Paragraph dark","sliderfont6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTE0fHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjQiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJqdXN0aWZ5IiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbms6SG92ZXIiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfX0=","sliderfont7customlabel":"Small text light","sliderfont7":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwxfCp8MDAwMDAwYzciLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMiIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont8customlabel":"Small text dark","sliderfont8":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDF8KnwwfCp8ZmZmZmZmMzMiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Nb250c2VycmF0KTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMSIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont9customlabel":"Handwritten light","sliderfont9":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont10customlabel":"Handwritten dark","sliderfont10":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfont11customlabel":"Button light","sliderfont11":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfont12customlabel":"Button dark","sliderfont12":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMDAwMDAwZGIiLCJzaXplIjoiMTAwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MHwqfGZmZmZmZjMzIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjMiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom1customlabel":"My first custom font","sliderfontcustom1":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMzYwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9UGFjaWZpY28pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoibGVmdCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom2customlabel":"My second custom font","sliderfontcustom2":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMTQwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom3customlabel":"My third custom font","sliderfontcustom3":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJjZW50ZXIiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsic2l6ZSI6IjEwMHx8JSIsInBhZGRpbmdsZWZ0IjowfSwiTGluazpIb3ZlciI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9fQ==","sliderfontcustom4customlabel":"My fourthcustom font ","sliderfontcustom4":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiMWFiYzljZmYiLCJzaXplIjoiMTIwfHwlIiwidHNoYWRvdyI6IjB8KnwxfCp8MXwqfDAwMDAwMGM3IiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9TW9udHNlcnJhdCk7KSxBcmlhbCIsImxpbmVoZWlnaHQiOiIxLjIiLCJib2xkIjowLCJpdGFsaWMiOjAsInVuZGVybGluZSI6MCwiYWxpZ24iOiJyaWdodCIsInBhZGRpbmdsZWZ0IjowfSwiTGluayI6eyJzaXplIjoiMTAwfHwlIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rOkhvdmVyIjp7InNpemUiOiIxMDB8fCUiLCJwYWRkaW5nbGVmdCI6MH19","sliderfontcustom5customlabel":"Example heading","sliderfontcustom5":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiMzAwfHwlIiwidHNoYWRvdyI6IjB8KnwwfCp8MHwqfGZmZmZmZjAwIiwiYWZvbnQiOiJnb29nbGUoQGltcG9ydCB1cmwoaHR0cDovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2Nzcz9mYW1pbHk9Um9ib3RvKTspLEFyaWFsIiwibGluZWhlaWdodCI6IjEuMyIsImJvbGQiOjAsIml0YWxpYyI6MCwidW5kZXJsaW5lIjowLCJhbGlnbiI6ImxlZnQiLCJwYWRkaW5nbGVmdCI6MH0sIkxpbmsiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifSwiTGluazpIb3ZlciI6eyJwYWRkaW5nbGVmdCI6MCwic2l6ZSI6IjEwMHx8JSJ9fQ==","sliderfontcustom6customlabel":"Example small","sliderfontcustom6":"eyJmaXJzdHRhYiI6IlRleHQiLCJUZXh0Ijp7ImNvbG9yIjoiZmZmZmZmZmYiLCJzaXplIjoiOTB8fCUiLCJ0c2hhZG93IjoiMHwqfDB8KnwwfCp8ZmZmZmZmMDAiLCJhZm9udCI6Imdvb2dsZShAaW1wb3J0IHVybChodHRwOi8vZm9udHMuZ29vZ2xlYXBpcy5jb20vY3NzP2ZhbWlseT1Sb2JvdG8pOyksQXJpYWwiLCJsaW5laGVpZ2h0IjoiMS4zIiwiYm9sZCI6MCwiaXRhbGljIjowLCJ1bmRlcmxpbmUiOjAsImFsaWduIjoiY2VudGVyIiwicGFkZGluZ2xlZnQiOjB9LCJMaW5rIjp7InBhZGRpbmdsZWZ0IjowLCJzaXplIjoiMTAwfHwlIn0sIkxpbms6SG92ZXIiOnsicGFkZGluZ2xlZnQiOjAsInNpemUiOiIxMDB8fCUifX0="}') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (10, 'slidercache1', '{"time":1392925796,"data":{"css":"http:\\/\\/capstone.jonny.me\\/wp-content\\/cache\\/css\\/static\\/409dcf2d8aea4c164499dbce221beee6.css","js":{"core":{"\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/class.js":"\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/class.js"}},"fonts":{"Montserrat":{"0":400,"1":"latin","400,latin":1},"Pacifico":{"0":400,"1":"latin","400,latin":1},"Roboto":{"0":400,"1":"latin","400,latin":1}},"html":"<script type=\\"text\\/javascript\\">\\r\\n    window[\'nextend-smart-slider-1-onresize\'] = [];\\r\\n<\\/script>\\r\\n\\r\\n<div id=\\"nextend-smart-slider-1\\" class=\\"nextend-slider-fadeload nextend-desktop \\" style=\\"font-size: 12px;\\" data-allfontsize=\\"12\\" data-desktopfontsize=\\"12\\" data-tabletfontsize=\\"16\\" data-phonefontsize=\\"20\\">\\r\\n    <div class=\\"smart-slider-border1\\" style=\\"\\">\\r\\n        <div class=\\"smart-slider-border2\\">\\r\\n            \\r\\n                            <div class=\\"smart-slider-canvas smart-slider-slide-active smart-slider-bg-colored\\" style=\\"\\">\\r\\n                                            <img src=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/bg1.png\\" class=\\"nextend-slide-bg\\"\\/>\\r\\n                                                            <div class=\\"smart-slider-canvas-inner\\">\\r\\n                        <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer for heading\\" class=\\"smart-slider-layer\\" style=\\"top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><h1 class=\\"sliderfontcustom5 \\" style=\\"padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;\\">\\n                  First Slide\\n                <\\/h1><\\/div><\\/div>                    <\\/div>\\r\\n                                    <\\/div>\\r\\n                            <div class=\\"smart-slider-canvas smart-slider-bg-colored\\" style=\\"\\">\\r\\n                                            <img src=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/bg2.png\\" class=\\"nextend-slide-bg\\"\\/>\\r\\n                                                            <div class=\\"smart-slider-canvas-inner\\">\\r\\n                        <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer for heading\\" class=\\"smart-slider-layer\\" style=\\"top: 37.328%; left: 12.352%; width: 42.182%; height: 15.334%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><h1 class=\\"sliderfontcustom5 \\" style=\\"padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;\\">\\n                  Second Slide\\n                <\\/h1><\\/div><\\/div>                    <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer #2\\" class=\\"smart-slider-layer\\" style=\\"top: 52.667%; left: 12.364%; width: 17.455%; height: 16%; position: absolute; z-index: 2; display: block;\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><div class=\\"nextend-smartslider-button-black-opacity-button-container sliderfontcustom6\\" style=\\"cursor:pointer; width: 100%;\\">\\n    <a href=\\"#\\" onclick=\\"if(this.getAttribute(\'href\') == \'#\') return false;\\" target=\\"_self\\" style=\\"display: block;\\" class=\\"nextend-smartslider-button-black-opacity-button \\">\\n      Read more\\n    <\\/a>\\n<\\/div>\\n<\\/div><\\/div>                    <\\/div>\\r\\n                                    <\\/div>\\r\\n                            <div class=\\"smart-slider-canvas smart-slider-bg-colored\\" style=\\"\\">\\r\\n                                            <img src=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/bg3.png\\" class=\\"nextend-slide-bg\\"\\/>\\r\\n                                                            <div class=\\"smart-slider-canvas-inner\\">\\r\\n                        <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer for heading\\" class=\\"smart-slider-layer\\" style=\\"top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><h1 class=\\"sliderfontcustom5 \\" style=\\"padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;\\">\\n                  Third Slide\\n                <\\/h1><\\/div><\\/div>                    <\\/div>\\r\\n                                    <\\/div>\\r\\n                    <\\/div>\\r\\n    <\\/div>\\r\\n    <div onclick=\\"njQuery(\'#nextend-smart-slider-1\').smartslider(\'previous\');\\" class=\\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-display-tablet nextend-arrow-previous nextend-transition nextend-transition-previous nextend-transition-previous-square\\" style=\\"position: absolute;left:0%;top:45%;\\" ><div class=\\"smartslider-outer\\"><\\/div><div class=\\"smartslider-inner\\"><\\/div><\\/div><div onclick=\\"njQuery(\'#nextend-smart-slider-1\').smartslider(\'next\');\\" class=\\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-display-tablet nextend-arrow-next nextend-transition nextend-transition-next nextend-transition-next-square\\" style=\\"position: absolute;right:0%;top:45%;\\" ><div class=\\"smartslider-outer\\"><\\/div><div class=\\"smartslider-inner\\"><\\/div><\\/div><div style=\\"position: absolute;left:0%;bottom:1%;visibility: hidden;z-index:10; line-height: 0;width:100%;text-align:center;\\" class=\\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-bullet \\" ><div class=\\"nextend-bullet-container nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><div onclick=\\"njQuery(\'#nextend-smart-slider-1\').smartslider(\'goto\',0,false);\\" data-thumbnail=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/t1.png\\"  class=\\"nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><\\/div><div onclick=\\"njQuery(\'#nextend-smart-slider-1\').smartslider(\'goto\',1,false);\\" data-thumbnail=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/t2.png\\"  class=\\"nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><\\/div><div onclick=\\"njQuery(\'#nextend-smart-slider-1\').smartslider(\'goto\',2,false);\\" data-thumbnail=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/t3.png\\"  class=\\"nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><\\/div><\\/div><\\/div><\\/div>\\r\\n\\r\\n<script type=\\"text\\/javascript\\">\\r\\n    njQuery(document).ready(function () {\\r\\n        njQuery(\'#nextend-smart-slider-1\').smartslider({\\"translate3d\\":1,\\"playfirstlayer\\":0,\\"mainafterout\\":0,\\"inaftermain\\":1,\\"fadeonscroll\\":0,\\"autoplay\\":1,\\"autoplayConfig\\":{\\"duration\\":5000,\\"counter\\":0,\\"autoplayToSlide\\":0,\\"stopautoplay\\":{\\"click\\":1,\\"mouseenter\\":1,\\"slideplaying\\":1},\\"resumeautoplay\\":{\\"mouseleave\\":0,\\"slideplayed\\":1,\\"slidechanged\\":0}},\\"responsive\\":{\\"downscale\\":1,\\"upscale\\":0,\\"maxwidth\\":3000,\\"basedon\\":\\"device\\",\\"screenwidth\\":{\\"tablet\\":1024,\\"phone\\":640},\\"ratios\\":[1,1,0.7,0.5]},\\"controls\\":{\\"scroll\\":0,\\"touch\\":\\"horizontal\\",\\"keyboard\\":0},\\"blockrightclick\\":0,\\"type\\":\\"ssSimpleSlider\\",\\"animation\\":[\\"horizontal\\"],\\"animationSettings\\":{\\"duration\\":1100,\\"delay\\":0,\\"easing\\":\\"easeInOutCubic\\",\\"parallax\\":1},\\"flux\\":[0,[\\"bars\\"]],\\"touchanimation\\":\\"0\\"});\\r\\n    });\\r\\n<\\/script>\\r\\n<div style=\\"clear: both;\\"><\\/div>\\r\\n<div id=\\"nextend-smart-slider-1-placeholder\\" ><img alt=\\"\\" style=\\"width:100%; max-width: 3000px;\\" src=\\"data:image\\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAiYAAAEsCAYAAAD3vXi9AAAFPElEQVR4nO3WMQEAIAzAMMC\\/53GhgR6Jgp7dswAAGs7vAACAx5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMi4MF4DV7Ol3hgAAAAASUVORK5CYII=\\" \\/><\\/div>","libraries":{"modernizr":{"jsfiles":["\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/modernizr\\/modernizr.js"],"js":""},"jquery":{"jsfiles":["\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/njQuery.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jQuery.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/uacss.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.unique-element-id.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.waitforimages.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.touchSwipe.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/easing.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.transit.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/animationbase.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/smartsliderbase.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/mainslider.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/layers.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/no.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/fade.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/slide.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/transit.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/jquery.qtip.min.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/plugins\\/nextendslidertype\\/simple\\/simple\\/slider.js"],"js":"$(\\"#nextend-smart-slider-1 .nextend-bullet-container .nextend-bullet:not([data-thumbnail=\\\\\\"\\\\\\"])\\").qtip({\\r\\n                    position: {\\r\\n                        my: \\"bottom center\\",\\r\\n                        at: \\"top center\\",\\r\\n                        adjust: {\\r\\n                          x: 0,\\r\\n                          y: -3\\r\\n                        },\\r\\n                        container: $(\\"#nextend-smart-slider-1\\")\\r\\n                    },\\r\\n                    prerender: true,\\r\\n                    style: {\\r\\n                        tip: {\\r\\n                            width: 14,\\r\\n                            height: 6\\r\\n                        },\\r\\n                        classes: \\"nextend-bullet-transition-thumbnail\\"\\r\\n                    },\\r\\n                    content: {\\r\\n                        text: function(e, api) {\\r\\n                            var img = $(this).attr(\\"data-thumbnail\\");\\r\\n                            return \\"<img src=\'\\" + img + \\"\' style=\'width:100%;\' \\/>\\";\\r\\n                        }\\r\\n                    }\\r\\n                });\\r\\n            \\n"}}}}') ; 
INSERT INTO `wp_nextend_smartslider_storage` VALUES (11, 'slidercache2', '{"time":1392925864,"data":{"css":"http:\\/\\/capstone.jonny.me\\/wp-content\\/cache\\/css\\/static\\/19c0bfebae4f4ee0c1ca7224aed31188.css","js":{"core":{"\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/class.js":"\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/class.js"}},"fonts":{"Montserrat":{"0":400,"1":"latin","400,latin":1},"Pacifico":{"0":400,"1":"latin","400,latin":1},"Roboto":{"0":400,"1":"latin","400,latin":1}},"html":"<script type=\\"text\\/javascript\\">\\r\\n    window[\'nextend-smart-slider-2-onresize\'] = [];\\r\\n<\\/script>\\r\\n\\r\\n<div id=\\"nextend-smart-slider-2\\" class=\\"nextend-slider-fadeload nextend-desktop \\" style=\\"font-size: 12px;\\" data-allfontsize=\\"12\\" data-desktopfontsize=\\"12\\" data-tabletfontsize=\\"16\\" data-phonefontsize=\\"20\\">\\r\\n    <div class=\\"smart-slider-border1\\" style=\\"\\">\\r\\n        <div class=\\"smart-slider-border2\\">\\r\\n            \\r\\n                            <div class=\\"smart-slider-canvas smart-slider-slide-active smart-slider-bg-colored\\" style=\\"\\">\\r\\n                                            <img src=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/bg1.png\\" class=\\"nextend-slide-bg\\"\\/>\\r\\n                                                            <div class=\\"smart-slider-canvas-inner\\">\\r\\n                        <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer for heading\\" class=\\"smart-slider-layer\\" style=\\"top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><h1 class=\\"sliderfontcustom5 \\" style=\\"padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;\\">\\n                  First Slide\\n                <\\/h1><\\/div><\\/div>                    <\\/div>\\r\\n                                    <\\/div>\\r\\n                            <div class=\\"smart-slider-canvas smart-slider-bg-colored\\" style=\\"\\">\\r\\n                                            <img src=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/bg2.png\\" class=\\"nextend-slide-bg\\"\\/>\\r\\n                                                            <div class=\\"smart-slider-canvas-inner\\">\\r\\n                        <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer for heading\\" class=\\"smart-slider-layer\\" style=\\"top: 37.328%; left: 12.352%; width: 42.182%; height: 15.334%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><h1 class=\\"sliderfontcustom5 \\" style=\\"padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;\\">\\n                  Second Slide\\n                <\\/h1><\\/div><\\/div>                    <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer #2\\" class=\\"smart-slider-layer\\" style=\\"top: 52.667%; left: 12.364%; width: 17.455%; height: 16%; position: absolute; z-index: 2; display: block;\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><div class=\\"nextend-smartslider-button-black-opacity-button-container sliderfontcustom6\\" style=\\"cursor:pointer; width: 100%;\\">\\n    <a href=\\"#\\" onclick=\\"if(this.getAttribute(\'href\') == \'#\') return false;\\" target=\\"_self\\" style=\\"display: block;\\" class=\\"nextend-smartslider-button-black-opacity-button \\">\\n      Read more\\n    <\\/a>\\n<\\/div>\\n<\\/div><\\/div>                    <\\/div>\\r\\n                                    <\\/div>\\r\\n                            <div class=\\"smart-slider-canvas smart-slider-bg-colored\\" style=\\"\\">\\r\\n                                            <img src=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/bg3.png\\" class=\\"nextend-slide-bg\\"\\/>\\r\\n                                                            <div class=\\"smart-slider-canvas-inner\\">\\r\\n                        <div data-parallaxout=\\"0.45\\" data-delayout=\\"0\\" data-easingout=\\"linear\\" data-durationout=\\"500\\" data-animationout=\\"0\\" data-playoutafter=\\"0\\" data-parallaxin=\\"0.45\\" data-delayin=\\"0\\" data-easingin=\\"linear\\" data-durationin=\\"500\\" data-animationin=\\"0\\" data-name=\\"Layer for heading\\" class=\\"smart-slider-layer\\" style=\\"top: 37.328%; left: 12.352%; width: 37.819%; height: 20%; position: absolute; z-index: 1; display: block; visibility: visible; transform-origin: center center 0px; opacity: 1; transform: translate(0px, 0px) rotate(0deg);\\" data-animation=\\"slide\\"><div style=\\"\\" class=\\"smart-slider-items\\"  ><h1 class=\\"sliderfontcustom5 \\" style=\\"padding: 0;\\n                      margin: 0;\\n                      background: none;\\n                      box-shadow: none;\\">\\n                  Third Slide\\n                <\\/h1><\\/div><\\/div>                    <\\/div>\\r\\n                                    <\\/div>\\r\\n                    <\\/div>\\r\\n    <\\/div>\\r\\n    <div onclick=\\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'previous\');\\" class=\\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-display-tablet nextend-arrow-previous nextend-transition nextend-transition-previous nextend-transition-previous-square\\" style=\\"position: absolute;left:0%;top:45%;\\" ><div class=\\"smartslider-outer\\"><\\/div><div class=\\"smartslider-inner\\"><\\/div><\\/div><div onclick=\\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'next\');\\" class=\\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-display-tablet nextend-arrow-next nextend-transition nextend-transition-next nextend-transition-next-square\\" style=\\"position: absolute;right:0%;top:45%;\\" ><div class=\\"smartslider-outer\\"><\\/div><div class=\\"smartslider-inner\\"><\\/div><\\/div><div style=\\"position: absolute;left:0%;bottom:1%;visibility: hidden;z-index:10; line-height: 0;width:100%;text-align:center;\\" class=\\"nextend-widget nextend-widget-always nextend-widget-display-desktop nextend-widget-bullet \\" ><div class=\\"nextend-bullet-container nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><div onclick=\\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',0,false);\\" data-thumbnail=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/t1.png\\"  class=\\"nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><\\/div><div onclick=\\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',1,false);\\" data-thumbnail=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/t2.png\\"  class=\\"nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><\\/div><div onclick=\\"njQuery(\'#nextend-smart-slider-2\').smartslider(\'goto\',2,false);\\" data-thumbnail=\\"http:\\/\\/www.nextendweb.com\\/demo\\/smartslider2\\/images\\/FREE\\/t3.png\\"  class=\\"nextend-bullet nextend-bullet-transition nextend-bullet-transition-simple-mini nextend-bullet-horizontal\\"><\\/div><\\/div><\\/div><\\/div>\\r\\n\\r\\n<script type=\\"text\\/javascript\\">\\r\\n    njQuery(document).ready(function () {\\r\\n        njQuery(\'#nextend-smart-slider-2\').smartslider({\\"translate3d\\":1,\\"playfirstlayer\\":0,\\"mainafterout\\":0,\\"inaftermain\\":1,\\"fadeonscroll\\":0,\\"autoplay\\":1,\\"autoplayConfig\\":{\\"duration\\":5000,\\"counter\\":0,\\"autoplayToSlide\\":0,\\"stopautoplay\\":{\\"click\\":1,\\"mouseenter\\":1,\\"slideplaying\\":1},\\"resumeautoplay\\":{\\"mouseleave\\":0,\\"slideplayed\\":1,\\"slidechanged\\":0}},\\"responsive\\":{\\"downscale\\":1,\\"upscale\\":0,\\"maxwidth\\":3000,\\"basedon\\":\\"device\\",\\"screenwidth\\":{\\"tablet\\":1024,\\"phone\\":640},\\"ratios\\":[1,1,0.7,0.5]},\\"controls\\":{\\"scroll\\":0,\\"touch\\":\\"horizontal\\",\\"keyboard\\":0},\\"blockrightclick\\":0,\\"type\\":\\"ssSimpleSlider\\",\\"animation\\":[\\"horizontal\\"],\\"animationSettings\\":{\\"duration\\":1100,\\"delay\\":0,\\"easing\\":\\"easeInOutCubic\\",\\"parallax\\":1},\\"flux\\":[0,[\\"bars\\"]],\\"touchanimation\\":\\"0\\"});\\r\\n    });\\r\\n<\\/script>\\r\\n<div style=\\"clear: both;\\"><\\/div>\\r\\n<div id=\\"nextend-smart-slider-2-placeholder\\" ><img alt=\\"\\" style=\\"width:100%; max-width: 3000px;\\" src=\\"data:image\\/png;base64,iVBORw0KGgoAAAANSUhEUgAAAiYAAAEsCAYAAAD3vXi9AAAFPElEQVR4nO3WMQEAIAzAMMC\\/53GhgR6Jgp7dswAAGs7vAACAx5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMgwJgBAhjEBADKMCQCQYUwAgAxjAgBkGBMAIMOYAAAZxgQAyDAmAECGMQEAMowJAJBhTACADGMCAGQYEwAgw5gAABnGBADIMCYAQIYxAQAyjAkAkGFMAIAMYwIAZBgTACDDmAAAGcYEAMi4MF4DV7Ol3hgAAAAASUVORK5CYII=\\" \\/><\\/div>","libraries":{"modernizr":{"jsfiles":["\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/modernizr\\/modernizr.js"],"js":""},"jquery":{"jsfiles":["\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/njQuery.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jQuery.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/uacss.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.unique-element-id.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.waitforimages.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.touchSwipe.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/easing.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/javascript\\/jquery\\/1.9.1\\/jquery.transit.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/animationbase.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/smartsliderbase.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/mainslider.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/layers.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/no.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/fade.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/slide.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/library\\/smartslider\\/assets\\/js\\/motions\\/transit.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/nextend\\/assets\\/js\\/jquery.qtip.min.js","\\/home\\/jonnymac\\/public_html\\/capstone\\/wp-content\\/plugins\\/smart-slider-2\\/plugins\\/nextendslidertype\\/simple\\/simple\\/slider.js"],"js":"$(\\"#nextend-smart-slider-2 .nextend-bullet-container .nextend-bullet:not([data-thumbnail=\\\\\\"\\\\\\"])\\").qtip({\\r\\n                    position: {\\r\\n                        my: \\"bottom center\\",\\r\\n                        at: \\"top center\\",\\r\\n                        adjust: {\\r\\n                          x: 0,\\r\\n                          y: -3\\r\\n                        },\\r\\n                        container: $(\\"#nextend-smart-slider-2\\")\\r\\n                    },\\r\\n                    prerender: true,\\r\\n                    style: {\\r\\n                        tip: {\\r\\n                            width: 14,\\r\\n                            height: 6\\r\\n                        },\\r\\n                        classes: \\"nextend-bullet-transition-thumbnail\\"\\r\\n                    },\\r\\n                    content: {\\r\\n                        text: function(e, api) {\\r\\n                            var img = $(this).attr(\\"data-thumbnail\\");\\r\\n                            return \\"<img src=\'\\" + img + \\"\' style=\'width:100%;\' \\/>\\";\\r\\n                        }\\r\\n                    }\\r\\n                });\\r\\n            \\n"}}}}') ;
#
# End of data contents of table wp_nextend_smartslider_storage
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------


#
# Delete any existing table `wp_nm_repositories`
#

DROP TABLE IF EXISTS `wp_nm_repositories`;


#
# Table structure of table `wp_nm_repositories`
#

CREATE TABLE `wp_nm_repositories` (
  `fileID` int(9) NOT NULL AUTO_INCREMENT,
  `userID` int(7) NOT NULL,
  `userName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `fileName` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileDetail` mediumtext COLLATE utf8_unicode_ci,
  `isShared` int(1) DEFAULT '0',
  `fileSize` int(12) DEFAULT NULL,
  `fileType` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileMeta` mediumtext COLLATE utf8_unicode_ci,
  `fileParent` int(12) DEFAULT NULL,
  `fileUploadedOn` datetime NOT NULL,
  PRIMARY KEY (`fileID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ;

#
# Data contents of table wp_nm_repositories (5 records)
#
 
INSERT INTO `wp_nm_repositories` VALUES (1, 1, 'admin', 'Resume.txt', 'This is a description for a resume.', 0, 0, 'txt', NULL, 0, '2014-02-28 14:07:45') ; 
INSERT INTO `wp_nm_repositories` VALUES (2, 19, 'Cameron Evans', 'My_Portfolio', NULL, 0, 0, '1dir', NULL, 0, '2014-02-28 21:01:46') ; 
INSERT INTO `wp_nm_repositories` VALUES (3, 19, 'Cameron Evans', 'Memo.docx', 'This is a memo?', 0, 72698, 'docx', NULL, 0, '2014-02-28 21:02:56') ; 
INSERT INTO `wp_nm_repositories` VALUES (4, 47, 'MarcScarfone', 'Office', NULL, 0, 0, '1dir', NULL, 0, '2014-04-17 18:58:53') ; 
INSERT INTO `wp_nm_repositories` VALUES (5, 47, 'MarcScarfone', 'Database', NULL, 0, 0, '1dir', NULL, 0, '2014-04-17 18:59:06') ;
#
# End of data contents of table wp_nm_repositories
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------


#
# Delete any existing table `wp_optinrev`
#

DROP TABLE IF EXISTS `wp_optinrev`;


#
# Table structure of table `wp_optinrev`
#

CREATE TABLE `wp_optinrev` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_optinrev (17 records)
#
 
INSERT INTO `wp_optinrev` VALUES (1, 'optinrev_poweredby', 'true') ; 
INSERT INTO `wp_optinrev` VALUES (2, 'optinrev_optinrevolution/optin1_enabled', 'true') ; 
INSERT INTO `wp_optinrev` VALUES (3, 'optinrev_show_popup', 'show_always') ; 
INSERT INTO `wp_optinrev` VALUES (4, 'optinrev_popups', 'a:1:{s:22:"optinrevolution/optin1";s:13:"Optin Popup 1";}') ; 
INSERT INTO `wp_optinrev` VALUES (5, 'optinrev_show_where', 'show_on_load') ; 
INSERT INTO `wp_optinrev` VALUES (6, 'optinrev_autosave', 'false') ; 
INSERT INTO `wp_optinrev` VALUES (7, 'optinrev_showmobile', 'false') ; 
INSERT INTO `wp_optinrev` VALUES (8, 'pub.optinrevolution.com', '<script type=\'text/javascript\'>
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function() {
var gads = document.createElement(\'script\');
gads.async = true;
gads.type = \'text/javascript\';
var useSSL = \'https:\' == document.location.protocol;
gads.src = (useSSL ? \'https:\' : \'http:\') + 
\'//www.googletagservices.com/tag/js/gpt.js\';
var node = document.getElementsByTagName(\'script\')[0];
node.parentNode.insertBefore(gads, node);
})();
</script>
<script type=\'text/javascript\'>
googletag.cmd.push(function() {
googletag.defineSlot(\'/14806716/Optin_Revolution_Lite_728x90\', [728, 90], \'div-gpt-ad-1375271579623-0\').addService(googletag.pubads());
googletag.pubads().enableSingleRequest();
googletag.enableServices();
});
</script>
<div id=\'div-gpt-ad-1375271579623-0\' style=\'width:728px; height:90px;\'>
<script type=\'text/javascript\'>
googletag.cmd.push(function() { googletag.display(\'div-gpt-ad-1375271579623-0\'); });
</script>
</div>
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 994084946;
var google_conversion_label = "9YB0CLbzyQQQ0pCC2gM";
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/994084946/?value=0&amp;label=9YB0CLbzyQQQ0pCC2gM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>') ; 
INSERT INTO `wp_optinrev` VALUES (9, 'pub.optinrevolution.com/video', '<div><h3>Increase your subscriber optin rate by 200%, 400% or even 600%! <a href="http://www.optinrevolution.com/?utm_source=plugin&utm_medium=link&utm_campaign=upgrade_video" title="Upgrade to Pro" target="_blank">Upgrade to Pro</a></h3></div>
<p><iframe width="640" height="360" src="http://www.youtube.com/embed/ver0g1DOyqY?rel=0&hl=en&fs=1&showinfo=0&vq=hd720&controls=0&wmode=transparent" frameborder="0" wmode="opaque" allowfullscreen></iframe></p>
<div><h3>Ready to take your email marketing efforts to the next level? <a href="http://www.optinrevolution.com/?utm_source=plugin&utm_medium=link&utm_campaign=upgrade_video" title="Upgrade to Pro" target="_blank">Upgrade to Pro</a></h3></div>') ; 
INSERT INTO `wp_optinrev` VALUES (10, 'optinrev_popup_enabled', 'false') ; 
INSERT INTO `wp_optinrev` VALUES (11, 'optinrev_default_images', 'a:2:{s:10:"get_access";a:3:{s:11:"get_access1";s:83:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/get_access1.png";s:11:"get_access2";s:83:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/get_access2.png";s:11:"get_access3";s:83:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/get_access3.png";}s:9:"close_btn";a:8:{s:6:"close1";s:79:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/close1b.png";s:6:"close2";s:79:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/close2b.png";s:6:"close3";s:79:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/close3b.png";s:6:"close4";s:79:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/close1r.png";s:6:"close5";s:79:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/close2r.png";s:6:"close6";s:79:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/close3r.png";s:6:"close7";s:76:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/btn1.png";s:6:"close8";s:76:"http://capstone.jonny.me/wp-content/plugins/optin-revolution/images/btn2.png";}}') ; 
INSERT INTO `wp_optinrev` VALUES (12, 'optinrev_cuid_12', 'get_access1.png|get_access1') ; 
INSERT INTO `wp_optinrev` VALUES (13, 'optinrev_cuid_13', 'get_access2.png|get_access2') ; 
INSERT INTO `wp_optinrev` VALUES (14, 'optinrev_cuid_14', 'get_access3.png|get_access3') ; 
INSERT INTO `wp_optinrev` VALUES (17, 'pub.optinrevolution.com/text.html', '<script type=\'text/javascript\'>
var googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
(function() {
var gads = document.createElement(\'script\');
gads.async = true;
gads.type = \'text/javascript\';
var useSSL = \'https:\' == document.location.protocol;
gads.src = (useSSL ? \'https:\' : \'http:\') + 
\'//www.googletagservices.com/tag/js/gpt.js\';
var node = document.getElementsByTagName(\'script\')[0];
node.parentNode.insertBefore(gads, node);
})();
</script>
<script type=\'text/javascript\'>
googletag.cmd.push(function() {
googletag.defineSlot(\'/14806716/Optin_Revolution_Lite_728x50\', [728, 50], \'div-gpt-ad-1375271604622-0\').addService(googletag.pubads());
googletag.pubads().enableSingleRequest();
googletag.enableServices();
});
</script>
<div id=\'div-gpt-ad-1375271604622-0\' style=\'width:728px; height:50px;\'>
<script type=\'text/javascript\'>
googletag.cmd.push(function() { googletag.display(\'div-gpt-ad-1375271604622-0\'); });
</script>
</div>') ; 
INSERT INTO `wp_optinrev` VALUES (18, 'optinrevolution/optin1', 'a:36:{s:6:"action";s:15:"optinrev_action";s:19:"save_setup_settings";s:22:"optinrevolution/optin1";s:13:"optinrev_data";s:5079:"<div style="position: absolute; left: 421px; top: 297px;border: 1px solid transparent;"><img id="wm" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/get_access2.png" border="0"></div><div style="position: absolute; left: 270px; top: 128px;border: 1px solid transparent;"><img id="stage_img_48" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/v-arrows.gif" border="0"></div><div style="position: absolute; left: 492px; top: 384px;border: 1px solid transparent;"><img id="stage_img_47" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/padlock.png" border="0"></div><div style="position: absolute; left: 511px; top: 387px; z-index: 1;border: 1px solid transparent;"><span style="font-size: 8pt;" data-mce-style="font-size: 8pt;">Your Privacy Is Protected.</span></div><div style="position: absolute; left: 87px; top: 85px; z-index: 1; text-align: center;border: 1px solid transparent;"><strong><span style="font-family: tahoma, arial, helvetica, sans-serif; font-size: 14pt;" data-mce-style="font-family: tahoma, arial, helvetica, sans-serif; font-size: 14pt;">On Average, 8 Out Of 10 People Will Read Headline Copy</span></strong><br><strong><span style="font-family: tahoma, arial, helvetica, sans-serif; font-size: 14pt;" data-mce-style="font-family: tahoma, arial, helvetica, sans-serif; font-size: 14pt;">But Only 2 Out Of 10 Will Read The Rest.</span></strong></div><div style="position: absolute; left: 4px; top: 10px; z-index: 1; text-align: center;border: 1px solid transparent;"><span style="font-family: impact, chicago; font-size: 24pt; color: #ff0000;">Remember, Every Element Of Compelling Copy Has Just<br>One Purpose - To Get The Next Sentence Read!</span></div><div style="position: absolute; left: 422px; top: 185px; z-index: 1; text-align: center; line-height: 16px; border: 1px solid transparent;"><span style="font-size: 10pt; font-family: arial, helvetica, sans-serif;" data-mce-style="font-size: 10pt; font-family: arial, helvetica, sans-serif;">Simply enter your best email below then click</span><br><span style="font-size: 10pt; font-family: arial, helvetica, sans-serif;" data-mce-style="font-size: 10pt; font-family: arial, helvetica, sans-serif;">"Get Access Now!" button and get instant</span><br><span style="font-size: 10pt; font-family: arial, helvetica, sans-serif;" data-mce-style="font-size: 10pt; font-family: arial, helvetica, sans-serif;">access to _____________ - <strong><span style="color: #ff0000;" data-mce-style="color: #ff0000;">100% FREE</span></strong></span></div><div style="position: absolute; left: 416px; top: 137px; z-index: 1; text-align: center;border: 1px solid transparent;"><span style="font-family: impact, chicago; font-size: 24pt; background-color: #ffff99;" data-mce-style="font-family: impact, chicago; font-size: 24pt; background-color: #ffff99;">FREE INSTANT ACCESS</span></div><div style="position: absolute; left: 7px; top: 116px; z-index: 2; border: 1px solid transparent;"><img id="stage_img_250" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/girl.gif" border="0" /></div><div id="poweredby" style="position: absolute; left: 240px; top: 420px; color: white;"><a href="http://www.optinrevolution.com/?utm_source=plugin&amp;utm_medium=link&amp;utm_campaign=poweredby" target="_new_blank" rel="nofollow" style="color:white !important">Wordpress Popup</a> <span style="color:white">by</span> <a href="http://www.optinrevolution.com/?utm_source=plugin&amp;utm_medium=link&amp;utm_campaign=poweredby" target="_blank" rel="nofollow" style="color:white !important">Optin Revolution Pro</a></div><form method="post" id="mce_getaccessed" action="http://www.optinrevolution.com/setup/?utm_source=plugin&utm_medium=not-setup&utm_campaign=lite" target="_blank"><div style="display:none;"><input type="hidden" name="listname" value="optinrev_course"><input type="hidden" name="meta_web_form_id" value="1712095327"><input type="hidden" name="meta_message" value="1"><input type="hidden" name="meta_adtracking" value="Pro"><input type="hidden" name="redirect" value="http://www.optinrevolution.com/free-course/thankyou.php"><input type="hidden" name="meta_redirect_onlist" value=""><input type="hidden" name="meta_required" value="email"></div><div style="position: absolute; left: 0px; top: 0px; border: 1px solid transparent; display: none;display:none;"><input type="text" name="name" id="name" value="Enter Your Name..." style="font-family: arial !important;font-size:20px;color:#000000;padding-top:8px !important;padding-bottom:8px !important;width:261px;background-color:#FFFFCC !important;border:5px solid #666666;"></div><div style="position: absolute; left: 425px; top: 237px;border: 1px solid transparent;"><input type="text" name="email" id="email" value="Enter Your Email..." style="font-family: arial !important;font-size:20px;color:#000000;padding-top:8px !important;padding-bottom:8px !important;width:261px;background-color:#FFFFCC !important;border:5px solid #666666;"></div></form>";s:21:"optinrev_close_button";s:22:"left:722.5px;top:33.5;";s:27:"optinrev_close_button_class";s:6:"close2";s:17:"optinrev_dragging";i:1;s:27:"optinrev_call_action_button";s:11:"get_access2";s:16:"optinrev_excerpt";s:4649:"<div id="simplemodal-container" style="width: 720px; height: 410px; border: 8px solid rgba(0,119,255,0.75); background-color: #ffffff; -moz-border-radius: 25px; -webkit-border-radius: 25px; border-radius: 25px;"><div class="close2" id="close" style="left:704.5px; top:-29.5px;"> </div><div class="simplemodal-data" id="simplemodal-data"><div style="position: absolute; left: 421px; top: 297px;"><img id="wm" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/get_access2.png" border="0" /></div><div style="position: absolute; left: 270px; top: 128px;"><img id="stage_img_48" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/v-arrows.gif" border="0" /></div><div style="position: absolute; left: 492px; top: 384px;"><img id="stage_img_47" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/padlock.png" border="0" /></div><div style="position: absolute; left: 511px; top: 387px; z-index: 1;"><span style="font-size: 8pt;">Your Privacy Is Protected.</span></div><div style="position: absolute; left: 87px; top: 85px; z-index: 1; text-align: center;"><strong><span style="font-family: tahoma, arial, helvetica, sans-serif; font-size: 14pt;">On Average, 8 Out Of 10 People Will Read Headline Copy</span></strong><br /><strong><span style="font-family: tahoma, arial, helvetica, sans-serif; font-size: 14pt;">But Only 2 Out Of 10 Will Read The Rest.</span></strong></div><div style="position: absolute; left: 4px; top: 10px; z-index: 1; text-align: center;"><span style="font-family: impact, chicago; font-size: 24pt; color: #ff0000;">Remember, Every Element Of Compelling Copy Has Just<br />One Purpose - To Get The Next Sentence Read!</span></div><div style="position: absolute; left: 422px; top: 185px; line-height: 16px; z-index: 1; text-align: center;"><span style="font-size: 10pt; font-family: arial, helvetica, sans-serif;">Simply enter your best email below then click</span><br /><span style="font-size: 10pt; font-family: arial, helvetica, sans-serif;">"Get Access Now!" button and get instant</span><br /><span style="font-size: 10pt; font-family: arial, helvetica, sans-serif;">access to _____________ - <strong><span style="color: #ff0000;">100% FREE</span></strong></span></div><div style="position: absolute; left: 416px; top: 137px; z-index: 1; text-align: center;"><span style="font-family: impact, chicago; font-size: 24pt; background-color: #ffff99;">FREE INSTANT ACCESS</span></div><div style="position: absolute; left: 7px; top: 116px; z-index: 2; border: 1px solid transparent;"><img id="stage_img_250" alt="" src="http://capstone.jonny.me/wp-content/plugins/optin-revolution/assets/girl.gif" border="0" /></div><div id="poweredby" style="position: absolute; left: 240px; top: 420px; color: white;"><a style="color: white !important;" href="http://www.optinrevolution.com/?utm_source=plugin&amp;utm_medium=link&amp;utm_campaign=poweredby" target="_blank" rel="nofollow">Wordpress Popup</a> <span style="color: white;">by</span> <a style="color: white !important;" href="http://www.optinrevolution.com/?utm_source=plugin&amp;utm_medium=link&amp;utm_campaign=poweredby" target="_blank" rel="nofollow">Optin Revolution Pro</a></div><form id="mce_getaccessed" action="http://www.optinrevolution.com/setup/?utm_source=plugin&utm_medium=not-setup&utm_campaign=lite" method="post" target="_blank"><div style="display: none;"><input type="hidden" name="listname" value="optinrev_course" /><input type="hidden" name="meta_web_form_id" value="1712095327" /><input type="hidden" name="meta_message" value="1" /><input type="hidden" name="meta_adtracking" value="Pro" /><input type="hidden" name="redirect" value="http://www.optinrevolution.com/free-course/thankyou.php" /><input type="hidden" name="meta_redirect_onlist" value="" /><input type="hidden" name="meta_required" value="email" /></div><div style="position: absolute; left: 0px; top: 0px; border: 1px solid transparent; display: none;"><input id="name" style="font-family: arial !important; font-size: 20px; color: #000000; padding-top: 8px !important; padding-bottom: 8px !important; width: 261px; background-color: #ffffcc !important; border: 5px solid #666666;" type="text" name="name" value="Enter Your Name..." /></div><div style="position: absolute; left: 425px; top: 237px;"><input id="email" style="font-family: arial !important; font-size: 20px; color: #000000; padding-top: 8px !important; padding-bottom: 8px !important; width: 261px; background-color: #ffffcc !important; border: 5px solid #666666;" type="text" name="email" value="Enter Your Email..." /></div></form></div></div>";s:23:"optinrev_email_form_opt";s:6:"aweber";s:22:"optinrev_foptin_active";s:6:"aweber";s:19:"optinrev_email_form";a:1:{s:6:"aweber";a:9:{s:4:"name";s:18:"Enter Your Name...";s:5:"email";s:19:"Enter Your Email...";s:8:"listname";s:0:"";s:16:"meta_web_form_id";s:0:"";s:12:"meta_message";N;s:15:"meta_adtracking";s:0:"";s:8:"redirect";s:0:"";s:20:"meta_redirect_onlist";s:0:"";s:17:"pixel_tracking_id";s:0:"";}}s:22:"optinrev_input_enabled";a:1:{s:4:"name";i:0;}s:8:"validate";a:1:{s:5:"email";i:1;}s:15:"optinrev_inputh";i:50;s:15:"optinrev_inputw";i:259;s:16:"optinrev_inputtc";s:7:"#000000";s:16:"optinrev_inputfz";i:20;s:15:"optinrev_inputc";s:7:"#FFFFCC";s:15:"optinrev_inputb";s:7:"#666666";s:16:"optinrev_inputbt";i:5;s:18:"optinrev_wbg_color";s:7:"#000000";s:20:"optinrev_wbg_opacity";i:50;s:14:"optinrev_delay";i:0;s:19:"optinrev_pwbg_color";s:7:"#FFFFFF";s:21:"optinrev_border_color";s:7:"#0077FF";s:25:"optinrev_border_thickness";i:8;s:23:"optinrev_border_opacity";i:75;s:22:"optinrev_border_radius";i:25;s:21:"optinrev_round_border";s:2:"on";s:19:"optinrev_top_margin";i:127;s:15:"optinrev_wwidth";i:720;s:16:"optinrev_hheight";i:410;s:19:"optinrev_link_color";s:7:"#1122CC";s:26:"optinrev_close_popup_image";s:6:"close2";s:20:"optinrev_gotowebsite";s:3:"top";s:21:"optinrev_cookie_delay";i:10;}') ; 
INSERT INTO `wp_optinrev` VALUES (19, 'optinrev_active_action_button', 'get_access2.png') ;
#
# End of data contents of table wp_optinrev
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3633 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (183 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/itworks', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'maceachern.jonny@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'permalink_structure', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (35, 'active_plugins', 'a:20:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:31:"advanced-access-manager/aam.php";i:2;s:45:"advanced-code-editor/advanced-code-editor.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:49:"content-aware-sidebars/content-aware-sidebars.php";i:5;s:25:"duplicator/duplicator.php";i:6;s:35:"exploit-scanner/exploit-scanner.php";i:7;s:65:"hide-admin-bar-from-non-admins/hide-admin-bar-from-non-admins.php";i:8;s:23:"ml-slider/ml-slider.php";i:9;s:33:"nav-menu-roles/nav-menu-roles.php";i:10;s:33:"soliloquy-lite/soliloquy-lite.php";i:11;s:52:"testimonials-by-woothemes/woothemes-testimonials.php";i:12;s:33:"theme-my-login/theme-my-login.php";i:13;s:45:"user-meta-shortcodes/user-meta-shortcodes.php";i:14;s:23:"user-meta/user-meta.php";i:15;s:37:"user-role-editor/user-role-editor.php";i:16;s:41:"wordpress-importer/wordpress-importer.php";i:17;s:33:"wp-front-end-repository/index.php";i:18;s:53:"wp-job-manager-companies/wp-job-manager-companies.php";i:19;s:33:"wp-job-manager/wp-job-manager.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'home', 'http://localhost/itworks', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'recently_edited', 'a:5:{i:0;s:76:"/home/jonnymac/public_html/capstone/wp-content/themes/jobify-child/style.css";i:1;s:80:"/home/jonnymac/public_html/capstone/wp-content/themes/jobify-child/functions.php";i:3;s:80:"/home/jonnymac/public_html/capstone/wp-content/themes/jobify/job-application.php";i:4;s:70:"/home/jonnymac/public_html/capstone/wp-content/themes/jobify/style.css";i:5;s:70:"/home/jonnymac/public_html/capstone/wp-content/themes/jobify/index.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (44, 'template', 'jobify', 'yes') ; 
INSERT INTO `wp_options` VALUES (45, 'stylesheet', 'jobify-child', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (48, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'default_role', 'candidateid', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'db_version', '27916', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'widget_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'widget_text', 'a:7:{i:2;a:3:{s:5:"title";s:0:"";s:4:"text";s:0:"";s:6:"filter";b:0;}i:3;a:3:{s:5:"title";s:5:"Pages";s:4:"text";s:229:"<ul>
<li  class="buffer-top"><a href="#">Item 1</a></li>
<li><a href="#">Item 1</a></li>
<li><a href="#">Item 1</a></li>
<li><a href="#">Item 1</a></li>
<li><a href="#">Item 1</a></li>
<li><a href="#">Item 1</a></li>
</ul>";s:6:"filter";b:0;}i:4;a:3:{s:5:"title";s:7:"Members";s:4:"text";s:408:"<ul>
<li class="buffer-top"><a href="http://capstone.jonny.me/your-company-profile/">Company Profile</a></li>
<li><a href="http://capstone.jonny.me/find-a-job/">Find A Job</a></li>
<li><a href="http://capstone.jonny.me/post-a-job/">Manage Jobs</a></li>
<li><a href="http://capstone.jonny.me/manage-jobs/">Manage Posts</a></li>
<li><a href="http://capstone.jonny.me/profile/">My Profile</a></li>

</ul>";s:6:"filter";b:0;}i:5;a:3:{s:5:"title";s:10:"Contact Us";s:4:"text";s:249:"<div class="scarfone">
<b>Administrator: </b>Marc Scarfone <br>
<b>Business Title: </b>Faculty<br>
<b>Department:</b> Info. Technology Y2 System Management Network<br>
<b>Phone:</b> (902) 491-5112<br>
<b>Email:</b> Marc.Scarfone@nscc.ca
</div>";s:6:"filter";b:0;}i:7;a:3:{s:5:"title";s:13:"Job Community";s:4:"text";s:379:"<ul>
<li class="buffer-top"><a href="http://capstone.jonny.me/about/">About</a></li>
<li><a href="http://capstone.jonny.me/contact/">Contact</a></li>
<li><a href="http://capstone.jonny.me/faqs/">FAQs</a></li>
<li><a href="http://capstone.jonny.me/privacy-policy/">Privacy</a></li>
<li><a href="http://capstone.jonny.me/terms-and-conditions/">Terms/Conditions</a></li>
</ul>";s:6:"filter";b:0;}i:8;a:3:{s:5:"title";s:8:"About Us";s:4:"text";s:286:"<div class="FooterAbout">
We\'re a Job Community for potential employers and NSCC students and Alumni. We connect employers with students from all over the province and make an opportunity for both be successful in the IT industry.
<br><br>
<a href="/about/">Learn More...</a>
</div>";s:6:"filter";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'uninstall_plugins', 'a:4:{s:33:"theme-my-login/theme-my-login.php";a:2:{i:0;s:20:"Theme_My_Login_Admin";i:1;s:9:"uninstall";}s:31:"advanced-access-manager/aam.php";a:2:{i:0;s:3:"aam";i:1;s:9:"uninstall";}s:38:"simple-backup/simple-backup-loader.php";s:23:"simple_backup_uninstall";s:35:"exploit-scanner/exploit-scanner.php";s:24:"exploitscanner_uninstall";}', 'no') ; 
INSERT INTO `wp_options` VALUES (86, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'page_on_front', '25', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'initial_db_version', '26691', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'wp_user_roles', 'a:8:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:64:{s:13:"switch_themes";i:1;s:11:"edit_themes";i:1;s:16:"activate_plugins";i:1;s:12:"edit_plugins";i:1;s:10:"edit_users";i:1;s:10:"edit_files";i:1;s:14:"manage_options";i:1;s:17:"moderate_comments";i:1;s:17:"manage_categories";i:1;s:12:"manage_links";i:1;s:12:"upload_files";i:1;s:6:"import";i:1;s:15:"unfiltered_html";i:1;s:10:"edit_posts";i:1;s:17:"edit_others_posts";i:1;s:20:"edit_published_posts";i:1;s:13:"publish_posts";i:1;s:10:"edit_pages";i:1;s:4:"read";i:1;s:8:"level_10";i:1;s:7:"level_9";i:1;s:7:"level_8";i:1;s:7:"level_7";i:1;s:7:"level_6";i:1;s:7:"level_5";i:1;s:7:"level_4";i:1;s:7:"level_3";i:1;s:7:"level_2";i:1;s:7:"level_1";i:1;s:7:"level_0";i:1;s:17:"edit_others_pages";i:1;s:20:"edit_published_pages";i:1;s:13:"publish_pages";i:1;s:12:"delete_pages";i:1;s:19:"delete_others_pages";i:1;s:22:"delete_published_pages";i:1;s:12:"delete_posts";i:1;s:19:"delete_others_posts";i:1;s:22:"delete_published_posts";i:1;s:20:"delete_private_posts";i:1;s:18:"edit_private_posts";i:1;s:18:"read_private_posts";i:1;s:20:"delete_private_pages";i:1;s:18:"edit_private_pages";i:1;s:18:"read_private_pages";i:1;s:12:"delete_users";i:1;s:12:"create_users";i:1;s:17:"unfiltered_upload";i:1;s:14:"edit_dashboard";i:1;s:14:"update_plugins";i:1;s:14:"delete_plugins";i:1;s:15:"install_plugins";i:1;s:13:"update_themes";i:1;s:14:"install_themes";i:1;s:11:"update_core";i:1;s:10:"list_users";i:1;s:12:"remove_users";i:1;s:9:"add_users";i:1;s:13:"promote_users";i:1;s:18:"edit_theme_options";i:1;s:13:"delete_themes";i:1;s:6:"export";i:1;s:19:"manage_job_listings";b:1;s:12:"manage_roles";i:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:7:"Company";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:21:"aamrole_532b177d52ab8";a:2:{s:4:"name";s:9:"Candidate";s:12:"capabilities";a:0:{}}s:8:"employer";a:2:{s:4:"name";s:8:"Employer";s:12:"capabilities";a:3:{s:4:"read";b:1;s:10:"edit_posts";b:0;s:12:"delete_posts";b:0;}}s:11:"candidateid";a:2:{s:4:"name";s:9:"Candidate";s:12:"capabilities";a:0:{}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:2:{i:0;s:6:"text-2";i:1;s:6:"text-3";}s:22:"widget-area-front-page";a:3:{i:0;s:19:"metaslider_widget-2";i:1;s:20:"jobify_widget_jobs-2";i:2;s:21:"jobify_widget_stats-2";}s:18:"widget-area-footer";a:4:{i:0;s:6:"text-8";i:1;s:6:"text-7";i:2;s:6:"text-4";i:3;s:6:"text-5";}s:25:"widget-area-price-options";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (169, 'widget_jobify_widget_stats', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:11:"description";s:0:"";s:10:"animations";s:1:"1";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'cron', 'a:9:{i:1397358000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1407771187;a:2:{s:34:"job_manager_check_for_expired_jobs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:31:"job_manager_delete_old_previews";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1407784337;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1407784341;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1407784356;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1407808115;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1407819594;a:1:{s:24:"user_meta_schedule_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1408143600;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3631, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (3617, '_site_transient_timeout_theme_roots', '1407772972', 'yes') ; 
INSERT INTO `wp_options` VALUES (3618, '_site_transient_theme_roots', 'a:5:{s:12:"jobify-child";s:7:"/themes";s:6:"jobify";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3619, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1407771180;s:7:"checked";a:5:{s:12:"jobify-child";s:5:"1.0.0";s:6:"jobify";s:5:"1.5.3";s:14:"twentyfourteen";s:3:"1.1";s:14:"twentythirteen";s:3:"1.2";s:12:"twentytwelve";s:3:"1.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2534, 'user_meta_cache', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2536, 'job_manager_registration_role', 'employer', 'yes') ; 
INSERT INTO `wp_options` VALUES (2538, 'soliloquy_upgrade', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2583, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:26:"maceachern.jonny@gmail.com";s:7:"version";s:5:"3.9.2";s:9:"timestamp";i:1407771178;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (992, 'user_meta_fields', 'a:13:{i:1;a:6:{s:11:"field_title";s:10:"First Name";s:10:"field_type";s:10:"first_name";s:14:"title_position";s:3:"top";s:8:"max_char";s:2:"32";s:10:"field_size";s:3:"200";s:9:"css_style";s:19:"margin-bottom:30px;";}i:2;a:4:{s:11:"field_title";s:5:"Email";s:10:"field_type";s:10:"user_email";s:14:"title_position";s:3:"top";s:9:"css_style";s:19:"margin-bottom:30px;";}i:3;a:4:{s:11:"field_title";s:8:"Password";s:10:"field_type";s:9:"user_pass";s:14:"title_position";s:3:"top";s:9:"css_style";s:19:"margin-bottom:30px;";}i:4;a:4:{s:11:"field_title";s:7:"Website";s:10:"field_type";s:8:"user_url";s:14:"title_position";s:3:"top";s:9:"css_style";s:19:"margin-bottom:30px;";}i:5;a:4:{s:11:"field_title";s:9:"Last Name";s:10:"field_type";s:9:"last_name";s:14:"title_position";s:3:"top";s:9:"css_style";s:19:"margin-bottom:30px;";}i:6;a:5:{s:11:"field_title";s:17:"Biographical Info";s:10:"field_type";s:11:"description";s:14:"title_position";s:3:"top";s:10:"field_size";s:5:"100%;";s:9:"css_style";s:19:"margin-bottom:30px;";}i:7;a:8:{s:11:"field_title";s:14:"Program Stream";s:10:"field_type";s:6:"select";s:14:"title_position";s:3:"top";s:8:"meta_key";s:14:"program_stream";s:8:"required";s:2:"on";s:7:"options";s:293:"1st Year=1st Year, Computer Electronics Technician=Computer Electronics Technician, Database Administration=Database Administration, Systems Management/Networking=Systems Management/Networking, Programming=Programming, Database Development=Database Development, Web Programming=Web Programming";s:10:"field_size";s:6:"500px;";s:9:"css_style";s:19:"margin-bottom:30px;";}i:9;a:6:{s:11:"field_title";s:22:"Education & Experience";s:10:"field_type";s:8:"textarea";s:14:"title_position";s:3:"top";s:8:"meta_key";s:9:"education";s:10:"field_size";s:5:"100%;";s:9:"css_style";s:19:"margin-bottom:30px;";}i:10;a:6:{s:11:"field_title";s:6:"Skills";s:10:"field_type";s:8:"textarea";s:14:"title_position";s:3:"top";s:8:"meta_key";s:6:"skills";s:10:"field_size";s:5:"100%;";s:9:"css_style";s:19:"margin-bottom:30px;";}i:11;a:6:{s:11:"field_title";s:12:"Phone Number";s:10:"field_type";s:4:"text";s:14:"title_position";s:3:"top";s:8:"meta_key";s:12:"phone_number";s:8:"max_char";s:2:"12";s:9:"css_style";s:19:"margin-bottom:30px;";}i:12;a:4:{s:11:"field_title";s:8:"LinkedIn";s:10:"field_type";s:4:"text";s:14:"title_position";s:3:"top";s:8:"meta_key";s:8:"linkedin";}i:13;a:4:{s:11:"field_title";s:5:"Skype";s:10:"field_type";s:4:"text";s:14:"title_position";s:3:"top";s:8:"meta_key";s:5:"skype";}i:14;a:4:{s:11:"field_title";s:10:"Phone Cell";s:10:"field_type";s:4:"text";s:14:"title_position";s:3:"top";s:8:"meta_key";s:10:"phone_cell";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (994, 'user_meta_forms', 'a:2:{s:14:"seeker_profile";a:5:{s:8:"form_key";s:14:"seeker_profile";s:6:"fields";a:11:{i:0;s:1:"1";i:1;s:1:"5";i:2;s:1:"7";i:3;s:2:"11";i:4;s:2:"14";i:5;s:1:"4";i:6;s:1:"2";i:7;s:1:"3";i:8;s:2:"10";i:9;s:1:"9";i:10;s:1:"6";}s:12:"button_title";s:14:"Update Profile";s:12:"button_class";s:0:"";s:10:"form_class";s:0:"";}s:15:"company_profile";a:5:{s:8:"form_key";s:15:"company_profile";s:6:"fields";a:4:{i:0;s:1:"4";i:1;s:1:"2";i:2;s:2:"11";i:3;s:1:"3";}s:12:"button_title";s:0:"";s:12:"button_class";s:0:"";s:10:"form_class";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1005, 'user_meta_settings', 'a:4:{s:7:"general";a:1:{s:12:"profile_page";s:4:"2235";}s:16:"_wp_http_referer";s:43:"/wp-admin/admin.php?page=user-meta-settings";s:5:"login";a:1:{s:14:"resetpass_page";s:4:"2199";}s:12:"registration";a:1:{s:23:"email_verification_page";s:4:"2199";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1977, 'aam_menu_role_administrator', 'a:60:{s:9:"index.php";s:1:"0";s:15:"update-core.php";s:1:"0";s:8:"edit.php";s:1:"0";s:12:"post-new.php";s:1:"0";s:31:"edit-tags.php?taxonomy=category";s:1:"0";s:31:"edit-tags.php?taxonomy=post_tag";s:1:"0";s:30:"edit.php?post_type=testimonial";s:1:"0";s:34:"post-new.php?post_type=testimonial";s:1:"0";s:65:"edit-tags.php?taxonomy=testimonial-category&post_type=testimonial";s:1:"0";s:10:"upload.php";s:1:"0";s:13:"media-new.php";s:1:"0";s:23:"edit.php?post_type=page";s:1:"0";s:27:"post-new.php?post_type=page";s:1:"0";s:17:"edit-comments.php";s:1:"0";s:30:"edit.php?post_type=job_listing";s:1:"0";s:34:"post-new.php?post_type=job_listing";s:1:"0";s:61:"edit-tags.php?taxonomy=job_listing_type&post_type=job_listing";s:1:"0";s:20:"job-manager-settings";s:1:"0";s:18:"job-manager-addons";s:1:"0";s:26:"edit.php?post_type=sidebar";s:1:"0";s:30:"post-new.php?post_type=sidebar";s:1:"0";s:10:"themes.php";s:1:"0";s:13:"customize.php";s:1:"0";s:11:"widgets.php";s:1:"0";s:13:"nav-menus.php";s:1:"0";s:13:"custom-header";s:1:"0";s:17:"custom-background";s:1:"0";s:16:"theme-editor.php";s:1:"0";s:11:"plugins.php";s:1:"0";s:18:"plugin-install.php";s:1:"0";s:17:"plugin-editor.php";s:1:"0";s:9:"users.php";s:1:"0";s:12:"user-new.php";s:1:"0";s:11:"profile.php";s:1:"0";s:26:"users-user-role-editor.php";s:1:"0";s:9:"tools.php";s:1:"0";s:10:"import.php";s:1:"0";s:10:"export.php";s:1:"0";s:19:"options-general.php";s:1:"0";s:19:"options-writing.php";s:1:"0";s:19:"options-reading.php";s:1:"0";s:22:"options-discussion.php";s:1:"0";s:17:"options-media.php";s:1:"0";s:21:"options-permalink.php";s:1:"0";s:29:"settings-user-role-editor.php";s:1:"0";s:8:"usermeta";s:1:"0";s:21:"user-meta-form-editor";s:1:"0";s:15:"user-meta-email";s:1:"0";s:23:"user-meta-import-export";s:1:"0";s:18:"user-meta-settings";s:1:"0";s:28:"edit.php?post_type=soliloquy";s:1:"0";s:32:"post-new.php?post_type=soliloquy";s:1:"0";s:14:"theme_my_login";s:1:"0";s:26:"theme_my_login_redirection";s:1:"0";s:13:"nm_repository";s:1:"0";s:13:"nm-repo-files";s:1:"0";s:3:"aam";s:1:"0";s:15:"aam-configpress";s:1:"0";s:7:"aam-ext";s:1:"0";s:10:"metaslider";s:1:"0";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (135, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392319510;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (136, 'current_theme', 'Jobify Child', 'yes') ; 
INSERT INTO `wp_options` VALUES (137, 'theme_mods_jobify-child', 'a:16:{i:0;b:0;s:16:"header_textcolor";s:5:"blank";s:16:"background_color";s:6:"ffffff";s:16:"background_image";s:68:"http://capstone.jonny.me/wp-content/uploads/2014/02/cream_pixels.png";s:17:"background_repeat";s:9:"no-repeat";s:21:"background_position_x";s:6:"center";s:21:"background_attachment";s:6:"scroll";s:10:"responsive";i:1;s:7:"primary";s:7:"#00418c";s:18:"jobify_cta_display";b:0;s:15:"jobify_cta_text";s:111:"<h2>Got a question?</h2>

We\'re here to help. Check out our FAQs, send us an email or call us at 1 800 555 5555";s:21:"jobify_cta_text_color";s:7:"#ffffff";s:27:"jobify_cta_background_color";s:7:"#3399cc";s:18:"nav_menu_locations";a:2:{s:7:"primary";i:13;s:13:"footer-social";i:12;}s:17:"header_image_data";O:8:"stdClass":5:{s:13:"attachment_id";i:2376;s:3:"url";s:68:"http://capstone.jonny.me/wp-content/uploads/2014/04/cropped-logo.png";s:13:"thumbnail_url";s:68:"http://capstone.jonny.me/wp-content/uploads/2014/04/cropped-logo.png";s:6:"height";i:71;s:5:"width";i:210;}s:12:"header_image";s:68:"http://capstone.jonny.me/wp-content/uploads/2014/04/cropped-logo.png";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (3015, 'job_listing_type_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (141, 'job_manager_installed_terms', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (142, 'wp_job_manager_version', '1.13.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (143, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, 'job_manager_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (147, 'job_manager_enable_categories', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (146, 'job_manager_hide_filled_positions', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (148, 'job_manager_enable_registration', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (149, 'job_manager_user_requires_account', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (150, 'job_manager_submission_requires_approval', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (151, 'job_manager_submission_duration', '30', 'yes') ; 
INSERT INTO `wp_options` VALUES (152, 'job_manager_submit_page_slug', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (153, 'woothemes-testimonials-version', '1.5.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (214, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (749, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (164, 'testimonial-category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (170, 'widget_jobify_widget_jobs', 'a:2:{i:2;a:3:{s:5:"title";s:11:"Recent Jobs";s:6:"number";i:5;s:9:"spotlight";s:1:"1";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (171, 'widget_jobify_widget_map', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (172, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (173, 'widget_jobify_widget_callout', 'a:3:{i:4;a:3:{s:11:"description";s:0:"";s:5:"title";s:10:"Learn More";s:10:"button-url";s:0:"";}i:5;a:3:{s:11:"description";s:0:"";s:5:"title";s:10:"Learn More";s:10:"button-url";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (174, 'widget_jobify_widget_testimonials', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (382, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (175, 'widget_jobify_widget_companies', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2789, 'simple-backup-settings', 'a:2:{s:15:"backup_settings";a:5:{s:18:"enable_file_backup";s:4:"true";s:16:"file_compression";s:4:".zip";s:16:"enable_db_backup";s:4:"true";s:14:"db_compression";s:4:".sql";s:24:"enable_ftp_backup_system";s:4:"true";}s:19:"ftp_server_settings";a:5:{s:19:"ftp_server_hostname";s:17:"capstone.jonny.me";s:15:"ftp_server_port";s:2:"21";s:19:"ftp_server_username";s:13:"lelo@jonny.me";s:19:"ftp_server_password";s:9:"Leloddfa7";s:20:"ftp_server_directory";s:13:"simple-backup";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3628, 'hmbkp_path', 'C:/wamp/www/ITWorks/wp-content/backupwordpress-3fd0145e8d-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (3627, 'hmbkp_default_path', 'C:/wamp/www/ITWorks/wp-content/backupwordpress-3fd0145e8d-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (2806, 'hmbkp_schedule_default-1', 'a:5:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1397257200;s:11:"max_backups";i:5;s:19:"HMBKP_Email_Service";a:1:{s:5:"email";s:0:"";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2807, 'hmbkp_schedule_default-2', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";i:1397358000;s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2808, 'hmbkp_plugin_version', '2.6.2', 'yes') ; 
INSERT INTO `wp_options` VALUES (237, 'theme_my_login', 'a:4:{s:10:"enable_css";b:1;s:11:"email_login";b:1;s:14:"active_modules";a:1:{i:0;s:41:"custom-redirection/custom-redirection.php";}s:7:"version";s:5:"6.3.8";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (236, 'cas_db_version', '2.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (677, 'widget_sslider_wid', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (246, 'theme_my_login_redirection', 'a:5:{s:13:"administrator";a:4:{s:10:"login_type";s:7:"default";s:9:"login_url";s:0:"";s:11:"logout_type";s:6:"custom";s:10:"logout_url";s:1:"/";}s:6:"editor";a:4:{s:10:"login_type";s:7:"default";s:9:"login_url";s:0:"";s:11:"logout_type";s:6:"custom";s:10:"logout_url";s:1:"/";}s:6:"author";a:4:{s:10:"login_type";s:7:"default";s:9:"login_url";s:0:"";s:11:"logout_type";s:6:"custom";s:10:"logout_url";s:1:"/";}s:11:"contributor";a:4:{s:10:"login_type";s:7:"default";s:9:"login_url";s:0:"";s:11:"logout_type";s:6:"custom";s:10:"logout_url";s:1:"/";}s:10:"subscriber";a:4:{s:10:"login_type";s:6:"custom";s:9:"login_url";s:1:"/";s:11:"logout_type";s:6:"custom";s:10:"logout_url";s:1:"/";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (258, 'user_role_editor', 'a:5:{s:17:"ure_caps_readable";i:0;s:24:"ure_show_deprecated_caps";i:0;s:19:"ure_hide_pro_banner";i:0;s:15:"show_admin_role";s:1:"1";s:19:"other_default_roles";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (259, 'wp_backup_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:19:"manage_job_listings";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (424, 'widget_nextendsmartslider2widget', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:12:"smartslider2";s:1:"1";s:18:"smartslider2tablet";s:2:"-1";s:17:"smartslider2phone";s:2:"-1";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1716, 'ml-slider_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (681, 'promotion_slider_options', 'a:9:{s:7:"version";s:5:"3.3.4";s:8:"start_on";s:5:"first";s:12:"auto_advance";s:12:"auto_advance";s:10:"time_delay";i:6;s:13:"display_title";s:4:"none";s:15:"display_excerpt";s:4:"none";s:14:"pause_on_hover";s:8:"no_pause";s:10:"load_js_in";s:4:"head";s:16:"default_img_size";s:4:"full";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (452, 'wpcf7', 'a:1:{s:7:"version";s:3:"3.9";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (690, 'widget_metaslider_widget', 'a:2:{i:2;a:2:{s:9:"slider_id";s:4:"2230";s:5:"title";s:16:"A Slider Example";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (676, 'smooth_slider_options', 'a:47:{s:8:"autostep";s:1:"1";s:2:"fx";s:10:"scrollHorz";s:5:"speed";s:1:"7";s:10:"transition";s:1:"5";s:8:"no_posts";s:1:"5";s:8:"bg_color";s:7:"#ffffff";s:6:"height";s:3:"250";s:5:"width";s:3:"450";s:6:"border";s:1:"1";s:7:"brcolor";s:7:"#999999";s:10:"goto_slide";s:1:"1";s:8:"navimg_w";s:2:"32";s:9:"navimg_ht";s:2:"32";s:10:"custom_nav";s:0:"";s:7:"support";s:1:"0";s:14:"allowable_tags";s:0:"";s:4:"more";s:9:"Read More";s:10:"user_level";s:17:"edit_others_posts";s:8:"noscript";s:210:"This page is having a slideshow that uses Javascript. Your browser either doesn\'t support Javascript or you have it turned off. To see this page as it is meant to appear please use a Javascript enabled browser.";s:9:"shortcode";s:1:"1";s:10:"stylesheet";s:7:"default";s:3:"css";s:0:"";s:10:"title_text";s:14:"Featured Posts";s:10:"title_from";s:1:"0";s:10:"title_font";s:26:"Arial,Helvetica,sans-serif";s:12:"title_fcolor";s:7:"#000000";s:11:"title_fsize";s:2:"20";s:12:"title_fstyle";s:4:"bold";s:11:"ptitle_font";s:26:"Arial,Helvetica,sans-serif";s:13:"ptitle_fcolor";s:7:"#000000";s:12:"ptitle_fsize";s:2:"14";s:13:"ptitle_fstyle";s:4:"bold";s:8:"img_pick";a:6:{i:0;s:1:"1";i:1;s:16:"slider_thumbnail";i:2;s:1:"1";i:3;s:1:"1";i:4;s:1:"1";i:5;s:1:"1";}s:9:"img_align";s:4:"none";s:4:"crop";s:1:"0";s:8:"img_size";s:1:"1";s:9:"img_width";s:3:"165";s:10:"img_height";s:3:"120";s:10:"img_border";s:1:"1";s:11:"img_brcolor";s:7:"#000000";s:12:"content_font";s:26:"Arial,Helvetica,sans-serif";s:14:"content_fcolor";s:7:"#333333";s:13:"content_fsize";s:2:"12";s:14:"content_fstyle";s:6:"normal";s:12:"content_from";s:7:"content";s:13:"content_limit";s:2:"20";s:13:"content_chars";s:3:"300";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (685, 'metaslider_systemcheck', 'a:2:{s:16:"wordPressVersion";b:0;s:12:"imageLibrary";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (722, 'theme_mods_jobify', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1393533668;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:4:{i:0;s:6:"text-3";i:1;s:6:"text-4";i:2;s:6:"text-5";i:3;s:23:"jobify_widget_callout-2";}s:22:"widget-area-front-page";a:3:{i:0;s:19:"metaslider_widget-2";i:1;s:20:"jobify_widget_jobs-2";i:2;s:21:"jobify_widget_stats-2";}s:18:"widget-area-footer";a:1:{i:0;s:6:"text-2";}s:25:"widget-area-price-options";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (373, 'IWG_RoleMan_CapList', 'a:52:{i:0;s:16:"activate_plugins";i:1;s:9:"add_users";i:2;s:12:"create_users";i:3;s:19:"delete_others_pages";i:4;s:19:"delete_others_posts";i:5;s:12:"delete_pages";i:6;s:14:"delete_plugins";i:7;s:12:"delete_posts";i:8;s:20:"delete_private_pages";i:9;s:20:"delete_private_posts";i:10;s:22:"delete_published_pages";i:11;s:22:"delete_published_posts";i:12;s:13:"delete_themes";i:13;s:12:"delete_users";i:14;s:14:"edit_dashboard";i:15;s:10:"edit_files";i:16;s:17:"edit_others_pages";i:17;s:17:"edit_others_posts";i:18;s:10:"edit_pages";i:19;s:12:"edit_plugins";i:20;s:10:"edit_posts";i:21;s:18:"edit_private_pages";i:22;s:18:"edit_private_posts";i:23;s:20:"edit_published_pages";i:24;s:20:"edit_published_posts";i:25;s:18:"edit_theme_options";i:26;s:11:"edit_themes";i:27;s:10:"edit_users";i:28;s:6:"export";i:29;s:6:"import";i:30;s:15:"install_plugins";i:31;s:14:"install_themes";i:43;s:10:"list_users";i:44;s:17:"manage_categories";i:45;s:19:"manage_job_listings";i:46;s:12:"manage_links";i:47;s:14:"manage_options";i:48;s:17:"moderate_comments";i:49;s:13:"promote_users";i:50;s:13:"publish_pages";i:51;s:13:"publish_posts";i:52;s:4:"read";i:53;s:18:"read_private_pages";i:54;s:18:"read_private_posts";i:55;s:12:"remove_users";i:56;s:13:"switch_themes";i:57;s:15:"unfiltered_html";i:58;s:17:"unfiltered_upload";i:59;s:11:"update_core";i:60;s:14:"update_plugins";i:61;s:13:"update_themes";i:62;s:12:"upload_files";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (374, 'IWG_RoleManager', 'a:2:{s:6:"status";s:10:"not active";s:7:"version";i:131587;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (379, 'aam_updated', '2.8', 'yes') ; 
INSERT INTO `wp_options` VALUES (380, 'widget_jobify_widget_slider', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (381, 'widget_jobify_widget_blog_posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (389, 'widget_jobify_widget_slider_hero', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (401, 'aam_visitor_activity', 'a:1:{i:1400260304;a:1:{s:6:"action";s:6:"logout";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (859, 'user_meta_history', 'a:1:{s:7:"version";a:4:{s:12:"last_version";s:5:"1.1.6";s:5:"1.1.4";a:1:{s:9:"timestamp";i:1393563595;}s:5:"1.1.5";a:1:{s:9:"timestamp";i:1396621886;}s:5:"1.1.6";a:1:{s:9:"timestamp";i:1407771187;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (870, 'nm_repo_db_version', '1.0.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (871, 'nm_repo_settings', 'a:6:{s:3:"bug";s:5:"false";s:27:"nm_repository_files_allowed";s:24:"*.pdf;*.docx;*.txt;*.doc";s:24:"nm_repository_size_limit";s:8:"15728640";s:24:"nm_repository_file_saved";s:10:"File saved";s:25:"nm_repository_dir_created";s:82:"Directory is created, you can now add documents relating to your Company and Jobs.";s:6:"action";s:16:"saveRepoSettings";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1978, 'aam_metabox_role_administrator', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1979, 'aam_event_role_administrator', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1980, 'aam_backup_role_administrator', 'a:1:{i:0;a:4:{s:4:"menu";a:0:{}s:10:"capability";a:65:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:19:"manage_job_listings";b:1;s:12:"manage_roles";b:1;s:13:"administrator";b:1;}s:7:"metabox";a:0:{}s:5:"event";a:0:{}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (2888, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (3621, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.2.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-3.9.2.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-3.9.2-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-3.9.2-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.2";s:7:"version";s:5:"3.9.2";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1407771176;s:15:"version_checked";s:5:"3.9.2";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3622, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1407771179;s:8:"response";a:9:{s:31:"advanced-access-manager/aam.php";O:8:"stdClass":6:{s:2:"id";s:5:"24416";s:4:"slug";s:23:"advanced-access-manager";s:6:"plugin";s:31:"advanced-access-manager/aam.php";s:11:"new_version";s:5:"2.8.1";s:3:"url";s:54:"https://wordpress.org/plugins/advanced-access-manager/";s:7:"package";s:72:"https://downloads.wordpress.org/plugin/advanced-access-manager.2.8.1.zip";}s:36:"contact-form-7/wp-contact-form-7.php";O:8:"stdClass":6:{s:2:"id";s:3:"790";s:4:"slug";s:14:"contact-form-7";s:6:"plugin";s:36:"contact-form-7/wp-contact-form-7.php";s:11:"new_version";s:5:"3.9.1";s:3:"url";s:45:"https://wordpress.org/plugins/contact-form-7/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/contact-form-7.3.9.1.zip";}s:49:"content-aware-sidebars/content-aware-sidebars.php";O:8:"stdClass":6:{s:2:"id";s:5:"24507";s:4:"slug";s:22:"content-aware-sidebars";s:6:"plugin";s:49:"content-aware-sidebars/content-aware-sidebars.php";s:11:"new_version";s:5:"2.4.1";s:3:"url";s:53:"https://wordpress.org/plugins/content-aware-sidebars/";s:7:"package";s:71:"https://downloads.wordpress.org/plugin/content-aware-sidebars.2.4.1.zip";}s:45:"custom-facebook-feed/custom-facebook-feed.php";O:8:"stdClass":6:{s:2:"id";s:5:"41442";s:4:"slug";s:20:"custom-facebook-feed";s:6:"plugin";s:45:"custom-facebook-feed/custom-facebook-feed.php";s:11:"new_version";s:5:"2.0.1";s:3:"url";s:51:"https://wordpress.org/plugins/custom-facebook-feed/";s:7:"package";s:69:"https://downloads.wordpress.org/plugin/custom-facebook-feed.2.0.1.zip";}s:23:"ml-slider/ml-slider.php";O:8:"stdClass":6:{s:2:"id";s:5:"38583";s:4:"slug";s:9:"ml-slider";s:6:"plugin";s:23:"ml-slider/ml-slider.php";s:11:"new_version";s:3:"3.0";s:3:"url";s:40:"https://wordpress.org/plugins/ml-slider/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/ml-slider.3.0.zip";}s:29:"nextgen-gallery/nggallery.php";O:8:"stdClass":6:{s:2:"id";s:3:"592";s:4:"slug";s:15:"nextgen-gallery";s:6:"plugin";s:29:"nextgen-gallery/nggallery.php";s:11:"new_version";s:9:"2.0.66.17";s:3:"url";s:46:"https://wordpress.org/plugins/nextgen-gallery/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/nextgen-gallery.zip";}s:29:"optin-revolution/optinrev.php";O:8:"stdClass":6:{s:2:"id";s:5:"35006";s:4:"slug";s:16:"optin-revolution";s:6:"plugin";s:29:"optin-revolution/optinrev.php";s:11:"new_version";s:5:"1.3.8";s:3:"url";s:47:"https://wordpress.org/plugins/optin-revolution/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/optin-revolution.1.3.8.zip";}s:31:"smooth-slider/smooth-slider.php";O:8:"stdClass":6:{s:2:"id";s:5:"10162";s:4:"slug";s:13:"smooth-slider";s:6:"plugin";s:31:"smooth-slider/smooth-slider.php";s:11:"new_version";s:5:"2.6.1";s:3:"url";s:44:"https://wordpress.org/plugins/smooth-slider/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/smooth-slider.2.6.1.zip";}s:37:"user-role-editor/user-role-editor.php";O:8:"stdClass":6:{s:2:"id";s:5:"13697";s:4:"slug";s:16:"user-role-editor";s:6:"plugin";s:37:"user-role-editor/user-role-editor.php";s:11:"new_version";s:6:"4.14.4";s:3:"url";s:47:"https://wordpress.org/plugins/user-role-editor/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/user-role-editor.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3623, 'duplicator_settings', 'a:9:{s:7:"version";s:5:"0.5.6";s:18:"uninstall_settings";b:1;s:15:"uninstall_files";b:1;s:16:"uninstall_tables";b:1;s:13:"package_debug";b:0;s:17:"package_mysqldump";b:0;s:22:"package_mysqldump_path";s:0:"";s:17:"package_zip_flush";b:0;s:20:"storage_htaccess_off";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (3624, 'job_manager_page_jobify_login_form', '1671', 'yes') ; 
INSERT INTO `wp_options` VALUES (3625, 'job_manager_page_jobify_register_form', '1943', 'yes') ; 
INSERT INTO `wp_options` VALUES (3626, 'job_manager_page_login_form', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (3629, 'job_manager_allowed_application_method', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (3630, 'job_manager_job_dashboard_page_slug', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (2859, 'exploitscanner', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (2860, 'exploitscanner_results', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (2861, 'exploitscanner_diff_cache', '0', 'no') ; 
INSERT INTO `wp_options` VALUES (3632, '_transient_doing_cron', '1407771216.9019420146942138671875', 'yes') ; 
INSERT INTO `wp_options` VALUES (3574, 'duplicator_version_plugin', '0.5.6', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=2174 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (940 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1217, 2188, '_wp_attached_file', '2014/02/cropped-LogoWhite-300x171.png') ; 
INSERT INTO `wp_postmeta` VALUES (1218, 2188, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1216, 25, '_edit_lock', '1397225157:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 7, '_company_description', 'With Next Big Sound, users track mentions of their favorite bands and musical artists across a variety of major music websites: music plays on Last.fm and MySpace, fans on Facebook, iLike, Last.fm, MySpace and Twitter, band page views on MySpace, and band page comments on MySpace. NBS calculates and graphs each of these statistics over time and compares the data to that of other similar bands. The site has been tracking this data since June 2009 for over 486,000 bands. Next Big Sound was recently named as one of the 10 best music startups of 2010 by Billboard Magazine and CEO Alex White was named to Billboard\'s 30 Under 30 executives to watch list.') ; 
INSERT INTO `wp_postmeta` VALUES (7, 7, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (8, 7, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (9, 7, '_application_deadline', '') ; 
INSERT INTO `wp_postmeta` VALUES (10, 7, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (11, 7, '_company_twitter', '@nextbigsound') ; 
INSERT INTO `wp_postmeta` VALUES (12, 7, 'geolocation_lat', '37.4241060') ; 
INSERT INTO `wp_postmeta` VALUES (13, 7, 'geolocation_state_long', 'California') ; 
INSERT INTO `wp_postmeta` VALUES (14, 7, 'geolocation_state_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (15, 7, 'geolocation_city', 'Stanford') ; 
INSERT INTO `wp_postmeta` VALUES (16, 7, 'geolocation_country_short', 'US') ; 
INSERT INTO `wp_postmeta` VALUES (17, 7, 'geolocation_formatted_address', 'Stanford, CA, USA') ; 
INSERT INTO `wp_postmeta` VALUES (18, 7, 'geolocation_long', '-122.1660756') ; 
INSERT INTO `wp_postmeta` VALUES (19, 7, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (20, 7, '_job_location', 'Standford') ; 
INSERT INTO `wp_postmeta` VALUES (21, 7, '_application', 'jobs@mailinator.com') ; 
INSERT INTO `wp_postmeta` VALUES (22, 7, '_company_name', 'Next Big Sound') ; 
INSERT INTO `wp_postmeta` VALUES (23, 7, '_company_website', 'https://www.nextbigsound.com/') ; 
INSERT INTO `wp_postmeta` VALUES (24, 7, '_company_tagline', 'Analytics and Insights for the Music Industry') ; 
INSERT INTO `wp_postmeta` VALUES (25, 7, 'geolocation_country_long', 'United States') ; 
INSERT INTO `wp_postmeta` VALUES (26, 7, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (27, 7, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (28, 7, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (29, 7, '_company_google', 'https://plus.google.com/112412034036668256825/posts') ; 
INSERT INTO `wp_postmeta` VALUES (30, 7, '_company_facebook', 'https://www.facebook.com/nextbigsound') ; 
INSERT INTO `wp_postmeta` VALUES (31, 8, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (32, 8, '_company_twitter', '@Amazon') ; 
INSERT INTO `wp_postmeta` VALUES (33, 8, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (34, 8, '_application_deadline', '') ; 
INSERT INTO `wp_postmeta` VALUES (35, 8, '_filled', '1') ; 
INSERT INTO `wp_postmeta` VALUES (36, 8, '_featured', '1') ; 
INSERT INTO `wp_postmeta` VALUES (37, 8, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (38, 8, 'geolocation_formatted_address', 'Sunset District, San Francisco, CA, USA') ; 
INSERT INTO `wp_postmeta` VALUES (39, 8, 'geolocation_long', '-122.4863492') ; 
INSERT INTO `wp_postmeta` VALUES (40, 8, 'geolocation_lat', '37.7467314') ; 
INSERT INTO `wp_postmeta` VALUES (41, 8, 'geolocation_state_long', 'California') ; 
INSERT INTO `wp_postmeta` VALUES (42, 8, 'geolocation_state_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (43, 8, 'geolocation_city', 'San Francisco') ; 
INSERT INTO `wp_postmeta` VALUES (44, 8, 'geolocation_country_long', 'United States') ; 
INSERT INTO `wp_postmeta` VALUES (45, 8, '_thumbnail_id', '1986') ; 
INSERT INTO `wp_postmeta` VALUES (46, 8, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (47, 8, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (48, 8, 'geolocation_country_short', 'US') ; 
INSERT INTO `wp_postmeta` VALUES (49, 8, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (50, 8, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (51, 8, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (52, 8, '_application', 'jobs@mailinator.com') ; 
INSERT INTO `wp_postmeta` VALUES (53, 8, '_job_location', 'Sunset District') ; 
INSERT INTO `wp_postmeta` VALUES (54, 8, '_company_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (55, 8, '_company_name', 'Amazon') ; 
INSERT INTO `wp_postmeta` VALUES (56, 8, '_company_website', 'http://amazon.com/') ; 
INSERT INTO `wp_postmeta` VALUES (1643, 2251, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1642, 2251, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1641, 2251, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1640, 2251, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1639, 2251, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1638, 2251, '_menu_item_object_id', '2249') ; 
INSERT INTO `wp_postmeta` VALUES (1637, 2251, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1636, 2251, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1635, 2249, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1634, 2249, '_edit_lock', '1403882842:1') ; 
INSERT INTO `wp_postmeta` VALUES (1795, 2301, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:449;s:4:"file";s:18:"2014/03/Slide1.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Slide1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"Slide1-300x118.png";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:19:"Slide1-1024x403.png";s:5:"width";i:1024;s:6:"height";i:403;s:9:"mime-type";s:9:"image/png";}s:12:"content-grid";a:4:{s:4:"file";s:18:"Slide1-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:18:"Slide1-115x115.png";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2152, 2428, 'geolocation_country_short', 'GB') ; 
INSERT INTO `wp_postmeta` VALUES (1632, 2248, '_nav_menu_role', 'in') ; 
INSERT INTO `wp_postmeta` VALUES (1602, 2245, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1601, 2245, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1600, 2245, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1599, 2245, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1598, 2245, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1597, 2245, '_menu_item_object_id', '1760') ; 
INSERT INTO `wp_postmeta` VALUES (1596, 2245, '_menu_item_menu_item_parent', '2251') ; 
INSERT INTO `wp_postmeta` VALUES (1595, 2245, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1629, 2248, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1593, 2244, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1592, 2244, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1591, 2244, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1590, 2244, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1589, 2244, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1588, 2244, '_menu_item_object_id', '1762') ; 
INSERT INTO `wp_postmeta` VALUES (1587, 2244, '_menu_item_menu_item_parent', '2251') ; 
INSERT INTO `wp_postmeta` VALUES (1586, 2244, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1633, 2249, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1584, 2243, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1583, 2243, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1582, 2243, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1581, 2243, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1580, 2243, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1579, 2243, '_menu_item_object_id', '1882') ; 
INSERT INTO `wp_postmeta` VALUES (1578, 2243, '_menu_item_menu_item_parent', '2251') ; 
INSERT INTO `wp_postmeta` VALUES (1577, 2243, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1628, 2248, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1575, 2242, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1574, 2242, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1573, 2242, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1572, 2242, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1571, 2242, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1570, 2242, '_menu_item_object_id', '2069') ; 
INSERT INTO `wp_postmeta` VALUES (1569, 2242, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1568, 2242, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (201, 1721, '_company_facebook', 'Dropbox') ; 
INSERT INTO `wp_postmeta` VALUES (202, 1721, 'geolocation_country_long', 'United States') ; 
INSERT INTO `wp_postmeta` VALUES (203, 1721, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (204, 1721, 'geolocation_state_long', 'California') ; 
INSERT INTO `wp_postmeta` VALUES (205, 1721, 'geolocation_state_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (206, 1721, 'geolocation_city', 'San Francisco') ; 
INSERT INTO `wp_postmeta` VALUES (207, 1721, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (208, 1721, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (209, 1721, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (210, 1721, '_wp_old_slug', 'dropbox') ; 
INSERT INTO `wp_postmeta` VALUES (211, 1721, '_company_google', '103316200298703443962') ; 
INSERT INTO `wp_postmeta` VALUES (212, 1721, 'geolocation_lat', '37.7777984') ; 
INSERT INTO `wp_postmeta` VALUES (213, 1721, 'geolocation_formatted_address', 'South of Market, San Francisco, CA, USA') ; 
INSERT INTO `wp_postmeta` VALUES (214, 1721, 'geolocation_country_short', 'US') ; 
INSERT INTO `wp_postmeta` VALUES (215, 1721, 'geolocation_long', '-122.4090937') ; 
INSERT INTO `wp_postmeta` VALUES (216, 1721, '_thumbnail_id', '1723') ; 
INSERT INTO `wp_postmeta` VALUES (217, 1721, '_job_location', 'South of Market') ; 
INSERT INTO `wp_postmeta` VALUES (218, 1721, '_company_name', 'DropBox') ; 
INSERT INTO `wp_postmeta` VALUES (219, 1721, '_application', 'jobs@sogetthis.com') ; 
INSERT INTO `wp_postmeta` VALUES (220, 1721, '_company_tagline', 'Simplify Your Life') ; 
INSERT INTO `wp_postmeta` VALUES (221, 1721, '_company_website', 'http://dropbox.com/') ; 
INSERT INTO `wp_postmeta` VALUES (222, 1721, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (223, 1721, '_company_twitter', 'Dropbox') ; 
INSERT INTO `wp_postmeta` VALUES (224, 1721, '_application_deadline', '') ; 
INSERT INTO `wp_postmeta` VALUES (225, 1721, '_filled', '1') ; 
INSERT INTO `wp_postmeta` VALUES (226, 1721, '_featured', '1') ; 
INSERT INTO `wp_postmeta` VALUES (227, 1721, '_company_description', 'Dropbox is a file hosting service operated by Dropbox, Inc., that offers cloud storage, file synchronization, and client software. Dropbox allows users to create a special folder on each of their computers, which Dropbox then synchronizes so that it appears to be the same folder (with the same contents) regardless of which computer is used to view it. Files placed in this folder also are accessible through a website and mobile phone applications.') ; 
INSERT INTO `wp_postmeta` VALUES (228, 1726, 'geolocation_lat', '37.4688273') ; 
INSERT INTO `wp_postmeta` VALUES (229, 1726, 'geolocation_state_long', 'California') ; 
INSERT INTO `wp_postmeta` VALUES (230, 1726, 'geolocation_state_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (231, 1726, 'geolocation_city', 'East Palo Alto') ; 
INSERT INTO `wp_postmeta` VALUES (232, 1726, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (233, 1726, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (234, 1726, 'geolocation_country_long', 'United States') ; 
INSERT INTO `wp_postmeta` VALUES (235, 1726, 'geolocation_country_short', 'US') ; 
INSERT INTO `wp_postmeta` VALUES (236, 1726, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (237, 1726, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (238, 1726, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (239, 1726, '_company_description', 'Disney Interactive Studios, Inc. (initially Walt Disney Computer Software, later Disney Interactive and Buena Vista Games, Inc.) is a Worldwide American video game company. It self-publishes and distributes multi-platform video games and interactive entertainment worldwide. Disney Interactive Studios is a subsidiary of Disney Interactive, thus a part of the The Walt Disney Company media conglomerate.') ; 
INSERT INTO `wp_postmeta` VALUES (240, 1726, 'geolocation_long', '-122.1410751') ; 
INSERT INTO `wp_postmeta` VALUES (241, 1726, 'geolocation_formatted_address', 'East Palo Alto, CA, USA') ; 
INSERT INTO `wp_postmeta` VALUES (242, 1726, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (243, 1726, '_job_location', 'East Palo Alto') ; 
INSERT INTO `wp_postmeta` VALUES (244, 1726, '_application', 'jobs@mailinator.com') ; 
INSERT INTO `wp_postmeta` VALUES (245, 1726, '_company_name', 'Disney Interactive') ; 
INSERT INTO `wp_postmeta` VALUES (246, 1726, '_company_website', 'http://games.disney.com/video-games') ; 
INSERT INTO `wp_postmeta` VALUES (247, 1726, '_filled', '1') ; 
INSERT INTO `wp_postmeta` VALUES (248, 1726, '_application_deadline', '') ; 
INSERT INTO `wp_postmeta` VALUES (249, 1726, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (250, 1726, '_company_twitter', '@Disney‎') ; 
INSERT INTO `wp_postmeta` VALUES (251, 1726, '_company_tagline', 'Where the Magic Lives') ; 
INSERT INTO `wp_postmeta` VALUES (252, 1726, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (253, 1728, '_job_location', 'Mission District') ; 
INSERT INTO `wp_postmeta` VALUES (254, 1728, '_company_name', 'Foursquare') ; 
INSERT INTO `wp_postmeta` VALUES (255, 1728, '_application', 'jobs@mailinator.com') ; 
INSERT INTO `wp_postmeta` VALUES (256, 1728, '_company_website', 'https://foursquare.com/') ; 
INSERT INTO `wp_postmeta` VALUES (257, 1728, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (258, 1728, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (259, 1728, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (260, 1728, 'geolocation_country_long', 'United States') ; 
INSERT INTO `wp_postmeta` VALUES (261, 1728, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (262, 1728, 'geolocation_country_short', 'US') ; 
INSERT INTO `wp_postmeta` VALUES (263, 1728, 'geolocation_state_long', 'California') ; 
INSERT INTO `wp_postmeta` VALUES (264, 1728, 'geolocation_state_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (265, 1728, 'geolocation_city', 'San Francisco') ; 
INSERT INTO `wp_postmeta` VALUES (266, 1728, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (267, 1728, 'geolocation_lat', '37.7598648') ; 
INSERT INTO `wp_postmeta` VALUES (268, 1728, 'geolocation_long', '-122.4147977') ; 
INSERT INTO `wp_postmeta` VALUES (269, 1728, '_company_description', 'Foursquare helps you and your friends make the most of where you are. We\'re a small but highly ambitious company with millions of users worldwide relying on foursquare to keep up with friends, discover what\'s nearby, save money and unlock deals. We’re also helping over a million registered merchants ranging from local businesses to global brands connect with their customers. To thrive as a member of team Foursquare, you must embrace our exciting work-hard, play-hard environment. We\'re not afraid to move fast and break things as we release, launch, iterate, update and announce -- sometimes all in the same day. We\'re a closely-knit team and, especially at the end of a long day over beers, we feel like we\'re inventing the future together.') ; 
INSERT INTO `wp_postmeta` VALUES (270, 1728, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (271, 1728, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (272, 1728, '_application_deadline', '') ; 
INSERT INTO `wp_postmeta` VALUES (273, 1728, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (274, 1728, '_company_twitter', '@Foursquare') ; 
INSERT INTO `wp_postmeta` VALUES (275, 1728, '_company_tagline', 'Unlock the city') ; 
INSERT INTO `wp_postmeta` VALUES (276, 1728, 'geolocation_formatted_address', 'Mission District, San Francisco, CA, USA') ; 
INSERT INTO `wp_postmeta` VALUES (277, 1728, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1627, 2248, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1566, 2241, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1565, 2241, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1564, 2241, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1563, 2241, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1562, 2241, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1561, 2241, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (1560, 2241, '_menu_item_menu_item_parent', '2347') ; 
INSERT INTO `wp_postmeta` VALUES (1559, 2241, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1622, 2248, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1623, 2248, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1557, 2240, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1556, 2240, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1555, 2240, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1554, 2240, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1553, 2240, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1552, 2240, '_menu_item_object_id', '1915') ; 
INSERT INTO `wp_postmeta` VALUES (1551, 2240, '_menu_item_menu_item_parent', '2347') ; 
INSERT INTO `wp_postmeta` VALUES (1550, 2240, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1791, 1728, '_edit_lock', '1394133759:1') ; 
INSERT INTO `wp_postmeta` VALUES (1790, 2300, '_nav_menu_role', 'out') ; 
INSERT INTO `wp_postmeta` VALUES (1625, 2248, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1626, 2248, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1945, 2364, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1944, 2364, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1943, 2364, '_menu_item_object_id', '2362') ; 
INSERT INTO `wp_postmeta` VALUES (1942, 2364, '_menu_item_menu_item_parent', '2251') ; 
INSERT INTO `wp_postmeta` VALUES (1941, 2364, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1940, 2362, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1624, 2248, '_menu_item_object_id', '2196') ; 
INSERT INTO `wp_postmeta` VALUES (1825, 2323, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:210;s:6:"height";i:53;s:4:"file";s:17:"2014/03/logo4.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"logo4-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:16:"logo4-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1824, 2323, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1823, 2323, '_wp_attached_file', '2014/03/logo4.png') ; 
INSERT INTO `wp_postmeta` VALUES (1822, 1882, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1522, 2236, 'ml-slider_settings', 'a:34:{s:4:"type";s:4:"flex";s:6:"random";s:4:"true";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:3:"980";s:6:"height";s:3:"420";s:3:"spw";s:1:"7";s:3:"sph";s:1:"5";s:5:"delay";s:4:"3000";s:6:"sDelay";s:2:"30";s:7:"opacity";s:3:"0.7";s:10:"titleSpeed";s:3:"500";s:6:"effect";s:4:"fade";s:10:"navigation";s:4:"true";s:5:"links";s:4:"true";s:10:"hoverPause";s:4:"true";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"600";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";s:2:"15";s:6:"center";s:4:"true";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:9:"fullWidth";s:5:"false";s:10:"noConflict";s:5:"false";s:12:"smoothHeight";s:5:"false";}') ; 
INSERT INTO `wp_postmeta` VALUES (1984, 2378, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1985, 2378, '_wp_attachment_backup_sizes', 'a:4:{s:16:"resized-1140x450";a:5:{s:4:"path";s:97:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/picjumbo.com_IMG_4893-1140x450.jpg";s:4:"file";s:34:"picjumbo.com_IMG_4893-1140x450.jpg";s:5:"width";i:1140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-2140x450";a:5:{s:4:"path";s:97:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/picjumbo.com_IMG_4893-2140x450.jpg";s:4:"file";s:34:"picjumbo.com_IMG_4893-2140x450.jpg";s:5:"width";i:2140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-3140x450";a:5:{s:4:"path";s:97:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/picjumbo.com_IMG_4893-3140x450.jpg";s:4:"file";s:34:"picjumbo.com_IMG_4893-3140x450.jpg";s:5:"width";i:3140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-2140x550";a:5:{s:4:"path";s:97:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/picjumbo.com_IMG_4893-2140x550.jpg";s:4:"file";s:34:"picjumbo.com_IMG_4893-2140x550.jpg";s:5:"width";i:2140;s:6:"height";i:550;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1986, 2379, '_wp_attached_file', '2014/04/werocks.png') ; 
INSERT INTO `wp_postmeta` VALUES (1987, 2379, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:450;s:4:"file";s:19:"2014/04/werocks.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"werocks-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:19:"werocks-300x118.png";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:20:"werocks-1024x404.png";s:5:"width";i:1024;s:6:"height";i:404;s:9:"mime-type";s:9:"image/png";}s:12:"content-grid";a:4:{s:4:"file";s:19:"werocks-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:19:"werocks-115x115.png";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1988, 2379, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1989, 2377, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (1990, 2378, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (1991, 2379, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (2000, 2387, '_wp_attached_file', '2014/04/securityYellow.gif') ; 
INSERT INTO `wp_postmeta` VALUES (2001, 2387, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:26:"2014/04/securityYellow.gif";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"securityYellow-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:26:"securityYellow-300x300.gif";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/gif";}s:12:"content-grid";a:4:{s:4:"file";s:26:"securityYellow-400x200.gif";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/gif";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:26:"securityYellow-115x115.gif";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1887, 2337, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1888, 2337, '_wp_attachment_backup_sizes', 'a:6:{s:16:"resized-1140x450";a:5:{s:4:"path";s:84:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/aircraft-1140x450.jpg";s:4:"file";s:21:"aircraft-1140x450.jpg";s:5:"width";i:1140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-2140x450";a:5:{s:4:"path";s:84:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/aircraft-2140x450.jpg";s:4:"file";s:21:"aircraft-2140x450.jpg";s:5:"width";i:2140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-2560x366";a:5:{s:4:"path";s:84:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/aircraft-2560x366.jpg";s:4:"file";s:21:"aircraft-2560x366.jpg";s:5:"width";i:2560;s:6:"height";i:366;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-2140x550";a:5:{s:4:"path";s:84:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/aircraft-2140x550.jpg";s:4:"file";s:21:"aircraft-2140x550.jpg";s:5:"width";i:2140;s:6:"height";i:550;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-1134x325";a:5:{s:4:"path";s:84:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/aircraft-1134x325.jpg";s:4:"file";s:21:"aircraft-1134x325.jpg";s:5:"width";i:1134;s:6:"height";i:325;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-1140x325";a:5:{s:4:"path";s:84:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/aircraft-1140x325.jpg";s:4:"file";s:21:"aircraft-1140x325.jpg";s:5:"width";i:1140;s:6:"height";i:325;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1889, 2337, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (1890, 2146, '_edit_lock', '1403888098:1') ; 
INSERT INTO `wp_postmeta` VALUES (1891, 2338, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1892, 2338, '_edit_lock', '1397760524:1') ; 
INSERT INTO `wp_postmeta` VALUES (1893, 2338, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1864, 2333, '_wp_attached_file', '2014/03/connect.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1865, 2333, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:900;s:4:"file";s:19:"2014/03/connect.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"connect-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"connect-300x168.jpg";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"connect-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:12:"content-grid";a:4:{s:4:"file";s:19:"connect-400x200.jpg";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:20:"content-job-featured";a:4:{s:4:"file";s:20:"connect-1350x525.jpg";s:5:"width";i:1350;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:19:"connect-115x115.jpg";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1868, 2333, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (1885, 2337, '_wp_attached_file', '2014/03/aircraft.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1886, 2337, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2560;s:6:"height";i:1440;s:4:"file";s:20:"2014/03/aircraft.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"aircraft-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"aircraft-300x168.jpg";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"aircraft-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:12:"content-grid";a:4:{s:4:"file";s:20:"aircraft-400x200.jpg";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:20:"content-job-featured";a:4:{s:4:"file";s:21:"aircraft-1350x525.jpg";s:5:"width";i:1350;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:20:"aircraft-115x115.jpg";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1447, 2225, '_edit_lock', '1394205988:1') ; 
INSERT INTO `wp_postmeta` VALUES (1446, 2225, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1445, 2224, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (1444, 2224, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (1443, 2224, '_company_description', '<p>Dummy data.  My company is the best!!!!!</p>') ; 
INSERT INTO `wp_postmeta` VALUES (1442, 2224, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1441, 2224, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1440, 2224, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (1439, 2224, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (1438, 2224, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (1437, 2224, '_company_website', '') ; 
INSERT INTO `wp_postmeta` VALUES (1436, 2224, '_company_name', 'Titz\'n Glitz') ; 
INSERT INTO `wp_postmeta` VALUES (1435, 2224, '_job_location', 'Dummy Location') ; 
INSERT INTO `wp_postmeta` VALUES (1434, 2224, '_application', 'dummy@email.com') ; 
INSERT INTO `wp_postmeta` VALUES (1433, 2223, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (1432, 2223, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (1431, 2223, '_messages', 'a:6:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";}') ; 
INSERT INTO `wp_postmeta` VALUES (1430, 2223, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:104:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1429, 2223, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:162:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)";s:9:"recipient";s:26:"maceachern.jonny@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1428, 2223, '_form', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (1700, 2260, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1426, 2218, '_soliloquy_settings', 'a:6:{s:5:"width";i:2000;s:6:"height";i:1000;s:10:"transition";s:4:"fade";s:5:"speed";i:7000;s:8:"duration";i:600;s:9:"preloader";i:1;}') ; 
INSERT INTO `wp_postmeta` VALUES (1425, 2218, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1858, 2332, 'ml-slider_settings', 'a:34:{s:4:"type";s:4:"flex";s:6:"random";s:5:"false";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:4:"1140";s:6:"height";s:3:"450";s:3:"spw";s:1:"7";s:3:"sph";s:1:"5";s:5:"delay";s:4:"3000";s:6:"sDelay";s:2:"30";s:7:"opacity";s:3:"0.7";s:10:"titleSpeed";s:3:"500";s:6:"effect";s:5:"slide";s:10:"navigation";s:4:"true";s:5:"links";s:4:"true";s:10:"hoverPause";s:4:"true";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"500";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";s:2:"15";s:6:"center";s:4:"true";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:9:"fullWidth";s:5:"false";s:10:"noConflict";s:5:"false";s:12:"smoothHeight";s:5:"false";}') ; 
INSERT INTO `wp_postmeta` VALUES (1866, 2333, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1867, 2333, '_wp_attachment_backup_sizes', 'a:6:{s:16:"resized-1140x450";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/connect-1140x450.jpg";s:4:"file";s:20:"connect-1140x450.jpg";s:5:"width";i:1140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-1600x336";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/connect-1600x336.jpg";s:4:"file";s:20:"connect-1600x336.jpg";s:5:"width";i:1600;s:6:"height";i:336;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-1600x229";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/connect-1600x229.jpg";s:4:"file";s:20:"connect-1600x229.jpg";s:5:"width";i:1600;s:6:"height";i:229;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-1600x411";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/connect-1600x411.jpg";s:4:"file";s:20:"connect-1600x411.jpg";s:5:"width";i:1600;s:6:"height";i:411;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-1134x325";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/connect-1134x325.jpg";s:4:"file";s:20:"connect-1134x325.jpg";s:5:"width";i:1134;s:6:"height";i:325;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-1140x325";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/connect-1140x325.jpg";s:4:"file";s:20:"connect-1140x325.jpg";s:5:"width";i:1140;s:6:"height";i:325;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1855, 2217, '_edit_lock', '1395255123:1') ; 
INSERT INTO `wp_postmeta` VALUES (1414, 2218, '_edit_lock', '1393564734:1') ; 
INSERT INTO `wp_postmeta` VALUES (1413, 2217, '_wp_attachment_is_custom_background', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1412, 2217, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:160;s:6:"height";i:160;s:4:"file";s:24:"2014/02/cream_pixels.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"cream_pixels-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:24:"cream_pixels-115x115.png";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1411, 2217, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (1410, 2217, '_wp_attached_file', '2014/02/cream_pixels.png') ; 
INSERT INTO `wp_postmeta` VALUES (2002, 2382, '_wp_attachment_image_alt', 'Mobile') ; 
INSERT INTO `wp_postmeta` VALUES (2003, 2383, '_wp_attachment_image_alt', 'Business Solutions') ; 
INSERT INTO `wp_postmeta` VALUES (2004, 2384, '_wp_attachment_image_alt', 'Networking Opportunities') ; 
INSERT INTO `wp_postmeta` VALUES (2005, 2386, '_wp_attachment_image_alt', 'Customizable Profile') ; 
INSERT INTO `wp_postmeta` VALUES (2006, 2387, '_wp_attachment_image_alt', 'Secured') ; 
INSERT INTO `wp_postmeta` VALUES (2007, 2389, '_wp_attached_file', '2014/04/itjobs.png') ; 
INSERT INTO `wp_postmeta` VALUES (2008, 2389, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:450;s:4:"file";s:18:"2014/04/itjobs.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"itjobs-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"itjobs-300x118.png";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:19:"itjobs-1024x404.png";s:5:"width";i:1024;s:6:"height";i:404;s:9:"mime-type";s:9:"image/png";}s:12:"content-grid";a:4:{s:4:"file";s:18:"itjobs-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:18:"itjobs-115x115.png";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1521, 2235, '_tml_action', 'profile') ; 
INSERT INTO `wp_postmeta` VALUES (1500, 2230, 'ml-slider_settings', 'a:35:{s:4:"type";s:4:"nivo";s:6:"random";s:5:"false";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:4:"1140";s:6:"height";s:3:"450";s:3:"spw";s:1:"7";s:3:"sph";s:1:"5";s:5:"delay";s:4:"3000";s:6:"sDelay";s:2:"30";s:7:"opacity";s:3:"0.7";s:10:"titleSpeed";s:3:"500";s:6:"effect";s:4:"fade";s:10:"navigation";s:4:"true";s:5:"links";s:4:"true";s:10:"hoverPause";s:4:"true";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"500";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";s:2:"15";s:6:"center";s:4:"true";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:9:"fullWidth";s:5:"false";s:10:"noConflict";s:5:"false";s:12:"smoothHeight";s:5:"false";s:14:"carouselMargin";s:1:"5";}') ; 
INSERT INTO `wp_postmeta` VALUES (1794, 2301, '_wp_attached_file', '2014/03/Slide1.png') ; 
INSERT INTO `wp_postmeta` VALUES (1498, 703, '_edit_lock', '1403889743:1') ; 
INSERT INTO `wp_postmeta` VALUES (1970, 2375, '_wp_attached_file', '2014/03/geeksBlur.png') ; 
INSERT INTO `wp_postmeta` VALUES (1971, 2375, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:450;s:4:"file";s:21:"2014/03/geeksBlur.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"geeksBlur-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:21:"geeksBlur-300x118.png";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:22:"geeksBlur-1024x404.png";s:5:"width";i:1024;s:6:"height";i:404;s:9:"mime-type";s:9:"image/png";}s:12:"content-grid";a:4:{s:4:"file";s:21:"geeksBlur-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:21:"geeksBlur-115x115.png";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1977, 2376, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1978, 2377, '_wp_attached_file', '2014/04/DeathtoStock_Wired2.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1979, 2377, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:5300;s:6:"height";i:3534;s:4:"file";s:31:"2014/04/DeathtoStock_Wired2.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"DeathtoStock_Wired2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"DeathtoStock_Wired2-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"DeathtoStock_Wired2-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"content-grid";a:4:{s:4:"file";s:31:"DeathtoStock_Wired2-400x200.jpg";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:20:"content-job-featured";a:4:{s:4:"file";s:32:"DeathtoStock_Wired2-1350x525.jpg";s:5:"width";i:1350;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:31:"DeathtoStock_Wired2-115x115.jpg";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2;s:6:"credit";s:0:"";s:6:"camera";s:12:"Canon EOS 6D";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1380635140;s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"35";s:3:"iso";s:3:"320";s:13:"shutter_speed";s:5:"0.008";s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (800, 6, '_company_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (801, 6, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (802, 6, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (803, 6, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (804, 6, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (805, 6, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (806, 6, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (807, 6, 'geolocation_city', 'Sunnyvale') ; 
INSERT INTO `wp_postmeta` VALUES (808, 6, 'geolocation_state_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (809, 6, 'geolocation_state_long', 'California') ; 
INSERT INTO `wp_postmeta` VALUES (810, 6, 'geolocation_lat', '37.3688300') ; 
INSERT INTO `wp_postmeta` VALUES (811, 6, 'geolocation_long', '-122.0363496') ; 
INSERT INTO `wp_postmeta` VALUES (812, 6, 'geolocation_formatted_address', 'Sunnyvale, CA, USA') ; 
INSERT INTO `wp_postmeta` VALUES (813, 6, 'geolocation_country_long', 'United States') ; 
INSERT INTO `wp_postmeta` VALUES (814, 6, '_application_deadline', '') ; 
INSERT INTO `wp_postmeta` VALUES (815, 6, 'geolocation_country_short', 'US') ; 
INSERT INTO `wp_postmeta` VALUES (816, 6, '_job_location', 'Sunnyvale') ; 
INSERT INTO `wp_postmeta` VALUES (817, 6, '_application', 'jobs@mailinator.com') ; 
INSERT INTO `wp_postmeta` VALUES (818, 6, '_company_name', 'GE') ; 
INSERT INTO `wp_postmeta` VALUES (819, 6, '_company_website', 'http://www.ge.com/') ; 
INSERT INTO `wp_postmeta` VALUES (820, 6, '_company_tagline', 'GE imagination at work') ; 
INSERT INTO `wp_postmeta` VALUES (821, 6, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (822, 6, '_company_logo', 'http://demo.astoundify.com/jobify-darker/wp-content/uploads/sites/16/2014/01/GE-Logo.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (823, 6, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (824, 6, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (825, 6, 'geolocation_postcode', '78566') ; 
INSERT INTO `wp_postmeta` VALUES (826, 2146, '_company_facebook', 'https://www.facebook.com/optimizely‎') ; 
INSERT INTO `wp_postmeta` VALUES (827, 2146, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (828, 2146, 'geolocation_country_long', 'United States') ; 
INSERT INTO `wp_postmeta` VALUES (829, 2146, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (830, 2146, '_company_description', 'Optimizely was founded by two former Google product managers, Dan Siroker and Pete Koomen. Dan served as the Director of Analytics during the Obama 2008 presidential campaign. While there, his team relied on the use of A/B and multivariate testing to maximize e-mail sign-ups, volunteers, and donations to raise more than $100 million in additional revenue for the campaign.

But optimization was hard — you needed technical skills and know-how to run even the simplest of tests. After the campaign, Siroker teamed up with Koomen to create a world-class optimization platform that was easy to use in an effort to provide a platform for businesses to be able to conceive and run experiments that helped them make better data-driven decisions.

Since completing YCombinator in the winter of 2010, Optimizely has seen strong and growing demand.') ; 
INSERT INTO `wp_postmeta` VALUES (831, 2146, '_application_deadline', '') ; 
INSERT INTO `wp_postmeta` VALUES (832, 2146, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (833, 2146, '_filled', '1') ; 
INSERT INTO `wp_postmeta` VALUES (834, 2146, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (835, 2146, '_company_twitter', 'Optimizely') ; 
INSERT INTO `wp_postmeta` VALUES (836, 2146, '_company_tagline', 'A/B testing software you\'ll actually use') ; 
INSERT INTO `wp_postmeta` VALUES (837, 2146, '_company_website', 'https://www.optimizely.com/') ; 
INSERT INTO `wp_postmeta` VALUES (838, 2146, '_company_name', 'Optimizely') ; 
INSERT INTO `wp_postmeta` VALUES (839, 2146, '_application', 'jobs@mailinator.com') ; 
INSERT INTO `wp_postmeta` VALUES (840, 2146, 'geolocation_city', 'San Francisco') ; 
INSERT INTO `wp_postmeta` VALUES (841, 2146, 'geolocation_formatted_address', 'The Castro, San Francisco, CA, USA') ; 
INSERT INTO `wp_postmeta` VALUES (842, 2146, 'geolocation_long', '-122.4350043') ; 
INSERT INTO `wp_postmeta` VALUES (843, 2146, 'geolocation_lat', '37.7609082') ; 
INSERT INTO `wp_postmeta` VALUES (844, 2146, 'geolocation_state_long', 'California') ; 
INSERT INTO `wp_postmeta` VALUES (845, 2146, 'geolocation_state_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (846, 2146, 'geolocation_country_short', 'US') ; 
INSERT INTO `wp_postmeta` VALUES (847, 2146, '_job_location', 'The Castro') ; 
INSERT INTO `wp_postmeta` VALUES (848, 2146, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (2151, 2428, 'geolocation_state_long', 'England') ; 
INSERT INTO `wp_postmeta` VALUES (2150, 2428, 'geolocation_state_short', 'England') ; 
INSERT INTO `wp_postmeta` VALUES (2149, 2428, 'geolocation_city', 'Halifax') ; 
INSERT INTO `wp_postmeta` VALUES (2148, 2428, 'geolocation_formatted_address', 'Halifax, West Yorkshire, UK') ; 
INSERT INTO `wp_postmeta` VALUES (2147, 2428, 'geolocation_long', '-1.8575400') ; 
INSERT INTO `wp_postmeta` VALUES (2146, 2428, 'geolocation_lat', '53.7270200') ; 
INSERT INTO `wp_postmeta` VALUES (2145, 2428, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (2144, 2428, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (2143, 2428, '_company_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (2142, 2428, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2137, 2428, '_company_website', '') ; 
INSERT INTO `wp_postmeta` VALUES (2138, 2428, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (2139, 2428, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (2140, 2428, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (2141, 2428, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2136, 2428, '_company_name', 'Fake company') ; 
INSERT INTO `wp_postmeta` VALUES (2135, 2428, '_job_location', 'Halifax') ; 
INSERT INTO `wp_postmeta` VALUES (2134, 2428, '_application', 'fakecompany.com') ; 
INSERT INTO `wp_postmeta` VALUES (2133, 2427, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (2132, 2427, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2131, 2427, 'geolocation_country_long', 'United Kingdom') ; 
INSERT INTO `wp_postmeta` VALUES (2115, 2427, '_company_website', '') ; 
INSERT INTO `wp_postmeta` VALUES (2116, 2427, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (2117, 2427, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (2118, 2427, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (2119, 2427, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2120, 2427, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2121, 2427, '_company_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (2122, 2427, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (2123, 2427, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (2124, 2427, 'geolocation_lat', '53.7270200') ; 
INSERT INTO `wp_postmeta` VALUES (2125, 2427, 'geolocation_long', '-1.8575400') ; 
INSERT INTO `wp_postmeta` VALUES (2126, 2427, 'geolocation_formatted_address', 'Halifax, West Yorkshire, UK') ; 
INSERT INTO `wp_postmeta` VALUES (2127, 2427, 'geolocation_city', 'Halifax') ; 
INSERT INTO `wp_postmeta` VALUES (2128, 2427, 'geolocation_state_short', 'England') ; 
INSERT INTO `wp_postmeta` VALUES (2129, 2427, 'geolocation_state_long', 'England') ; 
INSERT INTO `wp_postmeta` VALUES (2130, 2427, 'geolocation_country_short', 'GB') ; 
INSERT INTO `wp_postmeta` VALUES (918, 2168, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (919, 2168, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (920, 2168, '_menu_item_object_id', '2168') ; 
INSERT INTO `wp_postmeta` VALUES (921, 2168, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (922, 2168, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (923, 2168, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (924, 2168, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (925, 2168, '_menu_item_url', 'http://facebook.com/astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (926, 2169, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (927, 2169, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (928, 2169, '_menu_item_object_id', '2169') ; 
INSERT INTO `wp_postmeta` VALUES (929, 2169, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (930, 2169, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (931, 2169, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (932, 2169, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (933, 2169, '_menu_item_url', 'https://vimeo.com/astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (934, 2170, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (935, 2170, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (936, 2170, '_menu_item_object_id', '2170') ; 
INSERT INTO `wp_postmeta` VALUES (937, 2170, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (938, 2170, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (939, 2170, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (940, 2170, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (941, 2170, '_menu_item_url', 'http://www.linkedin.com') ; 
INSERT INTO `wp_postmeta` VALUES (942, 2171, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (943, 2171, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (944, 2171, '_menu_item_object_id', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (945, 2171, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (946, 2171, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (947, 2171, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (948, 2171, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (949, 2171, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (950, 2172, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (951, 2172, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (952, 2172, '_menu_item_object_id', '2172') ; 
INSERT INTO `wp_postmeta` VALUES (953, 2172, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (954, 2172, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (955, 2172, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (956, 2172, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (957, 2172, '_menu_item_url', 'http://twitter.com/astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (958, 2173, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (959, 2173, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (960, 2173, '_menu_item_object_id', '2173') ; 
INSERT INTO `wp_postmeta` VALUES (961, 2173, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (962, 2173, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (963, 2173, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (964, 2173, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (965, 2173, '_menu_item_url', 'https://plus.google.com/') ; 
INSERT INTO `wp_postmeta` VALUES (966, 2174, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (967, 2174, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (968, 2174, '_menu_item_object_id', '2174') ; 
INSERT INTO `wp_postmeta` VALUES (969, 2174, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (970, 2174, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (971, 2174, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (972, 2174, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (973, 2174, '_menu_item_url', 'http://instagram.com/') ; 
INSERT INTO `wp_postmeta` VALUES (974, 2175, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (975, 2175, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (976, 2175, '_menu_item_object_id', '2175') ; 
INSERT INTO `wp_postmeta` VALUES (977, 2175, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (978, 2175, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (979, 2175, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (980, 2175, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (981, 2175, '_menu_item_url', 'https://pinterest.com/') ; 
INSERT INTO `wp_postmeta` VALUES (982, 14, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (983, 14, 'rcp_subscription_level', 'a:3:{i:0;s:1:"1";i:1;s:1:"2";i:2;s:1:"3";}') ; 
INSERT INTO `wp_postmeta` VALUES (984, 14, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (985, 14, '_is_paid', '1') ; 
INSERT INTO `wp_postmeta` VALUES (986, 14, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2111, 1882, '_sol_slider_data', 'a:2:{s:2:"id";i:1882;s:6:"config";a:12:{s:4:"type";s:7:"default";s:12:"slider_theme";s:4:"base";s:12:"slider_width";i:960;s:13:"slider_height";i:300;s:10:"transition";s:4:"fade";s:8:"duration";i:5000;s:5:"speed";i:400;s:6:"gutter";i:20;s:6:"slider";i:1;s:7:"classes";a:1:{i:0;s:0:"";}s:5:"title";s:0:"";s:4:"slug";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2114, 2427, '_company_name', 'Scarfone Incorporated') ; 
INSERT INTO `wp_postmeta` VALUES (2032, 25, '_sol_slider_data', 'a:2:{s:2:"id";i:25;s:6:"config";a:12:{s:4:"type";s:7:"default";s:12:"slider_theme";s:4:"base";s:12:"slider_width";i:960;s:13:"slider_height";i:300;s:10:"transition";s:4:"fade";s:8:"duration";i:5000;s:5:"speed";i:400;s:6:"gutter";i:20;s:6:"slider";i:1;s:7:"classes";a:1:{i:0;s:0:"";}s:5:"title";s:0:"";s:4:"slug";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (990, 25, '_wp_page_template', 'page-templates/jobify.php') ; 
INSERT INTO `wp_postmeta` VALUES (991, 703, '_thumbnail_id', '1732') ; 
INSERT INTO `wp_postmeta` VALUES (992, 703, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (993, 1671, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (994, 1673, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (995, 1673, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (996, 1673, '_wp_page_template', 'page-templates/pricing.php') ; 
INSERT INTO `wp_postmeta` VALUES (997, 1719, '_wp_page_template', 'page-templates/testimonials.php') ; 
INSERT INTO `wp_postmeta` VALUES (998, 1760, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (999, 1762, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1000, 1765, '_wp_page_template', 'page-templates/pricing.php') ; 
INSERT INTO `wp_postmeta` VALUES (1001, 1882, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1002, 1882, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1003, 1882, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1004, 1915, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1005, 1915, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1006, 1915, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1007, 2176, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1008, 2176, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1009, 2176, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (1010, 2176, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1011, 2176, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1012, 2176, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1013, 2176, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1014, 2176, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1015, 2177, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1016, 2177, '_menu_item_menu_item_parent', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (1017, 2177, '_menu_item_object_id', '1719') ; 
INSERT INTO `wp_postmeta` VALUES (1018, 2177, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1019, 2177, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1020, 2177, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1021, 2177, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1022, 2177, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1023, 2178, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1024, 2178, '_menu_item_menu_item_parent', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (1025, 2178, '_menu_item_object_id', '1762') ; 
INSERT INTO `wp_postmeta` VALUES (1026, 2178, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1027, 2178, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1028, 2178, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1029, 2178, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1030, 2178, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1031, 2179, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1032, 2179, '_menu_item_menu_item_parent', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (1033, 2179, '_menu_item_object_id', '1760') ; 
INSERT INTO `wp_postmeta` VALUES (1034, 2179, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1035, 2179, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1036, 2179, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1037, 2179, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1038, 2179, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1039, 2180, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1040, 2180, '_menu_item_menu_item_parent', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (1041, 2180, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (1042, 2180, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1043, 2180, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1044, 2180, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1045, 2180, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1046, 2180, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (2173, 2433, '_menu_item_orphaned', '1404302975') ; 
INSERT INTO `wp_postmeta` VALUES (2172, 2433, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (2171, 2433, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (2170, 2433, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1055, 2182, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1056, 2182, '_menu_item_menu_item_parent', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (1057, 2182, '_menu_item_object_id', '1882') ; 
INSERT INTO `wp_postmeta` VALUES (1058, 2182, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1059, 2182, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1060, 2182, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1061, 2182, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1062, 2182, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1063, 2183, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1064, 2183, '_menu_item_menu_item_parent', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (1065, 2183, '_menu_item_object_id', '1915') ; 
INSERT INTO `wp_postmeta` VALUES (1066, 2183, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1067, 2183, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1068, 2183, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1069, 2183, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1070, 2183, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1071, 1668, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:7:"animate";i:1;s:5:"speed";i:5030;s:8:"duration";i:360;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1072, 1668, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1073, 1668, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1074, 1668, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:7:"animate";i:1;s:5:"speed";i:5030;s:8:"duration";i:360;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1075, 1668, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1076, 1668, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1077, 1668, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:7:"animate";i:1;s:5:"speed";i:5030;s:8:"duration";i:360;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1078, 1668, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1079, 1668, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1080, 1668, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:7:"animate";i:1;s:5:"speed";i:5030;s:8:"duration";i:360;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1081, 1668, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1082, 1668, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1083, 1668, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:7:"animate";i:1;s:5:"speed";i:5030;s:8:"duration";i:360;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1084, 1668, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1085, 1668, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1086, 1668, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:7:"animate";i:1;s:5:"speed";i:5030;s:8:"duration";i:360;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1087, 1668, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1088, 1668, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1089, 1684, '_thumbnail_id', '2016') ; 
INSERT INTO `wp_postmeta` VALUES (1090, 1684, '_wp_old_slug', 'kelloggs') ; 
INSERT INTO `wp_postmeta` VALUES (1091, 1684, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1092, 1684, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1093, 1684, '_url', 'http://themeforest.net/item/jobify-job-board-wordpress-theme/5247604?ref=Astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (1094, 1684, '_wp_old_slug', 'marketify') ; 
INSERT INTO `wp_postmeta` VALUES (1095, 1687, '_thumbnail_id', '2015') ; 
INSERT INTO `wp_postmeta` VALUES (1096, 1687, '_wp_old_slug', 'wwf') ; 
INSERT INTO `wp_postmeta` VALUES (1097, 1687, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1098, 1687, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1099, 1687, '_url', 'http://themeforest.net/user/Astoundify/portfolio?ref=Astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (1100, 1689, '_thumbnail_id', '2019') ; 
INSERT INTO `wp_postmeta` VALUES (1101, 1689, '_wp_old_slug', 'pinterest') ; 
INSERT INTO `wp_postmeta` VALUES (1102, 1689, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1103, 1689, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1104, 1689, '_url', 'http://themeforest.net/item/fundify-the-wordpress-crowdfunding-theme/4257622?ref=Astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (1105, 1689, '_wp_old_slug', 'campaignify') ; 
INSERT INTO `wp_postmeta` VALUES (1106, 1689, '_wp_old_slug', 'fundify-2') ; 
INSERT INTO `wp_postmeta` VALUES (1107, 1691, '_thumbnail_id', '2017') ; 
INSERT INTO `wp_postmeta` VALUES (1108, 1691, '_wp_old_slug', 'wb') ; 
INSERT INTO `wp_postmeta` VALUES (1109, 1691, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1110, 1691, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1111, 1691, '_url', 'http://themeforest.net/item/campaignify-crowdfunding-wordpress-theme/4725411?ref=Astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (1112, 1691, '_wp_old_slug', 'fundify') ; 
INSERT INTO `wp_postmeta` VALUES (1113, 1691, '_wp_old_slug', 'marketify') ; 
INSERT INTO `wp_postmeta` VALUES (1114, 1693, '_thumbnail_id', '2018') ; 
INSERT INTO `wp_postmeta` VALUES (1115, 1693, '_wp_old_slug', 'j-crew') ; 
INSERT INTO `wp_postmeta` VALUES (1116, 1693, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1117, 1693, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1118, 1693, '_url', 'http://themeforest.net/item/marketify-digital-marketplace-wordpress-theme/6570786?ref=Astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (1119, 1693, '_wp_old_slug', 'classify') ; 
INSERT INTO `wp_postmeta` VALUES (1120, 1712, '_gravatar_email', 'spencer@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (1121, 1713, '_gravatar_email', 'adam@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (1122, 1713, '_wp_old_slug', 'adam somedude') ; 
INSERT INTO `wp_postmeta` VALUES (1123, 1767, '_thumbnail_id', '1802') ; 
INSERT INTO `wp_postmeta` VALUES (1124, 1778, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:5:"speed";i:7000;s:8:"duration";i:600;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:7:"animate";i:0;s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1125, 1778, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1126, 1778, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1127, 1778, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:5:"speed";i:7000;s:8:"duration";i:600;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:7:"animate";i:0;s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1128, 1778, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1129, 1778, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1130, 1778, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:5:"speed";i:7000;s:8:"duration";i:600;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:7:"animate";i:0;s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1131, 1778, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1132, 1778, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1133, 1778, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:5:"speed";i:7000;s:8:"duration";i:600;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:7:"animate";i:0;s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1134, 1778, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1135, 1778, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1136, 1778, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:5:"speed";i:7000;s:8:"duration";i:600;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:7:"animate";i:0;s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1137, 1778, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1138, 1778, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1139, 1778, '_soliloquy_settings', 'a:29:{s:4:"type";s:7:"default";s:7:"default";s:6:"custom";s:5:"width";b:0;s:6:"height";b:0;s:6:"custom";s:4:"full";s:10:"transition";s:4:"fade";s:5:"speed";i:7000;s:8:"duration";i:600;s:9:"preloader";i:1;s:10:"navigation";i:1;s:7:"control";i:1;s:8:"keyboard";i:1;s:6:"number";i:0;s:4:"loop";i:1;s:6:"action";i:1;s:3:"css";i:1;s:6:"smooth";i:1;s:5:"touch";i:1;s:5:"delay";i:0;s:6:"retina";s:1:"1";s:7:"animate";i:0;s:5:"video";i:0;s:8:"advanced";i:0;s:9:"multi_key";i:0;s:10:"mousewheel";i:0;s:9:"pauseplay";i:0;s:6:"random";i:0;s:5:"hover";i:0;s:7:"reverse";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1140, 1778, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1141, 1778, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1144, 1799, '_thumbnail_id', '1804') ; 
INSERT INTO `wp_postmeta` VALUES (1147, 1806, '_wp_old_slug', 'who-actually-enjoys-their-job-what-do-you-do-what-makes-it-enjoyable') ; 
INSERT INTO `wp_postmeta` VALUES (1148, 1806, '_thumbnail_id', '1811') ; 
INSERT INTO `wp_postmeta` VALUES (1149, 1862, '_wp_old_slug', 'middle-class-jobs-are-being-replaced-by-burger-flipping-retail-sales-low-pay-jobs-5') ; 
INSERT INTO `wp_postmeta` VALUES (1150, 1862, '_dp_original', '1806') ; 
INSERT INTO `wp_postmeta` VALUES (1151, 1862, '_thumbnail_id', '1804') ; 
INSERT INTO `wp_postmeta` VALUES (1152, 1862, '_wp_old_slug', 'who-actually-enjoys-their-job-what-do-you-do-what-makes-it-enjoyable') ; 
INSERT INTO `wp_postmeta` VALUES (1155, 1863, '_dp_original', '1865') ; 
INSERT INTO `wp_postmeta` VALUES (1156, 1863, '_thumbnail_id', '1811') ; 
INSERT INTO `wp_postmeta` VALUES (1157, 1863, '_wp_old_slug', 'who-actually-enjoys-their-job-what-do-you-do-what-makes-it-enjoyable') ; 
INSERT INTO `wp_postmeta` VALUES (1158, 1863, '_dp_original', '1864') ; 
INSERT INTO `wp_postmeta` VALUES (1159, 1863, '_thumbnail_id', '1811') ; 
INSERT INTO `wp_postmeta` VALUES (1160, 1863, '_wp_old_slug', 'who-actually-enjoys-their-job-what-do-you-do-what-makes-it-enjoyable') ; 
INSERT INTO `wp_postmeta` VALUES (1161, 1863, '_dp_original', '1862') ; 
INSERT INTO `wp_postmeta` VALUES (1162, 1863, '_thumbnail_id', '1802') ; 
INSERT INTO `wp_postmeta` VALUES (1163, 1863, '_wp_old_slug', 'who-actually-enjoys-their-job-what-do-you-do-what-makes-it-enjoyable') ; 
INSERT INTO `wp_postmeta` VALUES (1164, 1864, '_wp_old_slug', 'middle-class-jobs-are-being-replaced-by-burger-flipping-retail-sales-low-pay-jobs-3') ; 
INSERT INTO `wp_postmeta` VALUES (1165, 1864, '_dp_original', '1863') ; 
INSERT INTO `wp_postmeta` VALUES (1166, 1864, '_thumbnail_id', '1811') ; 
INSERT INTO `wp_postmeta` VALUES (1167, 1864, '_wp_old_slug', 'who-actually-enjoys-their-job-what-do-you-do-what-makes-it-enjoyable') ; 
INSERT INTO `wp_postmeta` VALUES (1168, 1943, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1169, 1943, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1170, 1943, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1171, 2069, '_wp_page_template', 'page-templates/map-jobs.php') ; 
INSERT INTO `wp_postmeta` VALUES (1172, 1714, '_gravatar_email', 'liam@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (1173, 1714, '_wp_old_slug', 'liam-mckay') ; 
INSERT INTO `wp_postmeta` VALUES (1174, 1715, '_gravatar_email', 'jason@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (1175, 1715, '_wp_old_slug', 'jason-schuller') ; 
INSERT INTO `wp_postmeta` VALUES (1176, 1759, '_gravatar_email', 'jake@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (1177, 1759, '_wp_old_slug', 'jake-caputo') ; 
INSERT INTO `wp_postmeta` VALUES (1178, 1793, '_gravatar_email', 'chrisc@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (1179, 1793, '_wp_old_slug', 'chris-christoff') ; 
INSERT INTO `wp_postmeta` VALUES (1180, 2023, '_thumbnail_id', '2020') ; 
INSERT INTO `wp_postmeta` VALUES (1181, 2023, 'rcp_access_level', 'None') ; 
INSERT INTO `wp_postmeta` VALUES (1182, 2023, 'rcp_user_level', 'All') ; 
INSERT INTO `wp_postmeta` VALUES (1183, 2023, '_url', 'http://themeforest.net/item/fundify-the-wordpress-crowdfunding-theme/4257622?ref=Astoundify') ; 
INSERT INTO `wp_postmeta` VALUES (1184, 2184, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1185, 2184, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1186, 2184, '_menu_item_object_id', '1671') ; 
INSERT INTO `wp_postmeta` VALUES (1187, 2184, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1188, 2184, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1189, 2184, '_menu_item_classes', 'a:1:{i:0;s:5:"login";}') ; 
INSERT INTO `wp_postmeta` VALUES (1190, 2184, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1191, 2184, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1192, 2185, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1193, 2185, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1194, 2185, '_menu_item_object_id', '1943') ; 
INSERT INTO `wp_postmeta` VALUES (1195, 2185, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1196, 2185, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1197, 2185, '_menu_item_classes', 'a:1:{i:0;s:8:"register";}') ; 
INSERT INTO `wp_postmeta` VALUES (1198, 2185, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1199, 2185, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1200, 2186, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1201, 2186, '_menu_item_menu_item_parent', '2171') ; 
INSERT INTO `wp_postmeta` VALUES (1202, 2186, '_menu_item_object_id', '703') ; 
INSERT INTO `wp_postmeta` VALUES (1203, 2186, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1204, 2186, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1205, 2186, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1206, 2186, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1207, 2186, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1208, 2187, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1209, 2187, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1210, 2187, '_menu_item_object_id', '2069') ; 
INSERT INTO `wp_postmeta` VALUES (1211, 2187, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1212, 2187, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1213, 2187, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1214, 2187, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1215, 2187, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1219, 2188, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:246;s:6:"height";i:102;s:4:"file";s:37:"2014/02/cropped-LogoWhite-300x171.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"cropped-LogoWhite-300x171-150x102.png";s:5:"width";i:150;s:6:"height";i:102;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:37:"cropped-LogoWhite-300x171-115x102.png";s:5:"width";i:115;s:6:"height";i:102;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1220, 2188, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1221, 2189, '_wp_attached_file', '2014/02/LogoWhiteCropped02.png') ; 
INSERT INTO `wp_postmeta` VALUES (1222, 2189, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1223, 2189, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:53;s:4:"file";s:30:"2014/02/LogoWhiteCropped02.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"LogoWhiteCropped02-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:29:"LogoWhiteCropped02-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1224, 2189, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1225, 1778, '_edit_lock', '1392342245:1') ; 
INSERT INTO `wp_postmeta` VALUES (1226, 2191, '_wp_attached_file', '2014/02/cropped-LogoWhiteCroppedTest2.png') ; 
INSERT INTO `wp_postmeta` VALUES (1227, 2191, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1228, 2191, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:53;s:4:"file";s:41:"2014/02/cropped-LogoWhiteCroppedTest2.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"cropped-LogoWhiteCroppedTest2-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:40:"cropped-LogoWhiteCroppedTest2-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1229, 2191, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1230, 2185, '_nav_menu_role', 'out') ; 
INSERT INTO `wp_postmeta` VALUES (1231, 2184, '_nav_menu_role', 'out') ; 
INSERT INTO `wp_postmeta` VALUES (1232, 2069, '_edit_lock', '1403882940:1') ; 
INSERT INTO `wp_postmeta` VALUES (1233, 2192, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (1234, 2192, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1235, 2192, '_menu_item_object_id', '2192') ; 
INSERT INTO `wp_postmeta` VALUES (1236, 2192, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (1237, 2192, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1238, 2192, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1239, 2192, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1240, 2192, '_menu_item_url', '/wp-login.php?action=logout') ; 
INSERT INTO `wp_postmeta` VALUES (1242, 2192, '_nav_menu_role', 'in') ; 
INSERT INTO `wp_postmeta` VALUES (2169, 2433, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (2168, 2433, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (2167, 2433, '_menu_item_object_id', '2362') ; 
INSERT INTO `wp_postmeta` VALUES (2166, 2433, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2165, 2433, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (2164, 2431, '_edit_lock', '1404302593:1') ; 
INSERT INTO `wp_postmeta` VALUES (2163, 2199, '_edit_lock', '1403889895:1') ; 
INSERT INTO `wp_postmeta` VALUES (2162, 1765, '_edit_lock', '1403890352:1') ; 
INSERT INTO `wp_postmeta` VALUES (2161, 1673, '_edit_lock', '1403890277:1') ; 
INSERT INTO `wp_postmeta` VALUES (2160, 2198, '_edit_lock', '1403890344:1') ; 
INSERT INTO `wp_postmeta` VALUES (2159, 2196, '_edit_lock', '1403890155:1') ; 
INSERT INTO `wp_postmeta` VALUES (2158, 2195, '_edit_lock', '1403890023:1') ; 
INSERT INTO `wp_postmeta` VALUES (1264, 2195, '_tml_action', 'login') ; 
INSERT INTO `wp_postmeta` VALUES (1265, 2196, '_tml_action', 'logout') ; 
INSERT INTO `wp_postmeta` VALUES (1266, 2197, '_tml_action', 'register') ; 
INSERT INTO `wp_postmeta` VALUES (1267, 2198, '_tml_action', 'lostpassword') ; 
INSERT INTO `wp_postmeta` VALUES (1268, 2199, '_tml_action', 'resetpass') ; 
INSERT INTO `wp_postmeta` VALUES (2157, 2427, '_edit_lock', '1403891268:1') ; 
INSERT INTO `wp_postmeta` VALUES (2156, 2428, '_edit_lock', '1403888039:1') ; 
INSERT INTO `wp_postmeta` VALUES (1983, 2378, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3888;s:6:"height";i:2592;s:4:"file";s:33:"2014/04/picjumbo.com_IMG_4893.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"picjumbo.com_IMG_4893-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"picjumbo.com_IMG_4893-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:34:"picjumbo.com_IMG_4893-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"content-grid";a:4:{s:4:"file";s:33:"picjumbo.com_IMG_4893-400x200.jpg";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:20:"content-job-featured";a:4:{s:4:"file";s:34:"picjumbo.com_IMG_4893-1350x525.jpg";s:5:"width";i:1350;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:33:"picjumbo.com_IMG_4893-115x115.jpg";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2;s:6:"credit";s:7:"unknown";s:6:"camera";s:22:"Canon EOS 400D DIGITAL";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1388076089;s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"28";s:3:"iso";s:3:"800";s:13:"shutter_speed";s:5:"0.025";s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1982, 2378, '_wp_attached_file', '2014/04/picjumbo.com_IMG_4893.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1981, 2377, '_wp_attachment_backup_sizes', 'a:4:{s:16:"resized-1140x450";a:5:{s:4:"path";s:95:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/DeathtoStock_Wired2-1140x450.jpg";s:4:"file";s:32:"DeathtoStock_Wired2-1140x450.jpg";s:5:"width";i:1140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-2140x450";a:5:{s:4:"path";s:95:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/DeathtoStock_Wired2-2140x450.jpg";s:4:"file";s:32:"DeathtoStock_Wired2-2140x450.jpg";s:5:"width";i:2140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-3140x450";a:5:{s:4:"path";s:95:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/DeathtoStock_Wired2-3140x450.jpg";s:4:"file";s:32:"DeathtoStock_Wired2-3140x450.jpg";s:5:"width";i:3140;s:6:"height";i:450;s:9:"mime-type";s:10:"image/jpeg";}s:16:"resized-2140x550";a:5:{s:4:"path";s:95:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/DeathtoStock_Wired2-2140x550.jpg";s:4:"file";s:32:"DeathtoStock_Wired2-2140x550.jpg";s:5:"width";i:2140;s:6:"height";i:550;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1980, 2377, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1972, 2375, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1973, 2375, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (2154, 2428, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2155, 2428, '_job_expires', '') ; 
INSERT INTO `wp_postmeta` VALUES (1955, 2328, '_edit_lock', '1395335932:1') ; 
INSERT INTO `wp_postmeta` VALUES (1953, 2347, '_nav_menu_role', 'a:2:{i:0;s:13:"administrator";i:1;s:10:"subscriber";}') ; 
INSERT INTO `wp_postmeta` VALUES (1952, 1762, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1951, 1760, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1950, 1760, '_edit_lock', '1395331711:1') ; 
INSERT INTO `wp_postmeta` VALUES (1948, 2364, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1947, 2364, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1946, 2364, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1998, 2386, '_wp_attached_file', '2014/04/profile2Yellow.gif') ; 
INSERT INTO `wp_postmeta` VALUES (1999, 2386, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:26:"2014/04/profile2Yellow.gif";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"profile2Yellow-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:26:"profile2Yellow-300x300.gif";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/gif";}s:12:"content-grid";a:4:{s:4:"file";s:26:"profile2Yellow-400x200.gif";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/gif";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:26:"profile2Yellow-115x115.gif";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1924, 2347, '_menu_item_url', '#') ; 
INSERT INTO `wp_postmeta` VALUES (1923, 2347, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1922, 2347, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1921, 2347, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1920, 2347, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (1919, 2347, '_menu_item_object_id', '2347') ; 
INSERT INTO `wp_postmeta` VALUES (1918, 2347, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1939, 2362, '_edit_lock', '1403882910:1') ; 
INSERT INTO `wp_postmeta` VALUES (1954, 2260, '_nav_menu_role', 'in') ; 
INSERT INTO `wp_postmeta` VALUES (1910, 2346, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1909, 2346, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1908, 2346, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1907, 2346, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1906, 2346, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1905, 2346, '_menu_item_object_id', '2297') ; 
INSERT INTO `wp_postmeta` VALUES (1903, 2346, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1904, 2346, '_menu_item_menu_item_parent', '2347') ; 
INSERT INTO `wp_postmeta` VALUES (1917, 2347, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (1938, 2362, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1916, 2346, '_nav_menu_role', 'a:3:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:10:"subscriber";}') ; 
INSERT INTO `wp_postmeta` VALUES (1915, 2240, '_nav_menu_role', 'a:3:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:10:"subscriber";}') ; 
INSERT INTO `wp_postmeta` VALUES (1914, 2241, '_nav_menu_role', 'a:3:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:10:"subscriber";}') ; 
INSERT INTO `wp_postmeta` VALUES (1645, 2254, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1646, 2254, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1647, 2254, '_menu_item_object_id', '1943') ; 
INSERT INTO `wp_postmeta` VALUES (1648, 2254, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1649, 2254, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1650, 2254, '_menu_item_classes', 'a:1:{i:0;s:8:"register";}') ; 
INSERT INTO `wp_postmeta` VALUES (1651, 2254, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1652, 2254, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1654, 2254, '_nav_menu_role', 'out') ; 
INSERT INTO `wp_postmeta` VALUES (1976, 2376, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:210;s:6:"height";i:71;s:4:"file";s:24:"2014/04/cropped-logo.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"cropped-logo-150x71.png";s:5:"width";i:150;s:6:"height";i:71;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:23:"cropped-logo-115x71.png";s:5:"width";i:115;s:6:"height";i:71;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1975, 2376, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1974, 2376, '_wp_attached_file', '2014/04/cropped-logo.png') ; 
INSERT INTO `wp_postmeta` VALUES (1701, 2260, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1702, 2260, '_menu_item_object_id', '2235') ; 
INSERT INTO `wp_postmeta` VALUES (1703, 2260, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1704, 2260, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1705, 2260, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (1706, 2260, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1707, 2260, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1710, 2235, '_edit_lock', '1403889832:1') ; 
INSERT INTO `wp_postmeta` VALUES (1711, 2235, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1712, 2235, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1713, 1915, '_edit_lock', '1403887914:1') ; 
INSERT INTO `wp_postmeta` VALUES (1714, 1882, '_edit_lock', '1403882898:1') ; 
INSERT INTO `wp_postmeta` VALUES (1715, 2263, '_form', 'Name *  [text* your-name class:footercontact] 

Email *  [email* your-email class:footercontact]

[textarea your-message class:footercontact]

[submit "Send"]') ; 
INSERT INTO `wp_postmeta` VALUES (1821, 2, '_edit_lock', '1403891101:1') ; 
INSERT INTO `wp_postmeta` VALUES (1716, 2263, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:162:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)";s:9:"recipient";s:26:"maceachern.jonny@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1717, 2263, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:104:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1718, 2263, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (1719, 2263, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (1720, 2263, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (1751, 2290, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:974;s:6:"height";i:548;s:4:"file";s:24:"2014/03/nscc_mission.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"nscc_mission-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"nscc_mission-300x168.jpg";s:5:"width";i:300;s:6:"height";i:168;s:9:"mime-type";s:10:"image/jpeg";}s:12:"content-grid";a:4:{s:4:"file";s:24:"nscc_mission-400x200.jpg";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:20:"content-job-featured";a:4:{s:4:"file";s:24:"nscc_mission-974x525.jpg";s:5:"width";i:974;s:6:"height";i:525;s:9:"mime-type";s:10:"image/jpeg";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:24:"nscc_mission-115x115.jpg";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1776, 2296, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1775, 2296, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:53;s:4:"file";s:22:"2014/03/copy-logo2.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"copy-logo2-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:21:"copy-logo2-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1750, 2290, '_wp_attached_file', '2014/03/nscc_mission.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (1773, 2296, '_wp_attached_file', '2014/03/copy-logo2.png') ; 
INSERT INTO `wp_postmeta` VALUES (1771, 2295, '_wp_attached_file', '2014/03/logo2.png') ; 
INSERT INTO `wp_postmeta` VALUES (1772, 2295, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:200;s:6:"height";i:53;s:4:"file";s:17:"2014/03/logo2.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"logo2-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:16:"logo2-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1752, 2290, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1753, 2290, '_wp_attachment_backup_sizes', 'a:1:{s:15:"resized-974x384";a:5:{s:4:"path";s:87:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/nscc_mission-974x384.jpg";s:4:"file";s:24:"nscc_mission-974x384.jpg";s:5:"width";i:974;s:6:"height";i:384;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1754, 2290, '_wp_attachment_image_alt', 'NSCC Mission Statement') ; 
INSERT INTO `wp_postmeta` VALUES (1756, 6, '_edit_lock', '1393975787:1') ; 
INSERT INTO `wp_postmeta` VALUES (1757, 8, '_edit_lock', '1396541277:1') ; 
INSERT INTO `wp_postmeta` VALUES (1758, 8, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1774, 2296, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1777, 2297, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (1778, 2297, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (1779, 2297, '_edit_lock', '1403889806:1') ; 
INSERT INTO `wp_postmeta` VALUES (1780, 1671, '_edit_lock', '1403890072:1') ; 
INSERT INTO `wp_postmeta` VALUES (1781, 2300, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (1782, 2300, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1783, 2300, '_menu_item_object_id', '1671') ; 
INSERT INTO `wp_postmeta` VALUES (1784, 2300, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (1785, 2300, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (1786, 2300, '_menu_item_classes', 'a:1:{i:0;s:5:"login";}') ; 
INSERT INTO `wp_postmeta` VALUES (1787, 2300, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (1788, 2300, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (1796, 2301, '_wp_attachment_image_alt', 'NSCC Mission Statement') ; 
INSERT INTO `wp_postmeta` VALUES (1797, 2301, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (1798, 2301, '_wp_attachment_backup_sizes', 'a:1:{s:16:"resized-1137x449";a:5:{s:4:"path";s:82:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/03/Slide1-1137x449.png";s:4:"file";s:19:"Slide1-1137x449.png";s:5:"width";i:1137;s:6:"height";i:449;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1799, 14, '_edit_lock', '1403892899:1') ; 
INSERT INTO `wp_postmeta` VALUES (1800, 1719, '_edit_lock', '1394205859:1') ; 
INSERT INTO `wp_postmeta` VALUES (1801, 1762, '_edit_lock', '1403889895:1') ; 
INSERT INTO `wp_postmeta` VALUES (1992, 2382, '_wp_attached_file', '2014/04/mobileMarketingYellow.gif') ; 
INSERT INTO `wp_postmeta` VALUES (1993, 2382, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:33:"2014/04/mobileMarketingYellow.gif";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"mobileMarketingYellow-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:33:"mobileMarketingYellow-300x300.gif";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/gif";}s:12:"content-grid";a:4:{s:4:"file";s:33:"mobileMarketingYellow-400x200.gif";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/gif";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:33:"mobileMarketingYellow-115x115.gif";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1994, 2383, '_wp_attached_file', '2014/04/bizSolutionsYellow.gif') ; 
INSERT INTO `wp_postmeta` VALUES (1995, 2383, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:30:"2014/04/bizSolutionsYellow.gif";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"bizSolutionsYellow-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:30:"bizSolutionsYellow-300x300.gif";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/gif";}s:12:"content-grid";a:4:{s:4:"file";s:30:"bizSolutionsYellow-400x200.gif";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/gif";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:30:"bizSolutionsYellow-115x115.gif";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1996, 2384, '_wp_attached_file', '2014/04/netYellow.gif') ; 
INSERT INTO `wp_postmeta` VALUES (1997, 2384, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:21:"2014/04/netYellow.gif";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"netYellow-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:21:"netYellow-300x300.gif";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/gif";}s:12:"content-grid";a:4:{s:4:"file";s:21:"netYellow-400x200.gif";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/gif";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:21:"netYellow-115x115.gif";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1809, 2197, '_edit_lock', '1403889895:1') ; 
INSERT INTO `wp_postmeta` VALUES (1810, 2315, '_wp_attached_file', '2014/03/logo.png') ; 
INSERT INTO `wp_postmeta` VALUES (1811, 2315, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:210;s:6:"height";i:53;s:4:"file";s:16:"2014/03/logo.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"logo-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:15:"logo-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1812, 2315, '_edit_lock', '1397182659:1') ; 
INSERT INTO `wp_postmeta` VALUES (1813, 2316, '_wp_attached_file', '2014/03/logo1.png') ; 
INSERT INTO `wp_postmeta` VALUES (1814, 2316, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1815, 2316, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:210;s:6:"height";i:53;s:4:"file";s:17:"2014/03/logo1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"logo1-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:16:"logo1-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1816, 2316, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1817, 2317, '_wp_attached_file', '2014/03/logo3.png') ; 
INSERT INTO `wp_postmeta` VALUES (1818, 2317, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (1819, 2317, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:210;s:6:"height";i:53;s:4:"file";s:17:"2014/03/logo3.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"logo3-150x53.png";s:5:"width";i:150;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:16:"logo3-115x53.png";s:5:"width";i:115;s:6:"height";i:53;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (1820, 2317, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1826, 2323, '_wp_attachment_is_custom_header', 'jobify-child') ; 
INSERT INTO `wp_postmeta` VALUES (1827, 2324, '_form', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message (required)<br />
    [textarea* your-message] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (1828, 2324, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:162:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)";s:9:"recipient";s:26:"maceachern.jonny@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1829, 2324, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:104:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";b:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (1830, 2324, '_messages', 'a:21:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:14:"invalid_number";s:28:"Number format seems invalid.";s:16:"number_too_small";s:25:"This number is too small.";s:16:"number_too_large";s:25:"This number is too large.";s:13:"invalid_email";s:28:"Email address seems invalid.";s:11:"invalid_url";s:18:"URL seems invalid.";s:11:"invalid_tel";s:31:"Telephone number seems invalid.";s:23:"quiz_answer_not_correct";s:27:"Your answer is not correct.";s:12:"invalid_date";s:26:"Date format seems invalid.";s:14:"date_too_early";s:23:"This date is too early.";s:13:"date_too_late";s:22:"This date is too late.";s:13:"upload_failed";s:22:"Failed to upload file.";s:24:"upload_file_type_invalid";s:30:"This file type is not allowed.";s:21:"upload_file_too_large";s:23:"This file is too large.";s:23:"upload_failed_php_error";s:38:"Failed to upload file. Error occurred.";}') ; 
INSERT INTO `wp_postmeta` VALUES (1831, 2324, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (1832, 2324, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (1834, 2328, '_application', 'dummy@email.com') ; 
INSERT INTO `wp_postmeta` VALUES (1835, 2328, '_job_location', 'Dartmouth, NS') ; 
INSERT INTO `wp_postmeta` VALUES (1836, 2328, '_company_name', 'WebGirl') ; 
INSERT INTO `wp_postmeta` VALUES (1837, 2328, '_company_website', '') ; 
INSERT INTO `wp_postmeta` VALUES (1838, 2328, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (1839, 2328, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (1840, 2328, '_company_logo', 'http://capstone.jonny.me/wp-content/uploads/job_listings/pink-pearl-my-computer.png') ; 
INSERT INTO `wp_postmeta` VALUES (1841, 2328, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1842, 2328, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (1843, 2328, '_company_description', '<p>Hottest  Web company in Dartmouth, NS</p>') ; 
INSERT INTO `wp_postmeta` VALUES (1844, 2328, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (1845, 2328, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (1846, 2328, 'geolocation_lat', '44.6652059') ; 
INSERT INTO `wp_postmeta` VALUES (1847, 2328, 'geolocation_long', '-63.5677427') ; 
INSERT INTO `wp_postmeta` VALUES (1848, 2328, 'geolocation_formatted_address', 'Dartmouth, NS, Canada') ; 
INSERT INTO `wp_postmeta` VALUES (1849, 2328, 'geolocation_city', 'Dartmouth') ; 
INSERT INTO `wp_postmeta` VALUES (1850, 2328, 'geolocation_state_short', 'NS') ; 
INSERT INTO `wp_postmeta` VALUES (1851, 2328, 'geolocation_state_long', 'Nova Scotia') ; 
INSERT INTO `wp_postmeta` VALUES (1852, 2328, 'geolocation_country_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (1853, 2328, 'geolocation_country_long', 'Canada') ; 
INSERT INTO `wp_postmeta` VALUES (1854, 2328, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2009, 2389, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (2010, 2392, '_wp_attached_file', '2014/04/learninggrowing.png') ; 
INSERT INTO `wp_postmeta` VALUES (2011, 2392, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:450;s:4:"file";s:27:"2014/04/learninggrowing.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"learninggrowing-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"learninggrowing-300x118.png";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:28:"learninggrowing-1024x404.png";s:5:"width";i:1024;s:6:"height";i:404;s:9:"mime-type";s:9:"image/png";}s:12:"content-grid";a:4:{s:4:"file";s:27:"learninggrowing-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:27:"learninggrowing-115x115.png";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2012, 2392, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (2013, 2389, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (2014, 2392, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (2015, 2379, '_wp_attachment_backup_sizes', 'a:5:{s:16:"resized-1140x239";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/werocks-1140x239.png";s:4:"file";s:20:"werocks-1140x239.png";s:5:"width";i:1140;s:6:"height";i:239;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x163";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/werocks-1140x163.png";s:4:"file";s:20:"werocks-1140x163.png";s:5:"width";i:1140;s:6:"height";i:163;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x292";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/werocks-1140x292.png";s:4:"file";s:20:"werocks-1140x292.png";s:5:"width";i:1140;s:6:"height";i:292;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1134x325";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/werocks-1134x325.png";s:4:"file";s:20:"werocks-1134x325.png";s:5:"width";i:1134;s:6:"height";i:325;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x325";a:5:{s:4:"path";s:83:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/werocks-1140x325.png";s:4:"file";s:20:"werocks-1140x325.png";s:5:"width";i:1140;s:6:"height";i:325;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2016, 2389, '_wp_attachment_backup_sizes', 'a:5:{s:16:"resized-1140x239";a:5:{s:4:"path";s:82:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/itjobs-1140x239.png";s:4:"file";s:19:"itjobs-1140x239.png";s:5:"width";i:1140;s:6:"height";i:239;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x163";a:5:{s:4:"path";s:82:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/itjobs-1140x163.png";s:4:"file";s:19:"itjobs-1140x163.png";s:5:"width";i:1140;s:6:"height";i:163;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x292";a:5:{s:4:"path";s:82:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/itjobs-1140x292.png";s:4:"file";s:19:"itjobs-1140x292.png";s:5:"width";i:1140;s:6:"height";i:292;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1134x325";a:5:{s:4:"path";s:82:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/itjobs-1134x325.png";s:4:"file";s:19:"itjobs-1134x325.png";s:5:"width";i:1134;s:6:"height";i:325;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x325";a:5:{s:4:"path";s:82:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/itjobs-1140x325.png";s:4:"file";s:19:"itjobs-1140x325.png";s:5:"width";i:1140;s:6:"height";i:325;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2017, 2392, '_wp_attachment_backup_sizes', 'a:5:{s:16:"resized-1140x239";a:5:{s:4:"path";s:91:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/learninggrowing-1140x239.png";s:4:"file";s:28:"learninggrowing-1140x239.png";s:5:"width";i:1140;s:6:"height";i:239;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x163";a:5:{s:4:"path";s:91:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/learninggrowing-1140x163.png";s:4:"file";s:28:"learninggrowing-1140x163.png";s:5:"width";i:1140;s:6:"height";i:163;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x292";a:5:{s:4:"path";s:91:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/learninggrowing-1140x292.png";s:4:"file";s:28:"learninggrowing-1140x292.png";s:5:"width";i:1140;s:6:"height";i:292;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1134x325";a:5:{s:4:"path";s:91:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/learninggrowing-1134x325.png";s:4:"file";s:28:"learninggrowing-1134x325.png";s:5:"width";i:1134;s:6:"height";i:325;s:9:"mime-type";s:9:"image/png";}s:16:"resized-1140x325";a:5:{s:4:"path";s:91:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/learninggrowing-1140x325.png";s:4:"file";s:28:"learninggrowing-1140x325.png";s:5:"width";i:1140;s:6:"height";i:325;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2018, 2394, '_wp_attached_file', '2014/04/globe.png') ; 
INSERT INTO `wp_postmeta` VALUES (2019, 2394, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1140;s:6:"height";i:450;s:4:"file";s:17:"2014/04/globe.png";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"globe-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"globe-300x118.png";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:18:"globe-1024x404.png";s:5:"width";i:1024;s:6:"height";i:404;s:9:"mime-type";s:9:"image/png";}s:12:"content-grid";a:4:{s:4:"file";s:17:"globe-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"soliloquy-thumb";a:4:{s:4:"file";s:17:"globe-115x115.png";s:5:"width";i:115;s:6:"height";i:115;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2020, 2394, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (2021, 2394, '_wp_attachment_backup_sizes', 'a:1:{s:16:"resized-1140x292";a:5:{s:4:"path";s:81:"/home/jonnymac/public_html/capstone/wp-content/uploads/2014/04/globe-1140x292.png";s:4:"file";s:18:"globe-1140x292.png";s:5:"width";i:1140;s:6:"height";i:292;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2022, 2394, '_wp_attachment_image_alt', '') ; 
INSERT INTO `wp_postmeta` VALUES (2023, 2218, '_sol_slider_data', 'a:4:{s:2:"id";i:2218;s:6:"config";a:9:{s:5:"title";s:14:"HomepageSlider";s:4:"slug";s:4:"2218";s:6:"slider";i:0;s:12:"slider_width";i:2000;s:13:"slider_height";i:1000;s:10:"transition";s:4:"fade";s:8:"duration";i:7000;s:5:"speed";i:600;s:12:"slider_theme";s:7:"classic";}s:6:"slider";a:0:{}s:6:"status";s:6:"active";}') ; 
INSERT INTO `wp_postmeta` VALUES (2024, 1778, '_sol_slider_data', 'a:4:{s:2:"id";i:1778;s:6:"config";a:7:{s:5:"title";s:10:"App Slider";s:4:"slug";s:9:"app-slide";s:6:"slider";i:0;s:10:"transition";s:4:"fade";s:8:"duration";i:7000;s:5:"speed";i:600;s:12:"slider_theme";s:7:"classic";}s:6:"slider";a:0:{}s:6:"status";s:6:"active";}') ; 
INSERT INTO `wp_postmeta` VALUES (2025, 1668, '_sol_slider_data', 'a:4:{s:2:"id";i:1668;s:6:"config";a:7:{s:5:"title";s:11:"Main Slider";s:4:"slug";s:11:"main-slider";s:6:"slider";i:0;s:10:"transition";s:4:"fade";s:8:"duration";i:5030;s:5:"speed";i:360;s:12:"slider_theme";s:7:"classic";}s:6:"slider";a:0:{}s:6:"status";s:6:"active";}') ; 
INSERT INTO `wp_postmeta` VALUES (2153, 2428, 'geolocation_country_long', 'United Kingdom') ; 
INSERT INTO `wp_postmeta` VALUES (2028, 2316, '_edit_lock', '1397182598:1') ; 
INSERT INTO `wp_postmeta` VALUES (2029, 2317, '_edit_lock', '1397191940:1') ; 
INSERT INTO `wp_postmeta` VALUES (2030, 2317, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2031, 25, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2112, 2427, '_application', 'scarfone.marc@gmail.com') ; 
INSERT INTO `wp_postmeta` VALUES (2113, 2427, '_job_location', 'Halifax') ; 
INSERT INTO `wp_postmeta` VALUES (2040, 2408, '_application', 'acmedesignco@acme.com') ; 
INSERT INTO `wp_postmeta` VALUES (2041, 2408, '_job_location', 'Halifax, NS') ; 
INSERT INTO `wp_postmeta` VALUES (2042, 2408, '_company_name', 'Acme Design Co.') ; 
INSERT INTO `wp_postmeta` VALUES (2043, 2408, '_company_website', '') ; 
INSERT INTO `wp_postmeta` VALUES (2044, 2408, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (2045, 2408, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (2046, 2408, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (2047, 2408, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2048, 2408, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2049, 2408, '_company_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (2050, 2408, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (2051, 2408, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (2052, 2408, 'geolocation_lat', '44.6488625') ; 
INSERT INTO `wp_postmeta` VALUES (2053, 2408, 'geolocation_long', '-63.5753196') ; 
INSERT INTO `wp_postmeta` VALUES (2054, 2408, 'geolocation_formatted_address', 'Halifax, NS, Canada') ; 
INSERT INTO `wp_postmeta` VALUES (2055, 2408, 'geolocation_city', 'Halifax') ; 
INSERT INTO `wp_postmeta` VALUES (2056, 2408, 'geolocation_state_short', 'NS') ; 
INSERT INTO `wp_postmeta` VALUES (2057, 2408, 'geolocation_state_long', 'Nova Scotia') ; 
INSERT INTO `wp_postmeta` VALUES (2058, 2408, 'geolocation_country_short', 'CA') ; 
INSERT INTO `wp_postmeta` VALUES (2059, 2408, 'geolocation_country_long', 'Canada') ; 
INSERT INTO `wp_postmeta` VALUES (2060, 2408, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2061, 2408, '_job_expires', '2014-07-10') ; 
INSERT INTO `wp_postmeta` VALUES (2062, 2328, '_job_expires', '2014-07-10') ; 
INSERT INTO `wp_postmeta` VALUES (2063, 2224, '_job_expires', '2014-07-10') ; 
INSERT INTO `wp_postmeta` VALUES (2064, 1762, '_sol_slider_data', 'a:2:{s:2:"id";i:1762;s:6:"config";a:12:{s:4:"type";s:7:"default";s:12:"slider_theme";s:4:"base";s:12:"slider_width";i:960;s:13:"slider_height";i:300;s:10:"transition";s:4:"fade";s:8:"duration";i:5000;s:5:"speed";i:400;s:6:"gutter";i:20;s:6:"slider";i:1;s:7:"classes";a:1:{i:0;s:0:"";}s:5:"title";s:0:"";s:4:"slug";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2065, 2412, '_application', 'gencomp@gen.com') ; 
INSERT INTO `wp_postmeta` VALUES (2066, 2412, '_job_location', '') ; 
INSERT INTO `wp_postmeta` VALUES (2067, 2412, '_company_name', 'Generic Company') ; 
INSERT INTO `wp_postmeta` VALUES (2068, 2412, '_company_website', '') ; 
INSERT INTO `wp_postmeta` VALUES (2069, 2412, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (2070, 2412, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (2071, 2412, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (2072, 2412, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2073, 2412, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2074, 2412, '_company_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (2075, 2412, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (2076, 2412, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (2077, 2249, '_sol_slider_data', 'a:2:{s:2:"id";i:2249;s:6:"config";a:12:{s:4:"type";s:7:"default";s:12:"slider_theme";s:4:"base";s:12:"slider_width";i:960;s:13:"slider_height";i:300;s:10:"transition";s:4:"fade";s:8:"duration";i:5000;s:5:"speed";i:400;s:6:"gutter";i:20;s:6:"slider";i:1;s:7:"classes";a:1:{i:0;s:0:"";}s:5:"title";s:0:"";s:4:"slug";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2078, 2412, '_job_expires', '2014-07-10') ; 
INSERT INTO `wp_postmeta` VALUES (2105, 2418, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2080, 2418, '_application', 'marc.scarfone@nscc.ca') ; 
INSERT INTO `wp_postmeta` VALUES (2081, 2418, '_job_location', 'Halifax') ; 
INSERT INTO `wp_postmeta` VALUES (2082, 2418, '_company_name', 'NSCC') ; 
INSERT INTO `wp_postmeta` VALUES (2083, 2418, '_company_website', '') ; 
INSERT INTO `wp_postmeta` VALUES (2084, 2418, '_company_tagline', '') ; 
INSERT INTO `wp_postmeta` VALUES (2085, 2418, '_company_twitter', '') ; 
INSERT INTO `wp_postmeta` VALUES (2086, 2418, '_company_logo', '') ; 
INSERT INTO `wp_postmeta` VALUES (2087, 2418, '_filled', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2088, 2418, '_featured', '0') ; 
INSERT INTO `wp_postmeta` VALUES (2089, 2418, '_company_description', '') ; 
INSERT INTO `wp_postmeta` VALUES (2090, 2418, '_company_facebook', '') ; 
INSERT INTO `wp_postmeta` VALUES (2091, 2418, '_company_google', '') ; 
INSERT INTO `wp_postmeta` VALUES (2092, 2418, 'geolocation_lat', '53.7270200') ; 
INSERT INTO `wp_postmeta` VALUES (2093, 2418, 'geolocation_long', '-1.8575400') ; 
INSERT INTO `wp_postmeta` VALUES (2094, 2418, 'geolocation_formatted_address', 'Halifax, West Yorkshire, UK') ; 
INSERT INTO `wp_postmeta` VALUES (2095, 2418, 'geolocation_city', 'Halifax') ; 
INSERT INTO `wp_postmeta` VALUES (2096, 2418, 'geolocation_state_short', 'England') ; 
INSERT INTO `wp_postmeta` VALUES (2097, 2418, 'geolocation_state_long', 'England') ; 
INSERT INTO `wp_postmeta` VALUES (2098, 2418, 'geolocation_country_short', 'GB') ; 
INSERT INTO `wp_postmeta` VALUES (2099, 2418, 'geolocation_country_long', 'United Kingdom') ; 
INSERT INTO `wp_postmeta` VALUES (2100, 2418, 'geolocated', '1') ; 
INSERT INTO `wp_postmeta` VALUES (2101, 2418, '_job_expires', '2014-07-16') ; 
INSERT INTO `wp_postmeta` VALUES (2102, 2418, '_edit_lock', '1398118622:1') ; 
INSERT INTO `wp_postmeta` VALUES (2103, 2418, '_wp_old_slug', 'web-programming') ; 
INSERT INTO `wp_postmeta` VALUES (2104, 2297, '_sol_slider_data', 'a:2:{s:2:"id";i:2297;s:6:"config";a:12:{s:4:"type";s:7:"default";s:12:"slider_theme";s:4:"base";s:12:"slider_width";i:960;s:13:"slider_height";i:300;s:10:"transition";s:4:"fade";s:8:"duration";i:5000;s:5:"speed";i:400;s:6:"gutter";i:20;s:6:"slider";i:1;s:7:"classes";a:1:{i:0;s:0:"";}s:5:"title";s:0:"";s:4:"slug";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (2106, 2418, '_sol_slider_data', 'a:2:{s:2:"id";i:2418;s:6:"config";a:12:{s:4:"type";s:7:"default";s:12:"slider_theme";s:4:"base";s:12:"slider_width";i:960;s:13:"slider_height";i:300;s:10:"transition";s:4:"fade";s:8:"duration";i:5000;s:5:"speed";i:400;s:6:"gutter";i:20;s:6:"slider";i:1;s:7:"classes";a:1:{i:0;s:0:"";}s:5:"title";s:0:"";s:4:"slug";s:0:"";}}') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=2434 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (224 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2014-02-13 19:12:17', '2014-02-13 19:12:17', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-02-13 19:12:17', '2014-02-13 19:12:17', '', 0, 'http://capstone.jonny.me/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2014-02-13 19:12:17', '2014-02-13 19:12:17', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://capstone.jonny.me/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'publish', 'open', 'open', '', 'sample-page', '', '', '2014-02-13 19:12:17', '2014-02-13 19:12:17', '', 0, 'http://capstone.jonny.me/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2223, 1, '2014-02-21 14:56:39', '2014-02-21 14:56:39', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)
maceachern.jonny@gmail.com


0

[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)
[your-email]


0
Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2014-02-21 14:56:39', '2014-02-21 14:56:39', '', 0, 'http://capstone.jonny.me/?post_type=wpcf7_contact_form&p=2223', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2188, 1, '2014-02-13 19:46:47', '2014-02-13 19:46:47', 'http://capstone.jonny.me/wp-content/uploads/2014/02/cropped-LogoWhite-300x171.png', 'cropped-LogoWhite-300x171.png', '', 'inherit', 'closed', 'open', '', 'cropped-logowhite-300x171-png', '', '', '2014-02-13 19:46:47', '2014-02-13 19:46:47', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/02/cropped-LogoWhite-300x171.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2014-01-15 16:05:08', '2014-01-15 16:05:08', 'Next Big Sound is looking for engineers to focus on front-end development. You should have a passion for shipping elegant, fast web applications that will be used by the music industry.
<div>
<h2>Responsibilities</h2>
<ul>
	<li>Proactively look for ways to make Next Big Sound better</li>
	<li>Write front-end code in PHP, HTML/CSS, and Javascript</li>
	<li>Design of extraction tools using our API</li>
	<li>Work closely with, and incorporate feedback from, product management, designers, and back-end engineers</li>
	<li>Rapidly fix bugs and solve problems</li>
</ul>
</div>
<div>
<h2>Qualifications</h2>
<ul>
	<li>Disciplined approach to testing and quality assurance</li>
	<li>Demonstrable experience building world-class, consumer web application interfaces</li>
	<li>Excellent programming skills in PHP (Codeigniter), Javascript (Backbone, Underscore), CSS (Less)</li>
	<li>Strong command of web standards, CSS-based design, cross-browser compatibility</li>
	<li>Good understanding of web technologies (HTTP, Apache) and familiarity with Unix/Linux</li>
	<li>Knowledgeable foundation in interaction design principles</li>
	<li>Great written communication and documentation abilities</li>
	<li>B.S. or higher in Computer science or equivalent</li>
</ul>
</div>
<div>
<h2>Benefits</h2>
<ul>
	<li>Please contact us to learn more.</li>
</ul>
</div>', 'Front-End Engineer', '', 'publish', 'closed', 'closed', '', 'front-end-engineer', '', '', '2014-01-15 16:05:08', '2014-01-15 16:05:08', '', 0, 'http://demo.astoundify.com/jobify/?post_type=job_listing&amp;p=7', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2014-01-02 16:07:02', '2014-01-02 16:07:02', 'The Amazon.com Universal Shopping Experience team (USX) is seeking a uniquely innovative and highly motivated Design Technologist (Prototyper) to bring to life bold concepts for the future of shopping. In this role, you will use a variety of tools and technologies to prototype new ways of interacting and shopping on the web and devices, with a variety of modalities. You’ll work with a small, highly capable team of designers, researchers and engineers in a studio environment, inventing and iterating on concepts that start and end with the customer. The ideal candidate will have an inventor’s spirit, an eye for detail, a can-do approach, and proficiency in a wide range of languages, platforms and technologies.
<div>
<h2>Responsibilities</h2>
<ul>
	<li>Actively participate in concept development and design ideation as part of a small team.</li>
	<li>Rapidly build and iterate prototypes that push the bounds of today’s computing to prove concepts and test ideas.</li>
	<li>Develop polished, high-fidelity functional prototypes to prove and sell concepts to development teams and senior leadership.</li>
	<li>Partner with engineering to ensure that interactive techniques and technologies translate through to shipping products and services.</li>
</ul>
</div>
<div>
<h2>Qualifications</h2>
<ul>
	<li>BS in Computer Science or related technical field (In lieu of degree, 4 years of relevant work experience).</li>
	<li>At least 3 years’ experience as a key member of a UI design team participating in the complete product development lifecycle of successfully launched applications.</li>
	<li>Proficiency in native mobile development and HTML5/CSS3/JavaScript, with a strong grasp on Object-Oriented thinking.</li>
	<li>Strong interaction and rapid prototype engineering skills across a broad spectrum of technologies including: Native mobile development, e.g. Objective-C/Xcode, HTML5/CSS3/JavaScript, JS frameworks, W3C DOM methods and properties</li>
	<li>Knowledge of web development tools such as Frameworks (e.g. jQuery, Backbone, Bootstrap), Package Management (e.g. Require.js, AMD), Browser Debugging (e.g. Web Inspector, Firebug, WebDev Toolbar), Templating (e.g. Handlebars, Underscore templates), and Preprocessors (e.g. SASS, LESS, CoffeeScript).</li>
	<li>Strong grasp of Physics, Algebra and Calculus and experience with application and modeling, e.g. transitions, gestures, image processing, 3D, etc.</li>
	<li>Portfolio of work that demonstrates detailed attention to typography, color, imagery, motion, and graphic elements</li>
	<li>Preferred: Experience in fetching data from services and screen scraping using a RESTful API (e.g. Twitter, AWS, OAuth).</li>
	<li>Preferred: Experience with Object Oriented JavaScript and modern JavaScript libraries (e.g., Closure, jQuery, Node).</li>
	<li>Preferred: Experience with vector and motion graphics, including SVG, HTML5 Canvas, and Animation via JavaScript and CSS.</li>
	<li>Preferred: Fluency in one or more of: Python/PHP/Ruby, Flash/ActionScript, C, C++ or Java.</li>
	<li>Preferred: Experience with unconventional hardware and software platform. Experience with sensors integration, including basic signal processing.</li>
	<li>Preferred: HCI and research experience, including mobile HCI, tangible interfaces, and physical computing.</li>
</ul>
</div>
<div>
<h2>Benefits</h2>
<ul>
	<li>A choice of four medical plans, including prescription drug coverage, designed to meet your individual needs, with domestic partner coverage</li>
	<li>Dental plan</li>
	<li>Vision plan</li>
	<li>Company-paid basic life and accident coverage as well as optional coverage at a low cost</li>
	<li>Company-paid short- and long-term disability plan</li>
	<li>Employee assistance program including dependent-care referral services and financial/legal services</li>
	<li>Health-care and dependent-care flexible spending accounts</li>
	<li>Salaried employees earn two weeks of vacation time in the first year, three weeks of vacation in the second</li>
	<li>Hourly employees earn 40 hours of vacation time in the first year, 80 hours in the second</li>
	<li>Six personal days every year in addition to six holidays</li>
	<li>401(k) savings plan with a company match</li>
	<li>Several employee discount programs</li>
	<li>Most Amazon employees receive Amazon Restricted Stock Units</li>
	<li>Amazon may provide relocation assistance for certain positions. (Ask your interviewer whether the position is eligible for relocation assistance.)</li>
</ul>
</div>', 'Design Technologist', '', 'publish', 'closed', 'closed', '', 'design-technologist-shopping-innovation', '', '', '2014-03-05 15:24:24', '2014-03-05 15:24:24', '', 0, 'http://demo.astoundify.com/jobify/?post_type=job_listing&#038;p=8', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1721, 1, '2013-12-18 15:47:39', '2013-12-18 15:47:39', 'The web is a giant place, and Dropbox is working to make the gap between computers and the internet much smaller. Dropbox is one of the fastest growing startups anywhere, and we\'re serving companies, schools, and millions of people worldwide. Dropbox is working on big problems; the kind of challenges that give you bragging rights, but we\'re nowhere near finished. Our greatest accomplishments are still waiting for you to build them.

We\'ve got a pretty broad vision for where we want to head next: we want to tie everyone\'s devices and services together to become the file system of the internet. And because we have such a small team, you\'ll be owning huge ideas from the start. Meanwhile, you\'ll join talented teammates to create something that simplifies people\'s lives.
<h2>Benefits &amp; Perks</h2>
<ul>
	<li>Set your own Dropbox storage quota</li>
	<li>Free breakfast, lunch and dinner daily, plus tons of snacks and beverages</li>
	<li>Office across from the SF Giants\' ballpark</li>
	<li>Really flexible hours</li>
	<li>Eighteen days of paid vacation and eleven paid holidays</li>
	<li>If you\'re sick, just stay home and get better</li>
	<li>Subsidized gym and commuter programs, including our very own Dropbox shuttle service within San Francisco</li>
	<li>401(k)</li>
	<li>Vision, dental, life, and health insurance too</li>
	<li>Join the band. Complete music studio equipped with drums, P.A., amplifiers, etc...</li>
	<li>Whiskey Fridays</li>
	<li>Gaming! Starcraft, dedicated game rooms, DDR (yep, a real machine), ping pong, tournaments, and more</li>
</ul>
<h2>Qualifications</h2>
<ul>
	<li>You\'re an experience whisperer -- you can distill complicated problems into simple and elegant solutions.</li>
	<li>You have an understanding of what makes an experience good or bad -- you can think through user problems, find reasonable solutions, then mock them up in detail and work with engineers build them.</li>
	<li>You love making things beautiful, and you have a strong understanding of composition, balance, symmetry, and white-space.</li>
	<li>You have a highly refined aesthetic sense and can both work within and expand the \'Dropbox style\'.</li>
	<li>You\'re a self-starter who actively seeks ways to make the Dropbox experience both visually appealing and easy to use.</li>
	<li>You look for opportunities to solve problems in unique and innovative ways.</li>
	<li>You understand the technical limitations and liberties behind your decisions, and have enough chops to communicate your ideas to engineers.</li>
	<li>You are actively involved in defining product strategy.</li>
	<li>You think in terms of design systems and make rational design decisions.</li>
	<li>You obsess over details, and are excited to polish until your work is pixel-perfect.</li>
	<li>You have plenty of experience designing for the web, and understand how to apply both form and function within it while maintaining simplicity.</li>
	<li>You\'re constantly pushing your limits and searching for opportunities to become better.</li>
	<li>You create your own iconography, set up your own guidelines, and build easy-to-navigate documents.</li>
	<li>Your team collaboration skills are unparalleled.</li>
	<li>You thrive in an environment with short feedback loops.</li>
	<li>You read everything and will paste an html heart character before your first name on the next page.</li>
	<li>You want work on a team of the world\'s best software designers and engineers building a product that you use everyday!</li>
</ul>
<strong>Please include a link to your portfolio - there\'s a spot for it on the application page.</strong>', 'Product Designer', '', 'publish', 'closed', 'closed', '', 'product-designer', '', '', '2013-12-18 15:47:39', '2013-12-18 15:47:39', '', 0, 'http://demo.astoundify.com/jobify/?post_type=job_listing&amp;p=1721', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1726, 1, '2014-01-03 18:07:24', '2014-01-03 18:07:24', 'The Sr. Multimedia Communications Designer will serve as a project manager, designer and driver of design/visual communications strategy to effectively communicate team initiatives, product launches and events.

In this role, the Sr. Multimedia Communications Designer will be highly creative in order to engage external and internal audiences, extend communications messages, and promote Disney Interactive’s suite of games, online properties, apps and digital experiences.

Creative responsibilities include, but are not limited to: presentations, asset management, website development, print mockups, promotional collateral, event deliverables, email communications, graphics, logo design and asset creation, intranet design, and management, and video production.
<h2>Qualifications</h2>
<ul>
	<li>Concept and produce digital media for communication initiatives (presentations, templates, digital signage, graphics, logos, etc.)</li>
	<li>Drive design strategy and vision based on the project needs and direction from the project lead.</li>
	<li>Lead creative development and execution of deliverables (on multiple platforms) for both external and internal audiences.</li>
	<li>Generate new and innovative executive presentations that include sound and video production.</li>
	<li>Design full-scale event creative that extends from signage to promo items.</li>
	<li>Manage all design projects, communicating, strategizing and prioritizing with product teams as needed.</li>
</ul>', 'Senior Designer', '', 'publish', 'closed', 'closed', '', 'senior-designer', '', '', '2014-01-03 18:07:24', '2014-01-03 18:07:24', '', 0, 'http://demo.astoundify.com/jobify/?post_type=job_listing&amp;p=1726', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1728, 1, '2014-01-10 19:08:15', '2014-01-10 19:08:15', 'Foursquare is building a world class sales organization with a mission of reinventing the way marketers connect with consumers at a hyper local level. Our Graphic Designer on the National Sales team will act as a one-person, internal creative services team and sit at the intersection of technology, design and brand building to help our team sell ideas through design thinking.
<div>Your career path may be non-linear, but the underlying theme has been applying design to solve abstract business problems. You understand how to break down a brief and can create a visual solution for almost any challenge. You are ready to apply yourself to building a revenue stream for Foursquare and will be comfortable working with teams ranging from Sales, Operations, Account Management, Product and Data Analytics. You relish the chance to pitch your work to clients and are comfortable with on-the-fly brainstorming. You will pivot daily between ideation, presentation development, content development, writing, designing and thinking about ways to proactively grow revenue.</div>
<div></div>
<h3>Key Responsibilities:</h3>
<ul>
	<li>Concept, design and implement creative solutions in multiple formats to build revenue channels</li>
	<li>Interface with key Monetization team constituencies to provide a creative and design counter perspective to strategic business discussions</li>
	<li>Outbound presentation, product overviews and RFP design elements</li>
	<li>Brainstorming with Account Executives to help bring ideas to brands who want to work with Foursquare</li>
	<li>Fielding inbound requests with little warning on tight timelines</li>
	<li>General problem solving</li>
</ul>
<h3>Requirements:</h3>
<ul>
	<li>3-5 years of experience in design, creative development, UX/UI design or a similar field with a portfolio to represent your work</li>
	<li>Mastery of Keynote, Photoshop, In-Design &amp; Illustrator (After Effects is a plus)</li>
	<li>A portfolio that reflects projects on which you were the sole or lead designer, as well as projects on which you supported a lead designer</li>
	<li>Ability to prioritize in an environment where everything is a priority</li>
	<li>Ability to function as a brand ambassador with senior clients and marketers</li>
	<li>Comfortable with aggressive revenue targets and a willingness to find new ad opportunities with existing industry relationships</li>
</ul>
This position is based in our New York City headquarters in SoHo. We offer competitive compensation packages, including full benefits and equity for all employees.', 'Graphic Designer', '', 'publish', 'closed', 'closed', '', 'graphic-designer', '', '', '2014-01-10 19:08:15', '2014-01-10 19:08:15', '', 0, 'http://demo.astoundify.com/jobify/?post_type=job_listing&amp;p=1728', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2332, 1, '2014-03-19 18:53:59', '2014-03-19 18:53:59', '', 'New Slider', '', 'publish', 'open', 'open', '', 'new-slider-3', '', '', '2014-03-19 18:53:59', '2014-03-19 18:53:59', '', 0, 'http://capstone.jonny.me/?post_type=ml-slider&p=2332', 0, 'ml-slider', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2260, 1, '2014-02-28 05:03:01', '2014-02-28 05:03:01', ' ', '', '', 'publish', 'open', 'open', '', '2260', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2260', 11, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2261, 1, '2014-02-28 05:06:12', '2014-02-28 05:06:12', '[theme-my-login]

[nm-wp-repo]', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-02-28 05:06:12', '2014-02-28 05:06:12', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2217, 1, '2014-02-20 19:28:09', '2014-02-20 19:28:09', '', 'cream_pixels', '', 'inherit', 'open', 'open', '', 'cream_pixels', '', '', '2014-02-20 19:28:09', '2014-02-20 19:28:09', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/02/cream_pixels.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2218, 1, '2014-02-20 19:37:12', '2014-02-20 19:37:12', '', 'HomepageSlider', '', 'publish', 'closed', 'closed', '', '2218', '', '', '2014-04-04 14:32:07', '2014-04-04 14:32:07', '', 0, 'http://capstone.jonny.me/?post_type=soliloquy&#038;p=2218', 0, 'soliloquy', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2014-01-17 16:02:03', '2014-01-17 16:02:03', 'GE is an equal opportunity employer, offering a great work environment, challenging career opportunities, professional training and competitive compensation.

As a User Experience Designer within GE’s New Media Technology team, this candidate will work with the Enterprise Systems organization to define and create best in class experiences for the company. The candidate will clearly and professionally demonstrate exposure to User Experience principles and methodologies, visual design, interaction design and showcase expertise through documented case studies, while having a strong understanding of digital, web and mobile technologies.
<h2>Responsibilities</h2>
<ul>
	<li>Collaboratively lead user research, concept testing, and usability testing by utilizing various methodologies</li>
	<li>Develop and document detailed user experience specifications</li>
	<li>Able to articulate UX concepts and solutions through wireframes and prototypes of varying fidelity</li>
	<li>Create compelling user interfaces through visual design esthetics and the use of typography</li>
	<li>Work with Product Management to provide solutions to market requirements that are innovative and functional</li>
</ul>
<div>
<h2>Qualifications</h2>
<ul>
	<li>Bachelor’s Degree in Management Information Systems, Graphic Design or a related field</li>
	<li>Minimum 8 years of experience as an Interaction Designer or UI Designer</li>
	<li>Minimum 4 years of experience executing high-profile web projects</li>
	<li>Minimum 4 years of experience with web and mobile technologies such as: HTML5, JavaScript, AJAX, Mobile SDKs, etc.</li>
	<li>Must provide a portfolio (web or PDF) clearly demonstrating the different processes of User Experience</li>
	<li>Must submit your application for employment through COS (Internal Candidates) or GECareers.com (External Candidates) to be considered for this opening</li>
	<li>Must be 18 years of age or older</li>
	<li>GE will only employ those who are legally authorized to work in the United States for this opening. Any offer of employment is conditioned upon the successful completion of a background investigation and drug screen.</li>
	<li>Must be willing to work out of an office in Van Buren Township, Michigan</li>
	<li>Must be able to satisfy the requirements of Section 19 of the Federal Deposit Insurance Act</li>
</ul>
</div>
<div>
<h2>Benefits</h2>
<ul>
	<li>GE strives to provide competitive employee benefits packages in the regions and industries in which we have a presence. Our wide range of employee services, retirement, health and other benefit plans are designed to help eligible employees make the best decisions for themselves, their family, and their lifestyle.</li>
</ul>
</div>', 'User Experience Designer (Lead Systems Analyst)', '', 'publish', 'closed', 'closed', '', 'user-experience-designer-lead-systems-analyst', '', '', '2014-01-17 16:02:03', '2014-01-17 16:02:03', '', 0, 'http://demo.astoundify.com/jobify/?post_type=job_listing&amp;p=6', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2146, 1, '2014-01-19 23:51:27', '2014-01-19 23:51:27', 'Working across many media, both online and offline, you will ensure brand consistency across all channels of communication. You will utilize your visual and interactive design skills to incorporate the Optimizely aesthetic into everything you create. You will work closely with marketing, customer success, sales and the rest of our growing company to explore design solutions that help our customers understand our product. The types of projects you will work on include creative brand and product marketing campaigns, sales and marketing materials, and user education projects.

<strong>About Us:</strong>
<ul>
	<li>Optimizely is a website optimization platform.  We help businesses show the right content to the right people at the right time.</li>
	<li>Our first product makes A/B Testing easy. In &gt;2 years we’ve grown to become #1 in the category with 6,500+ paying customers including Disney, Marketo and Salesforce.com.</li>
	<li>We\'ve raised over $30 million to grow internationally and open offices around the world.</li>
	<li>Join us in our mission to empower businesses to make better data-driven decisions.</li>
</ul>
<strong>Requirements:</strong>
<ul>
	<li>2+ years of relevant work experience</li>
	<li>Experience designing for the Web and knowledge of HTML/CSS</li>
	<li>Pixel-perfect attention to detail; no details are too small or insignificant</li>
	<li>Exceptional communication skills; the ability to clearly explain design decisions to anyone in the company</li>
	<li>Expert knowledge of Adobe Creative Suite (Photoshop, Illustrator, InDesign)</li>
	<li>Experience owning a wide variety of print projects from concept through completion</li>
	<li>Familiarity with printing processes, materials and techniques, and experience working with printers, a plus</li>
	<li>Must have a portfolio showcasing graphic, illustration, and interface design projects</li>
</ul>
<strong>Perks:</strong>
<ul>
	<li>Very competitive salary &amp; equity compensation</li>
	<li>Full health, dental, vision</li>
	<li>401k benefits</li>
	<li>Gym membership</li>
	<li>Catered lunches</li>
	<li>Unlimited vacation</li>
	<li>Clipper Cards for commute</li>
	<li>Company events: karaoke, show-n-tells, ski trips, retreats</li>
	<li>Top-of-the-line MacBook Pro and 27" monitor - in fact, any gear you want that will improve your productivity.</li>
</ul>', 'Communication Designer', '', 'publish', 'closed', 'closed', '', 'communication-designer', '', '', '2014-01-19 23:51:27', '2014-01-19 23:51:27', '', 0, 'http://demo.astoundify.com/jobify-darker/?post_type=job_listing&amp;p=2146', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2168, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'facebook', '', 'publish', 'open', 'open', '', 'facebook', '', '', '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 0, 'http://capstone.jonny.me/?p=2168', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2169, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'vimeo', '', 'publish', 'open', 'open', '', 'vimeo', '', '', '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 0, 'http://capstone.jonny.me/?p=2169', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2170, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'linkedin', '', 'publish', 'open', 'open', '', 'linkedin', '', '', '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 0, 'http://capstone.jonny.me/?p=2170', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2171, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'Jobify Pages', '', 'publish', 'open', 'open', '', 'jobify-pages', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2171', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2172, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'twitter', '', 'publish', 'open', 'open', '', 'twitter', '', '', '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 0, 'http://capstone.jonny.me/?p=2172', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2173, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'google', '', 'publish', 'open', 'open', '', 'google', '', '', '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 0, 'http://capstone.jonny.me/?p=2173', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2174, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'instagram', '', 'publish', 'open', 'open', '', 'instagram', '', '', '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 0, 'http://capstone.jonny.me/?p=2174', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2175, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'pinterest', '', 'publish', 'open', 'open', '', 'pinterest', '', '', '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 0, 'http://capstone.jonny.me/?p=2175', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2013-06-12 16:12:41', '2013-06-12 16:12:41', '[submit_job_form]', 'Post A Job', '', 'publish', 'closed', 'closed', '', 'post-a-job', '', '', '2013-06-12 16:12:41', '2013-06-12 16:12:41', '', 0, 'http://demo.astoundify.com/jobify/?page_id=14', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2013-07-16 18:58:08', '2013-07-16 18:58:08', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-04-11 13:56:38', '2014-04-11 13:56:38', '', 0, 'http://demo.astoundify.com/jobify/?page_id=25', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (703, 1, '2011-05-20 18:51:43', '2011-05-21 01:51:43', 'Use this static Page to test the Theme\'s handling of the Blog Posts Index page. If the site is set to display a static Page on the Front Page, and this Page is set to display the Blog Posts Index, then this text should not appear.', 'Blog', '', 'publish', 'open', 'closed', '', 'blog', '', '', '2011-05-20 18:51:43', '2011-05-21 01:51:43', '', 0, 'http://wpthemetestdata.wordpress.com/?page_id=703', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1671, 1, '2013-07-17 14:20:54', '2013-07-17 14:20:54', '[jobify_login_form]', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2013-07-17 14:20:54', '2013-07-17 14:20:54', '', 0, 'http://demo.astoundify.com/jobify/?page_id=1671', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1673, 1, '2013-07-17 14:21:21', '2013-07-17 14:21:21', '', 'Plans & Pricing', '', 'publish', 'closed', 'closed', '', 'plans-pricing', '', '', '2013-07-17 14:21:21', '2013-07-17 14:21:21', '', 0, 'http://demo.astoundify.com/jobify/?page_id=1673', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1719, 1, '2013-07-18 15:31:21', '2013-07-18 15:31:21', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2013-07-18 15:31:21', '2013-07-18 15:31:21', '', 0, 'http://demo.astoundify.com/jobify/?page_id=1719', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1760, 1, '2013-07-19 19:25:42', '2013-07-19 19:25:42', '<div>
<h1>Terms of Use for Members</h1>
By using our website you automatically agree to the following terms.

</div>
<div>
<h2>General Terms</h2>
</div>
Members invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Member Priviliges</h2>
</div>
By accepting this agreement the member gains the following privileges:
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment</li>
</ul>
<div>
<h2>Member Restricted Priviliges</h2>
</div>
It is important to remember that members may only deactivate their accounts through Student Services.
<div>
<h2>Member Liabilities</h2>
</div>
All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>
<div>
<h1>Term of Use for Employers (Pop-Up Box on First Launch)</h1>
</div>
<div>
<h2>General Terms</h2>
</div>
Employers invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Employer Priviliges</h2>
</div>
By accepting this agreement the employer gains the following privileges:
<ul>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
<h3></h3>
&nbsp;
<div>
<h2>Employer RESTRICTED PRIVILIGES</h2>
</div>
<b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>', 'Terms and Conditions', '', 'publish', 'closed', 'closed', '', 'terms-and-conditions', '', '', '2014-03-20 16:10:13', '2014-03-20 16:10:13', '', 0, 'http://demo.astoundify.com/jobify/?page_id=1760', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1762, 1, '2013-07-19 19:36:50', '2013-07-19 19:36:50', '<div>

<i>Last Updated:  3/20/2014</i>

&nbsp;

</div>
<div>
<h1>Security</h1>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .

&nbsp;
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<h1>Use of Information</h1>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'publish', 'closed', 'closed', '', 'privacy-policy', '', '', '2014-05-13 14:22:55', '2014-05-13 14:22:55', '', 0, 'http://demo.astoundify.com/jobify/?page_id=1762', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2425, 1, '2014-05-13 14:25:31', '2014-05-13 14:25:31', '<h3>Contact Information:</h3>
Marc Scarfone

Faculty, Information Technology Program

IT Campus, Halifax, Nova Scotia, Canada
<h3>Phone:   (902) 491-5112</h3>
&nbsp;
<h3>Send us an E-Mail!</h3>
<h3>[contact-form-7 id="2324" title="Main Contact"]</h3>', 'Contact', '', 'inherit', 'open', 'open', '', '1882-revision-v1', '', '', '2014-05-13 14:25:31', '2014-05-13 14:25:31', '', 1882, 'http://capstone.jonny.me/1882-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2426, 1, '2014-05-13 14:26:07', '2014-05-13 14:26:07', '<h3>Contact Information:</h3>
Marc Scarfone

Faculty, Information Technology Program

IT Campus, Halifax, Nova Scotia, Canada

Phone:   (902) 491-5112

&nbsp;
<h3>Send us an E-Mail!</h3>
<h3>[contact-form-7 id="2324" title="Main Contact"]</h3>', 'Contact', '', 'inherit', 'open', 'open', '', '1882-revision-v1', '', '', '2014-05-13 14:26:07', '2014-05-13 14:26:07', '', 1882, 'http://capstone.jonny.me/1882-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2427, 50, '2014-05-14 18:39:07', '2014-05-14 18:39:07', '<p>blah blah blah</p>', 'Programmer', '', 'publish', 'closed', 'open', '', 'programmer', '', '', '2014-05-14 18:47:11', '2014-05-14 18:47:11', '', 0, 'http://capstone.jonny.me/job/scarfone-incorporated-halifax-programming-programmer/', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2428, 46, '2014-05-16 17:11:07', '2014-05-16 17:11:07', '<p>sfasdfsasad</p>', 'fake job programmer', '', 'publish', 'closed', 'open', '', 'fake-job-programmer', '', '', '2014-05-16 17:14:13', '2014-05-16 17:14:13', '', 0, 'http://capstone.jonny.me/job/fake-company-halifax-computer-electronics-technician-fake-job-programmer/', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1765, 1, '2013-07-19 19:37:41', '2013-07-19 19:37:41', '', 'Pricing & Plans', '', 'publish', 'closed', 'closed', '', 'pricing-plans', '', '', '2013-07-19 19:37:41', '2013-07-19 19:37:41', '', 0, 'http://demo.astoundify.com/jobify/?page_id=1765', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1882, 1, '2013-07-23 00:49:28', '2013-07-23 00:49:28', '<h3>Contact Information:</h3>
Marc Scarfone

Faculty, Information Technology Program

IT Campus, Halifax, Nova Scotia, Canada

Phone:   (902) 491-5112

&nbsp;
<h3>Send us an E-Mail!</h3>
<h3>[contact-form-7 id="2324" title="Main Contact"]</h3>', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2014-05-13 14:26:07', '2014-05-13 14:26:07', '', 0, 'http://demo.astoundify.com/jobify/?page_id=1882', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2321, 1, '2014-03-07 16:22:34', '2014-03-07 16:22:34', '<h3>Contact Information:</h3>

Full Name: Scarfone, Marc
Business Title: NSCC Faculty
Department: InfoTechY2SysMgmt Network

<h3>Phone:</h3>
Need to speak with someone?

Phone: (902) 491-5112

<h3>Send us an E-Mail!</h3>

Temporary filler', 'Contact', '', 'inherit', 'open', 'open', '', '1882-revision-v1', '', '', '2014-03-07 16:22:34', '2014-03-07 16:22:34', '', 1882, 'http://capstone.jonny.me/1882-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2320, 1, '2014-03-07 16:22:11', '2014-03-07 16:22:11', '<h3>Mailing Address:</h3>
We love getting stuff in the mail.

Full Name: Scarfone, Marc
Business Title: NSCC Faculty
Department: InfoTechY2SysMgmt Network

<h3>Phone:</h3>
Need to speak with someone?

Phone: (902) 491-5112

<h3>Send us an E-Mail!</h3>

Temporary filler', 'Contact', '', 'inherit', 'open', 'open', '', '1882-revision-v1', '', '', '2014-03-07 16:22:11', '2014-03-07 16:22:11', '', 1882, 'http://capstone.jonny.me/1882-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1915, 1, '2013-07-23 19:40:23', '2013-07-23 19:40:23', '[job_dashboard]', 'Manage Jobs', '', 'publish', 'closed', 'closed', '', 'manage-jobs', '', '', '2013-07-23 19:40:23', '2013-07-23 19:40:23', '', 0, 'http://demo.astoundify.com/jobify-darker/?page_id=1915', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2176, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', ' ', '', '', 'publish', 'open', 'open', '', '2176', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2176', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2177, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', ' ', '', '', 'publish', 'open', 'open', '', '2177', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2177', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2178, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', ' ', '', '', 'publish', 'open', 'open', '', '2178', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2178', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2179, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', '', 'Our Terms', '', 'publish', 'open', 'open', '', 'our-terms', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2179', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2180, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', ' ', '', '', 'publish', 'open', 'open', '', '2180', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2180', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2182, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', ' ', '', '', 'publish', 'open', 'open', '', '2182', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2182', 10, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2183, 1, '2014-02-13 19:26:59', '2014-02-13 19:26:59', ' ', '', '', 'publish', 'open', 'open', '', '2183', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2183', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1668, 1, '2013-07-17 12:52:13', '2013-07-17 12:52:13', '', 'Main Slider', '', 'publish', 'closed', 'closed', '', 'main-slider', '', '', '2014-04-04 14:32:08', '2014-04-04 14:32:08', '', 0, 'http://demo.astoundify.com/jobify/?post_type=soliloquy&#038;p=1668', 0, 'soliloquy', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1684, 1, '2013-07-17 20:25:13', '2013-07-17 20:25:13', '', 'Jobify', '', 'publish', 'closed', 'closed', '', 'jobify', '', '', '2013-07-17 20:25:13', '2013-07-17 20:25:13', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1684', 7, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1687, 1, '2013-07-17 20:24:26', '2013-07-17 20:24:26', '', 'Astoundify', '', 'publish', 'closed', 'closed', '', 'astoundify', '', '', '2013-07-17 20:24:26', '2013-07-17 20:24:26', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1687', 6, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1689, 1, '2013-07-17 20:48:57', '2013-07-17 20:48:57', '', 'Classify', '', 'publish', 'closed', 'closed', '', 'classify', '', '', '2013-07-17 20:48:57', '2013-07-17 20:48:57', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1689', 5, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1691, 1, '2013-07-17 20:51:11', '2013-07-17 20:51:11', '', 'Campaignify', '', 'publish', 'closed', 'closed', '', 'campaignify', '', '', '2013-07-17 20:51:11', '2013-07-17 20:51:11', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1691', 4, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1693, 1, '2013-07-17 20:53:20', '2013-07-17 20:53:20', '', 'Marketify', '', 'publish', 'closed', 'closed', '', 'marketify', '', '', '2013-07-17 20:53:20', '2013-07-17 20:53:20', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1693', 3, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1712, 1, '2013-07-18 14:26:18', '2013-07-18 14:26:18', 'Excellent service offering a personal touch, if I had an issue they were no longer than a phone call away and were always quick to respond.', 'Spencer Pratt', '', 'publish', 'closed', 'closed', '', 'spencer-finnell', '', '', '2013-07-18 14:26:18', '2013-07-18 14:26:18', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1712', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1713, 1, '2013-07-18 14:28:11', '2013-07-18 14:28:11', 'Jobify offer an amazing service and I couldn\'t be happier! They are dedicated to helping recruiters find great candidates, wonderful service!', 'Adam Levine', '', 'publish', 'closed', 'closed', '', 'adam-levine', '', '', '2013-07-18 14:28:11', '2013-07-18 14:28:11', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1713', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1767, 1, '2013-07-19 20:55:16', '2013-07-19 20:55:16', 'A job is a regular activity performed in exchange for payment. A person usually begins a job by becoming an employee, volunteering, or starting a business. The duration of a job may range from an hour (in the case of odd jobs) to a lifetime (in the case of some judges). If a person is trained for a certain type of job, they may have a profession. The series of jobs a person holds in their life is their career.
Jobs for people

Generally people spend a good portion of their time doing a regular occupation. Some exceptions are being a student, disabled, retired or being/working in a creative field.
<h3>Types of job</h3>
There are a variety of jobs: full time, part time, temporary, odd jobs, seasonal, self-employment.
People may have a chosen occupation for which they have received training or a degree.
Those who do not hold down a steady job may do odd jobs or be unemployed.
Moonlighting is the practice of holding an additional job or jobs, often at night, in addition to one\'s main job, usually to earn extra income. A person who moonlights may have little time left for sleep or leisure activities.
<h3>Day job</h3>
The expression day job is often used for a job one works in to make ends meet while performing low-paying (or non-paying) work in their preferred vocation. Archetypical examples of this are the woman who works as a waitress (her day job) while she tries to become an actress, and the professional athlete who works as a laborer in the off season because he is currently only able to make the roster of a semi-professional team.
While many people do hold a full-time occupation, "day job" specifically refers to those who hold the position solely to pay living expenses so they can pursue, through low paying entry work, the job they really want (which may also be during the day). The phrase strongly implies that the day job would be quit, if only the real vocation paid a living wage.

Notable figures who had day jobs include the Wright brothers, who held full-time employment as bicycle repairmen while they experimented on powered flights.

The phrase "don\'t quit your day job" is a humorous response to a poor or mediocre performance not up to professional caliber. The phrase implies that the performer is not talented enough in that activity to be able to make a career out of it. Getting a job Further information: Job hunting and Employment

Getting a first job is an important rite of passage in many cultures. Youth may start by doing household work, odd jobs, or working for a family business. In many countries, school children get summer jobs during the longer summer vacation. Students enrolled in higher education can apply for internships.
Résumés summarize a person\'s education and job experience for potential employers. Employers read job candidate résumés to decide who to interview for an open position.
<h3>Use of the word</h3>
Labourers often talk of "getting a job", or "having a job". This conceptual metaphor of a "job" as a possession has led to its use in slogans such as "money for jobs, not bombs". Similar conceptions are that of "land" as a possession (real estate) or intellectual rights as a possession (intellectual property).

The Online Etymology Dictionary explains that the origin of "job" is from the obsolete phrase "jobbe of work" in the sense of "piece of work", and most dictionaries list the Middle English "gobbe" meaning "lump" (gob) as the origin of "jobbe". Attempts to link the word to the biblical character Job seem to be folk etymology', 'Canada adds 12,500 jobs in modest July rebound', '', 'publish', 'open', 'closed', '', 'canada-adds-12500-jobs-in-modest-july-rebound', '', '', '2013-07-19 20:55:16', '2013-07-19 20:55:16', '', 0, 'http://demo.astoundify.com/jobify/?p=1767', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1778, 1, '2013-07-20 20:47:13', '2013-07-20 20:47:13', '', 'App Slider', '', 'publish', 'closed', 'closed', '', 'app-slide', '', '', '2014-04-04 14:32:08', '2014-04-04 14:32:08', '', 0, 'http://demo.astoundify.com/jobify/?post_type=soliloquy&#038;p=1778', 0, 'soliloquy', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1799, 1, '2013-07-22 19:07:28', '2013-07-22 19:07:28', 'A job is a regular activity performed in exchange for payment. A person usually begins a job by becoming an employee, volunteering, or starting a business. The duration of a job may range from an hour (in the case of odd jobs) to a lifetime (in the case of some judges). If a person is trained for a certain type of job, they may have a profession. The series of jobs a person holds in their life is their career.
Jobs for people

Generally people spend a good portion of their time doing a regular occupation. Some exceptions are being a student, disabled, retired or being/working in a creative field.
<h3>Types of job</h3>
There are a variety of jobs: full time, part time, temporary, odd jobs, seasonal, self-employment.
People may have a chosen occupation for which they have received training or a degree.
Those who do not hold down a steady job may do odd jobs or be unemployed.
Moonlighting is the practice of holding an additional job or jobs, often at night, in addition to one\'s main job, usually to earn extra income. A person who moonlights may have little time left for sleep or leisure activities.
<h3>Day job</h3>
The expression day job is often used for a job one works in to make ends meet while performing low-paying (or non-paying) work in their preferred vocation. Archetypical examples of this are the woman who works as a waitress (her day job) while she tries to become an actress, and the professional athlete who works as a laborer in the off season because he is currently only able to make the roster of a semi-professional team.
While many people do hold a full-time occupation, "day job" specifically refers to those who hold the position solely to pay living expenses so they can pursue, through low paying entry work, the job they really want (which may also be during the day). The phrase strongly implies that the day job would be quit, if only the real vocation paid a living wage.

Notable figures who had day jobs include the Wright brothers, who held full-time employment as bicycle repairmen while they experimented on powered flights.

The phrase "don\'t quit your day job" is a humorous response to a poor or mediocre performance not up to professional caliber. The phrase implies that the performer is not talented enough in that activity to be able to make a career out of it. Getting a job Further information: Job hunting and Employment

Getting a first job is an important rite of passage in many cultures. Youth may start by doing household work, odd jobs, or working for a family business. In many countries, school children get summer jobs during the longer summer vacation. Students enrolled in higher education can apply for internships.
Résumés summarize a person\'s education and job experience for potential employers. Employers read job candidate résumés to decide who to interview for an open position.
<h3>Use of the word</h3>
Labourers often talk of "getting a job", or "having a job". This conceptual metaphor of a "job" as a possession has led to its use in slogans such as "money for jobs, not bombs". Similar conceptions are that of "land" as a possession (real estate) or intellectual rights as a possession (intellectual property).

The Online Etymology Dictionary explains that the origin of "job" is from the obsolete phrase "jobbe of work" in the sense of "piece of work", and most dictionaries list the Middle English "gobbe" meaning "lump" (gob) as the origin of "jobbe". Attempts to link the word to the biblical character Job seem to be folk etymology', 'Do you have a job that the average person doesn\'t even know exists?', '', 'publish', 'open', 'open', '', 'do-you-have-a-job-that-the-average-person-doesnt-even-know-exists', '', '', '2013-07-22 19:07:28', '2013-07-22 19:07:28', '', 0, 'http://demo.astoundify.com/jobify/?p=1799', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1806, 1, '2013-07-22 19:12:11', '2013-07-22 19:12:11', 'A job is a regular activity performed in exchange for payment. A person usually begins a job by becoming an employee, volunteering, or starting a business. The duration of a job may range from an hour (in the case of odd jobs) to a lifetime (in the case of some judges). If a person is trained for a certain type of job, they may have a profession. The series of jobs a person holds in their life is their career.
Jobs for people

Generally people spend a good portion of their time doing a regular occupation. Some exceptions are being a student, disabled, retired or being/working in a creative field.
<h3>Types of job</h3>
There are a variety of jobs: full time, part time, temporary, odd jobs, seasonal, self-employment.
People may have a chosen occupation for which they have received training or a degree.
Those who do not hold down a steady job may do odd jobs or be unemployed.
Moonlighting is the practice of holding an additional job or jobs, often at night, in addition to one\'s main job, usually to earn extra income. A person who moonlights may have little time left for sleep or leisure activities.
<h3>Day job</h3>
The expression day job is often used for a job one works in to make ends meet while performing low-paying (or non-paying) work in their preferred vocation. Archetypical examples of this are the woman who works as a waitress (her day job) while she tries to become an actress, and the professional athlete who works as a laborer in the off season because he is currently only able to make the roster of a semi-professional team.
While many people do hold a full-time occupation, "day job" specifically refers to those who hold the position solely to pay living expenses so they can pursue, through low paying entry work, the job they really want (which may also be during the day). The phrase strongly implies that the day job would be quit, if only the real vocation paid a living wage.

Notable figures who had day jobs include the Wright brothers, who held full-time employment as bicycle repairmen while they experimented on powered flights.

The phrase "don\'t quit your day job" is a humorous response to a poor or mediocre performance not up to professional caliber. The phrase implies that the performer is not talented enough in that activity to be able to make a career out of it. Getting a job Further information: Job hunting and Employment

Getting a first job is an important rite of passage in many cultures. Youth may start by doing household work, odd jobs, or working for a family business. In many countries, school children get summer jobs during the longer summer vacation. Students enrolled in higher education can apply for internships.
Résumés summarize a person\'s education and job experience for potential employers. Employers read job candidate résumés to decide who to interview for an open position.
<h3>Use of the word</h3>
Labourers often talk of "getting a job", or "having a job". This conceptual metaphor of a "job" as a possession has led to its use in slogans such as "money for jobs, not bombs". Similar conceptions are that of "land" as a possession (real estate) or intellectual rights as a possession (intellectual property).

The Online Etymology Dictionary explains that the origin of "job" is from the obsolete phrase "jobbe of work" in the sense of "piece of work", and most dictionaries list the Middle English "gobbe" meaning "lump" (gob) as the origin of "jobbe". Attempts to link the word to the biblical character Job seem to be folk etymology', 'Middle Class jobs are being replaced by burger-flipping, retail sales, low-pay jobs', '', 'publish', 'open', 'open', '', 'middle-class-jobs-are-being-replaced-by-burger-flipping-retail-sales-and-other-lousy-low-pay', '', '', '2013-07-22 19:12:11', '2013-07-22 19:12:11', '', 0, 'http://demo.astoundify.com/jobify/?p=1806', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1862, 1, '2013-07-22 21:22:14', '2013-07-22 21:22:14', 'A job is a regular activity performed in exchange for payment. A person usually begins a job by becoming an employee, volunteering, or starting a business. The duration of a job may range from an hour (in the case of odd jobs) to a lifetime (in the case of some judges). If a person is trained for a certain type of job, they may have a profession. The series of jobs a person holds in their life is their career.
Jobs for people

Generally people spend a good portion of their time doing a regular occupation. Some exceptions are being a student, disabled, retired or being/working in a creative field.
<h3>Types of job</h3>
There are a variety of jobs: full time, part time, temporary, odd jobs, seasonal, self-employment.
People may have a chosen occupation for which they have received training or a degree.
Those who do not hold down a steady job may do odd jobs or be unemployed.
Moonlighting is the practice of holding an additional job or jobs, often at night, in addition to one\'s main job, usually to earn extra income. A person who moonlights may have little time left for sleep or leisure activities.
<h3>Day job</h3>
The expression day job is often used for a job one works in to make ends meet while performing low-paying (or non-paying) work in their preferred vocation. Archetypical examples of this are the woman who works as a waitress (her day job) while she tries to become an actress, and the professional athlete who works as a laborer in the off season because he is currently only able to make the roster of a semi-professional team.
While many people do hold a full-time occupation, "day job" specifically refers to those who hold the position solely to pay living expenses so they can pursue, through low paying entry work, the job they really want (which may also be during the day). The phrase strongly implies that the day job would be quit, if only the real vocation paid a living wage.

Notable figures who had day jobs include the Wright brothers, who held full-time employment as bicycle repairmen while they experimented on powered flights.

The phrase "don\'t quit your day job" is a humorous response to a poor or mediocre performance not up to professional caliber. The phrase implies that the performer is not talented enough in that activity to be able to make a career out of it. Getting a job Further information: Job hunting and Employment

Getting a first job is an important rite of passage in many cultures. Youth may start by doing household work, odd jobs, or working for a family business. In many countries, school children get summer jobs during the longer summer vacation. Students enrolled in higher education can apply for internships.
Résumés summarize a person\'s education and job experience for potential employers. Employers read job candidate résumés to decide who to interview for an open position.
<h3>Use of the word</h3>
Labourers often talk of "getting a job", or "having a job". This conceptual metaphor of a "job" as a possession has led to its use in slogans such as "money for jobs, not bombs". Similar conceptions are that of "land" as a possession (real estate) or intellectual rights as a possession (intellectual property).

The Online Etymology Dictionary explains that the origin of "job" is from the obsolete phrase "jobbe of work" in the sense of "piece of work", and most dictionaries list the Middle English "gobbe" meaning "lump" (gob) as the origin of "jobbe". Attempts to link the word to the biblical character Job seem to be folk etymology', 'Canada adds 12,500 jobs in modest July rebound, good times ahead?', '', 'publish', 'open', 'open', '', 'canada-adds-12500-jobs-in-modest-july-rebound-which-is-a-good-sign', '', '', '2013-07-22 21:22:14', '2013-07-22 21:22:14', '', 0, 'http://demo.astoundify.com/jobify/?p=1862', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1863, 1, '2013-07-22 21:22:14', '2013-07-22 21:22:14', 'A job is a regular activity performed in exchange for payment. A person usually begins a job by becoming an employee, volunteering, or starting a business. The duration of a job may range from an hour (in the case of odd jobs) to a lifetime (in the case of some judges). If a person is trained for a certain type of job, they may have a profession. The series of jobs a person holds in their life is their career.
Jobs for people

Generally people spend a good portion of their time doing a regular occupation. Some exceptions are being a student, disabled, retired or being/working in a creative field.
<h3>Types of job</h3>
There are a variety of jobs: full time, part time, temporary, odd jobs, seasonal, self-employment.
People may have a chosen occupation for which they have received training or a degree.
Those who do not hold down a steady job may do odd jobs or be unemployed.
Moonlighting is the practice of holding an additional job or jobs, often at night, in addition to one\'s main job, usually to earn extra income. A person who moonlights may have little time left for sleep or leisure activities.
<h3>Day job</h3>
The expression day job is often used for a job one works in to make ends meet while performing low-paying (or non-paying) work in their preferred vocation. Archetypical examples of this are the woman who works as a waitress (her day job) while she tries to become an actress, and the professional athlete who works as a laborer in the off season because he is currently only able to make the roster of a semi-professional team.
While many people do hold a full-time occupation, "day job" specifically refers to those who hold the position solely to pay living expenses so they can pursue, through low paying entry work, the job they really want (which may also be during the day). The phrase strongly implies that the day job would be quit, if only the real vocation paid a living wage.

Notable figures who had day jobs include the Wright brothers, who held full-time employment as bicycle repairmen while they experimented on powered flights.

The phrase "don\'t quit your day job" is a humorous response to a poor or mediocre performance not up to professional caliber. The phrase implies that the performer is not talented enough in that activity to be able to make a career out of it. Getting a job Further information: Job hunting and Employment

Getting a first job is an important rite of passage in many cultures. Youth may start by doing household work, odd jobs, or working for a family business. In many countries, school children get summer jobs during the longer summer vacation. Students enrolled in higher education can apply for internships.
Résumés summarize a person\'s education and job experience for potential employers. Employers read job candidate résumés to decide who to interview for an open position.
<h3>Use of the word</h3>
Labourers often talk of "getting a job", or "having a job". This conceptual metaphor of a "job" as a possession has led to its use in slogans such as "money for jobs, not bombs". Similar conceptions are that of "land" as a possession (real estate) or intellectual rights as a possession (intellectual property).

The Online Etymology Dictionary explains that the origin of "job" is from the obsolete phrase "jobbe of work" in the sense of "piece of work", and most dictionaries list the Middle English "gobbe" meaning "lump" (gob) as the origin of "jobbe". Attempts to link the word to the biblical character Job seem to be folk etymology', 'Middle Class jobs are being replaced by burger-flipping, retail sales, low-pay jobs', '', 'publish', 'open', 'open', '', 'middle-class-jobs-are-being-replaced-by-burger-flipping-retail-sales-low-pay-jobs-4', '', '', '2013-07-22 21:22:14', '2013-07-22 21:22:14', '', 0, 'http://demo.astoundify.com/jobify/?p=1863', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1864, 1, '2013-07-22 21:22:14', '2013-07-22 21:22:14', 'A job is a regular activity performed in exchange for payment. A person usually begins a job by becoming an employee, volunteering, or starting a business. The duration of a job may range from an hour (in the case of odd jobs) to a lifetime (in the case of some judges). If a person is trained for a certain type of job, they may have a profession. The series of jobs a person holds in their life is their career.
Jobs for people

Generally people spend a good portion of their time doing a regular occupation. Some exceptions are being a student, disabled, retired or being/working in a creative field.
<h3>Types of job</h3>
There are a variety of jobs: full time, part time, temporary, odd jobs, seasonal, self-employment.
People may have a chosen occupation for which they have received training or a degree.
Those who do not hold down a steady job may do odd jobs or be unemployed.
Moonlighting is the practice of holding an additional job or jobs, often at night, in addition to one\'s main job, usually to earn extra income. A person who moonlights may have little time left for sleep or leisure activities.
<h3>Day job</h3>
The expression day job is often used for a job one works in to make ends meet while performing low-paying (or non-paying) work in their preferred vocation. Archetypical examples of this are the woman who works as a waitress (her day job) while she tries to become an actress, and the professional athlete who works as a laborer in the off season because he is currently only able to make the roster of a semi-professional team.
While many people do hold a full-time occupation, "day job" specifically refers to those who hold the position solely to pay living expenses so they can pursue, through low paying entry work, the job they really want (which may also be during the day). The phrase strongly implies that the day job would be quit, if only the real vocation paid a living wage.

Notable figures who had day jobs include the Wright brothers, who held full-time employment as bicycle repairmen while they experimented on powered flights.

The phrase "don\'t quit your day job" is a humorous response to a poor or mediocre performance not up to professional caliber. The phrase implies that the performer is not talented enough in that activity to be able to make a career out of it. Getting a job Further information: Job hunting and Employment

Getting a first job is an important rite of passage in many cultures. Youth may start by doing household work, odd jobs, or working for a family business. In many countries, school children get summer jobs during the longer summer vacation. Students enrolled in higher education can apply for internships.
Résumés summarize a person\'s education and job experience for potential employers. Employers read job candidate résumés to decide who to interview for an open position.
<h3>Use of the word</h3>
Labourers often talk of "getting a job", or "having a job". This conceptual metaphor of a "job" as a possession has led to its use in slogans such as "money for jobs, not bombs". Similar conceptions are that of "land" as a possession (real estate) or intellectual rights as a possession (intellectual property).

The Online Etymology Dictionary explains that the origin of "job" is from the obsolete phrase "jobbe of work" in the sense of "piece of work", and most dictionaries list the Middle English "gobbe" meaning "lump" (gob) as the origin of "jobbe". Attempts to link the word to the biblical character Job seem to be folk etymology', 'Fitness industry leading the charge on hiring in the UK and Ireland', '', 'publish', 'open', 'open', '', 'fitness-industry-leading-the-charge-on-hiring-in-the-uk-and-ireland', '', '', '2013-07-22 21:22:14', '2013-07-22 21:22:14', '', 0, 'http://demo.astoundify.com/jobify/?p=1864', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1943, 1, '2013-07-26 01:46:09', '2013-07-26 01:46:09', '[jobify_register_form]', 'Sign Up', '', 'publish', 'closed', 'closed', '', 'sign-up', '', '', '2013-07-26 01:46:09', '2013-07-26 01:46:09', '', 0, 'http://demo.astoundify.com/jobify-darker/?page_id=1943', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2069, 1, '2014-01-17 21:28:41', '2014-01-17 21:28:41', '', 'Find A Job', '', 'publish', 'closed', 'closed', '', 'find-a-job', '', '', '2014-01-17 21:28:41', '2014-01-17 21:28:41', '', 0, 'http://demo.astoundify.com/jobify-darker/?page_id=2069', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1714, 1, '2013-07-18 14:30:22', '2013-07-18 14:30:22', 'If I didn\'t find Jobify I\'m pretty sure i\'d be no where, they helped me find a job in less than 2 days and the job is amazing,  amazing service!', 'Liam Neeson', '', 'publish', 'closed', 'closed', '', 'liam-neeson', '', '', '2013-07-18 14:30:22', '2013-07-18 14:30:22', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1714', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1715, 1, '2013-07-18 14:30:55', '2013-07-18 14:30:55', 'Wow just Wow! Jobify is an excellent service that offers personal one to one help finding a job and they know how to please, i\'d use them again!', 'Jason Statham', '', 'publish', 'closed', 'closed', '', 'jason-statham', '', '', '2013-07-18 14:30:55', '2013-07-18 14:30:55', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1715', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1759, 1, '2013-07-19 18:42:46', '2013-07-19 18:42:46', 'Without Jobify i\'d be homeless, they found me a job and got me sorted out quickly with everything! Can\'t quite believe the service level that they offer!', 'Jake Gyllenhaal', '', 'publish', 'closed', 'closed', '', 'jake-gyllenhaal', '', '', '2013-07-19 18:42:46', '2013-07-19 18:42:46', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1759', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (1793, 1, '2013-07-22 16:38:02', '2013-07-22 16:38:02', 'I\'m incredibly pleased with Jobify\'s service. They offer quality candidates &amp; super quick support, they have turned me into a big fan.', 'Chris Christie', '', 'publish', 'closed', 'closed', '', 'chris-christie', '', '', '2013-07-22 16:38:02', '2013-07-22 16:38:02', '', 0, 'http://demo.astoundify.com/jobify/?post_type=testimonial&amp;p=1793', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2023, 1, '2013-12-09 15:32:39', '2013-12-09 15:32:39', '', 'Fundify', '', 'publish', 'closed', 'closed', '', 'fundify', '', '', '2013-12-09 15:32:39', '2013-12-09 15:32:39', '', 0, 'http://demo.astoundify.com/jobify-darker/?post_type=testimonial&amp;p=2023', 0, 'testimonial', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2184, 1, '2014-02-13 19:27:00', '2014-02-13 19:27:00', ' ', '', '', 'publish', 'open', 'open', '', '2184', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2184', 12, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2185, 1, '2014-02-13 19:27:00', '2014-02-13 19:27:00', ' ', '', '', 'publish', 'open', 'open', '', '2185', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2185', 11, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2186, 1, '2014-02-13 19:27:00', '2014-02-13 19:27:00', ' ', '', '', 'publish', 'open', 'open', '', '2186', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2186', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2187, 1, '2014-02-13 19:27:00', '2014-02-13 19:27:00', '', 'Jobs', '', 'publish', 'open', 'open', '', 'jobs', '', '', '2014-02-14 15:04:09', '2014-02-14 15:04:09', '', 0, 'http://capstone.jonny.me/?p=2187', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2189, 1, '2014-02-13 19:47:22', '2014-02-13 19:47:22', 'http://capstone.jonny.me/wp-content/uploads/2014/02/LogoWhiteCropped02.png', 'LogoWhiteCropped02.png', '', 'inherit', 'closed', 'open', '', 'logowhitecropped02-png', '', '', '2014-02-13 19:47:22', '2014-02-13 19:47:22', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/02/LogoWhiteCropped02.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2191, 1, '2014-02-14 14:43:06', '2014-02-14 14:43:06', 'http://capstone.jonny.me/wp-content/uploads/2014/02/cropped-LogoWhiteCroppedTest2.png', 'cropped-LogoWhiteCroppedTest2.png', '', 'inherit', 'closed', 'open', '', 'cropped-logowhitecroppedtest2-png', '', '', '2014-02-14 14:43:06', '2014-02-14 14:43:06', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/02/cropped-LogoWhiteCroppedTest2.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2192, 1, '2014-02-14 15:04:11', '2014-02-14 15:04:11', '', 'Logout', '', 'publish', 'open', 'open', '', 'logout', '', '', '2014-02-14 15:04:11', '2014-02-14 15:04:11', '', 0, 'http://capstone.jonny.me/?p=2192', 13, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2375, 1, '2014-03-28 02:51:05', '2014-03-28 02:51:05', '', 'geeksBlur', 'Innovative Mindsets', 'inherit', 'open', 'open', '', 'geeksblur', '', '', '2014-03-28 02:51:05', '2014-03-28 02:51:05', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/geeksBlur.png', 2, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2377, 1, '2014-04-03 17:33:38', '2014-04-03 17:33:38', '', 'DeathtoStock_Wired2', '', 'inherit', 'open', 'open', '', 'deathtostock_wired2', '', '', '2014-04-03 17:33:38', '2014-04-03 17:33:38', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/04/DeathtoStock_Wired2.jpg', 2, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (2378, 1, '2014-04-03 17:37:39', '2014-04-03 17:37:39', '', 'picjumbo.com_IMG_4893', '', 'inherit', 'open', 'open', '', 'picjumbo-com_img_4893', '', '', '2014-04-03 17:37:39', '2014-04-03 17:37:39', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/04/picjumbo.com_IMG_4893.jpg', 3, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (2379, 1, '2014-04-03 17:40:42', '2014-04-03 17:40:42', '', 'werocks', '', 'inherit', 'open', 'open', '', 'werocks', '', '', '2014-04-03 17:40:42', '2014-04-03 17:40:42', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/04/werocks.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2431, 1, '2014-07-02 12:02:56', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'draft', 'open', 'open', '', '', '', '', '2014-07-02 12:02:56', '2014-07-02 12:02:56', '', 0, 'http://capstone.jonny.me/?post_type=sidebar&#038;p=2431', 0, 'sidebar', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2195, 1, '2014-02-14 15:10:02', '2014-02-14 15:10:02', '[theme-my-login]', 'Log In', '', 'publish', 'closed', 'closed', '', 'login-2', '', '', '2014-02-14 15:10:02', '2014-02-14 15:10:02', '', 0, 'http://capstone.jonny.me/?page_id=2195', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2196, 1, '2014-02-14 15:10:02', '2014-02-14 15:10:02', '[theme-my-login]', 'Log Out', '', 'publish', 'closed', 'closed', '', 'logout', '', '', '2014-02-14 15:10:02', '2014-02-14 15:10:02', '', 0, 'http://capstone.jonny.me/?page_id=2196', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2197, 1, '2014-02-14 15:10:02', '2014-02-14 15:10:02', '[theme-my-login]', 'Register', '', 'publish', 'closed', 'closed', '', 'register', '', '', '2014-02-14 15:10:02', '2014-02-14 15:10:02', '', 0, 'http://capstone.jonny.me/?page_id=2197', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2198, 1, '2014-02-14 15:10:02', '2014-02-14 15:10:02', '[theme-my-login]', 'Lost Password', '', 'publish', 'closed', 'closed', '', 'lostpassword', '', '', '2014-02-14 15:10:02', '2014-02-14 15:10:02', '', 0, 'http://capstone.jonny.me/?page_id=2198', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2199, 1, '2014-02-14 15:10:02', '2014-02-14 15:10:02', '', 'Reset Password', '', 'publish', 'closed', 'closed', '', 'resetpass', '', '', '2014-04-04 14:31:26', '2014-04-04 14:31:26', '', 0, 'http://capstone.jonny.me/?page_id=2199', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2347, 1, '2014-03-20 15:43:42', '2014-03-20 15:43:42', '', 'Employers', '', 'publish', 'open', 'open', '', 'employers', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2347', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2346, 1, '2014-03-20 14:56:07', '2014-03-20 14:56:07', ' ', '', '', 'publish', 'open', 'open', '', '2346', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2346', 10, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2224, 25, '2014-02-21 15:44:57', '2014-02-21 15:44:57', '<p>Dummy data.  MUFAFA!</p>', 'Web Developer / Web Designer', '', 'expired', 'closed', 'open', '', 'web-developer-web-designer', '', '', '2014-08-11 15:32:50', '2014-08-11 15:32:50', '', 0, 'http://capstone.jonny.me/job/titzn-glitz-dummy-location-web-programming-web-developer-web-designer/', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2225, 1, '2014-02-21 16:16:16', '2014-02-21 16:16:16', 'THIS POST IS A TEST.', 'test', '', 'publish', 'open', 'open', '', 'test', '', '', '2014-02-21 16:16:19', '2014-02-21 16:16:19', '', 0, 'http://capstone.jonny.me/?p=2225', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2226, 1, '2014-02-21 16:16:16', '2014-02-21 16:16:16', 'THIS POST IS A TEST.', 'test', '', 'inherit', 'open', 'open', '', '2225-revision-v1', '', '', '2014-02-21 16:16:16', '2014-02-21 16:16:16', '', 2225, 'http://capstone.jonny.me/2225-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2301, 1, '2014-03-07 14:53:12', '2014-03-07 14:53:12', 'This is a test image', 'Mission Statement', 'NSCC\'s Mission Statement', 'inherit', 'open', 'open', '', 'slide1', '', '', '2014-03-07 14:53:12', '2014-03-07 14:53:12', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/Slide1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2230, 1, '2014-02-27 19:04:23', '2014-02-27 19:04:23', '', 'Main', '', 'publish', 'open', 'open', '', 'new-slider', '', '', '2014-04-11 14:32:45', '2014-04-11 14:32:45', '', 0, 'http://capstone.jonny.me/?post_type=ml-slider&#038;p=2230', 0, 'ml-slider', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2333, 1, '2014-03-19 19:31:10', '2014-03-19 19:31:10', '', '', '', 'inherit', 'open', 'open', '', 'connect', '', '', '2014-03-19 19:31:10', '2014-03-19 19:31:10', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/connect.jpg', 1, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (2337, 1, '2014-03-19 20:08:01', '2014-03-19 20:08:01', '', 'aircraft', '', 'inherit', 'open', 'open', '', 'aircraft', '', '', '2014-03-19 20:08:01', '2014-03-19 20:08:01', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/aircraft.jpg', 2, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (2338, 1, '2014-03-20 02:39:14', '2014-03-20 02:39:14', '[job_manager_companies]', 'test', '', 'publish', 'open', 'open', '', 'test', '', '', '2014-03-20 02:39:14', '2014-03-20 02:39:14', '', 0, 'http://capstone.jonny.me/?page_id=2338', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2339, 1, '2014-03-20 02:39:14', '2014-03-20 02:39:14', '[job_manager_companies]', 'test', '', 'inherit', 'open', 'open', '', '2338-revision-v1', '', '', '2014-03-20 02:39:14', '2014-03-20 02:39:14', '', 2338, 'http://capstone.jonny.me/2338-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2235, 1, '2014-02-27 19:22:16', '2014-02-27 19:22:16', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>


<div class="job_seeker_information">
<h2>Profile Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']
</div>


<h2><hr></h2>

<div class="upload_resume">
<h2 style="text-align: justify;">Attach a Resume Files</h2>
This can include ie. Resumes, Cover Letters, Reference Letters, etc.
[nm-wp-repo]
<div>
', 'Edit Profile', '', 'publish', 'closed', 'closed', '', 'profile', '', '', '2014-03-20 16:01:20', '2014-03-20 16:01:20', '', 0, 'http://capstone.jonny.me/your-profile/', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2236, 1, '2014-02-27 19:37:21', '2014-02-27 19:37:21', '', 'New Slider', '', 'trash', 'open', 'open', '', 'new-slider-2', '', '', '2014-02-27 19:38:53', '2014-02-27 19:38:53', '', 0, 'http://capstone.jonny.me/?post_type=ml-slider&#038;p=2236', 0, 'ml-slider', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2362, 1, '2014-03-20 16:07:48', '2014-03-20 16:07:48', '<h1>Need help posting a job?</h1>
1. Click on Employer and then post a job.
2. If you have an account, sign in. If not start filling out the form. A password will be emailed to you upon submission of the form.
3. Enter the job title
4. It is recommended that you add the job location unless the job can be performed from any location
5. Select the job type from the dropdown menu
6. Enter a Job description. Take mind to put as much detail as possible to make sure you are matched up to the right candidate.
7. Next you can either enter an email to where you would like to have the applications sent or provide a website URL that will take candidates to an online application site.
8. Optionally, add your social media details and upload your company logo.
9. Now you will enter in your company details including your company name, description and tagline (if your company has one).
10. Preview then submit your job listing.

<hr />

<h1>Want to Find a Job?</h1>
1. Click on Find a Job
2. You can search by job, location, or by clicking on a job type or multiple job types.
3. Click on a job that you are interested in and after reviewing the post, either choose to apply.

<hr />

<h1>Posting a Resume?</h1>
1. It is recommended that you log in or sign up before posting your resume.
2. You can click the “Post a Resume” button on the home page. The post a resume will link to a file input that allows the user to post a .doc or .pdf of their resume.
3. You will be prompted to log in if already registered or sign up if you have not registered.
4. See below screenshots!
5. Once you have a basic profile, go to My Profile and update your job seekers info.
6. Enter your First, Last Name and Program Stream.
7. If you have a website make sure to add the URL to your site.
8. You can also change your password here as well.
9. You can add your Portfolio URL, select as many types of work you are looking for. (The more specific your profile is, the more connections with employers you will make)
10. Fill in the other details requested.', 'FAQs', '', 'publish', 'closed', 'closed', '', 'faqs', '', '', '2014-03-20 16:07:48', '2014-03-20 16:07:48', '', 0, 'http://capstone.jonny.me/?page_id=2362', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2349, 1, '2014-03-20 15:48:43', '2014-03-20 15:48:43', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p>
</div>
<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;
</div>', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:48:43', '2014-03-20 15:48:43', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2240, 1, '2014-02-27 19:57:55', '2014-02-27 19:57:55', '', 'Manage Posts', '', 'publish', 'open', 'open', '', '2240', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2240', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2241, 1, '2014-02-27 19:57:54', '2014-02-27 19:57:54', ' ', '', '', 'publish', 'open', 'open', '', '2241', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2241', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2242, 1, '2014-02-27 19:57:58', '2014-02-27 19:57:58', ' ', '', '', 'publish', 'open', 'open', '', '2242', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2242', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2243, 1, '2014-02-27 19:57:50', '2014-02-27 19:57:50', '', 'Contact Us', '', 'publish', 'open', 'open', '', '2243', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2243', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2244, 1, '2014-02-27 19:57:51', '2014-02-27 19:57:51', '', 'Your Privacy', '', 'publish', 'open', 'open', '', '2244', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2244', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2245, 1, '2014-02-27 19:57:52', '2014-02-27 19:57:52', '', 'Our Terms', '', 'publish', 'open', 'open', '', '2245', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2245', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2248, 1, '2014-02-27 20:02:12', '2014-02-27 20:02:12', ' ', '', '', 'publish', 'open', 'open', '', '2248', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2248', 14, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2249, 1, '2014-02-27 20:07:27', '2014-02-27 20:07:27', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.</span></p>

<div><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></div>
<img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" />
&nbsp;
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'publish', 'closed', 'open', '', 'about', '', '', '2014-04-11 14:58:00', '2014-04-11 14:58:00', '', 0, 'http://capstone.jonny.me/?page_id=2249', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2254, 1, '2014-02-27 20:52:24', '2014-02-27 20:52:24', ' ', '', 'sign-up', 'publish', 'open', 'open', '', '2254', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2254', 12, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2376, 1, '2014-04-03 16:44:15', '2014-04-03 16:44:15', 'http://capstone.jonny.me/wp-content/uploads/2014/04/cropped-logo.png', 'cropped-logo.png', '', 'inherit', 'closed', 'open', '', 'cropped-logo-png', '', '', '2014-04-03 16:44:15', '2014-04-03 16:44:15', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/04/cropped-logo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2250, 1, '2014-02-27 20:07:27', '2014-02-27 20:07:27', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sed enim mi. Aliquam non arcu tempus erat lobortis pharetra. Donec molestie felis erat, ac accumsan ipsum rutrum nec. Vivamus id dolor a odio pretium porttitor. Phasellus rutrum quam nisl, ut faucibus tellus varius et. Praesent lacinia dignissim risus et hendrerit. Curabitur ut varius eros. Donec scelerisque sapien id tempor ultricies. Vestibulum eget ullamcorper leo. Praesent dolor purus, tincidunt et urna sit amet, rhoncus lacinia libero. Morbi ac malesuada nibh, posuere tempor enim. Pellentesque tristique felis eget elit rutrum, in ornare leo aliquet. Phasellus semper odio lorem, sed consequat nisl molestie et. Etiam eu tempor enim. Donec vel porta metus.

Morbi pulvinar vitae erat quis dictum. Ut dapibus lacinia nisl et ullamcorper. Nam sit amet magna vestibulum, ornare lacus venenatis, sollicitudin augue. Phasellus sed pulvinar metus. Maecenas nec ante ipsum. Nullam facilisis euismod tortor sit amet venenatis. Donec scelerisque enim sed nisi consequat feugiat sed non ligula. Nulla auctor gravida mauris, sed porta turpis rutrum sed. Maecenas laoreet, dolor mollis venenatis scelerisque, sem magna auctor arcu, at luctus odio magna non libero. Phasellus vel urna sodales, eleifend justo ac, porta purus. Aliquam quis condimentum tellus, vel aliquam tortor. Etiam accumsan fringilla nisi sed interdum. Nunc imperdiet erat et lacinia volutpat. Duis eu imperdiet ligula. Donec faucibus lectus ut nunc condimentum, nec eleifend ligula mollis.

Nulla condimentum lacus ut lacus rhoncus convallis. Quisque suscipit urna neque, ut scelerisque ipsum elementum id. Curabitur id metus quis dolor pulvinar vestibulum. Sed quis fringilla magna, non scelerisque diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin ut erat sodales, eleifend ipsum at, fermentum sem. Maecenas lacus purus, congue in auctor sed, blandit ac sapien. Maecenas mattis nec leo sit amet ultricies. Sed lorem nibh, pharetra sed turpis sed, mollis feugiat tortor.

Sed quis ultrices ante. Fusce lacus dui, ornare ac velit sit amet, sodales lobortis dolor. Pellentesque at orci ut tortor mollis vulputate quis ac turpis. Vestibulum risus nisi, varius vitae lacinia eget, vehicula non ante. Praesent lacinia hendrerit magna a fermentum. Vivamus malesuada, leo porta hendrerit congue, lacus orci faucibus arcu, a fringilla nulla risus et neque. Nam tempor ligula ut ipsum tincidunt, vitae rutrum augue pellentesque. Vestibulum ullamcorper enim eu sem malesuada, id cursus lorem rutrum. Proin cursus molestie sem, non molestie dolor vulputate a. Cras fringilla justo id felis vehicula tempor. Curabitur at neque odio. Etiam eleifend feugiat sem, non commodo urna molestie id. Vestibulum metus eros, sagittis eget metus at, molestie pretium augue. Proin ac turpis placerat, vulputate arcu vitae, elementum felis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Sed ullamcorper neque vel felis volutpat, at dignissim mauris iaculis.

Phasellus turpis orci, pretium sed pellentesque vitae, congue eu elit. Aenean vulputate vehicula adipiscing. Integer at dui aliquet, iaculis arcu id, tristique lectus. Vestibulum faucibus pellentesque enim eu consequat. Pellentesque molestie rutrum nunc, condimentum porta eros porta eget. Praesent et felis magna. Aliquam dictum, turpis at imperdiet gravida, libero libero luctus nunc, vel tincidunt augue velit nec risus. Donec sed tincidunt nibh, nec malesuada nibh.', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-02-27 20:07:27', '2014-02-27 20:07:27', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2251, 1, '2014-02-27 20:07:57', '2014-02-27 20:07:57', ' ', '', '', 'publish', 'open', 'open', '', '2251', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2251', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2253, 1, '2014-02-27 20:17:48', '2014-02-27 20:17:48', '<span style="font-family: Calibri; font-size: medium;">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-02-27 20:17:48', '2014-02-27 20:17:48', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2262, 1, '2014-02-28 05:20:30', '2014-02-28 05:20:30', '<h1>Upload Resume</h1>
[nm-wp-repo]', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-02-28 05:20:30', '2014-02-28 05:20:30', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2263, 1, '2014-02-28 16:13:18', '2014-02-28 16:13:18', 'Name *  [text* your-name class:footercontact] 

Email *  [email* your-email class:footercontact]

[textarea your-message class:footercontact]

[submit "Send"]
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)
maceachern.jonny@gmail.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Footer', '', 'publish', 'open', 'open', '', 'footer', '', '', '2014-02-28 16:17:56', '2014-02-28 16:17:56', '', 0, 'http://capstone.jonny.me/?post_type=wpcf7_contact_form&#038;p=2263', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2264, 1, '2014-05-26 16:50:55', '2014-05-26 16:50:55', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div class="current_information" style="display: none;">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding: 10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p>

</div>
<div class="job_seeker_information">
<h2>Profile Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

</div>

<hr />

<div class="upload_resume">
<h2 style="text-align: justify;">Attach a Resume Files</h2>
This can include ie. Resumes, Cover Letters, Reference Letters, etc.
[nm-wp-repo]
<div></div>
</div>', 'Edit Profile', '', 'inherit', 'open', 'open', '', '2235-autosave-v1', '', '', '2014-05-26 16:50:55', '2014-05-26 16:50:55', '', 2235, 'http://capstone.jonny.me/2235-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2265, 1, '2014-02-28 21:46:24', '2014-02-28 21:46:24', '<h2>Job-Seeker Information</h2>
Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;
<h2>Upload Resume</h2>
[nm-wp-repo]', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-02-28 21:46:24', '2014-02-28 21:46:24', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2267, 1, '2014-03-02 20:59:05', '2014-03-02 20:59:05', '<h2> Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 20:59:05', '2014-03-02 20:59:05', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2269, 1, '2014-03-02 21:28:08', '2014-03-02 21:28:08', '<h2 style="text-align: justify;"> Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'edit_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 21:28:08', '2014-03-02 21:28:08', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2270, 1, '2014-03-02 21:29:15', '2014-03-02 21:29:15', '<h2 style="text-align: justify;"> Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'profiler\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 21:29:15', '2014-03-02 21:29:15', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2271, 1, '2014-03-02 23:36:00', '2014-03-02 23:36:00', '<h2 style="text-align: justify;"> Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 23:36:00', '2014-03-02 23:36:00', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2272, 1, '2014-03-02 23:38:38', '2014-03-02 23:38:38', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="last_name"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 23:38:38', '2014-03-02 23:38:38', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2341, 1, '2014-03-20 14:42:23', '2014-03-20 14:42:23', '<div class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="display:none;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio:[userinfo field="description"]{{empty}}[/userinfo]</p>
</div>
<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;
</div>', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 14:42:23', '2014-03-20 14:42:23', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2273, 1, '2014-03-02 23:39:55', '2014-03-02 23:39:55', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 23:39:55', '2014-03-02 23:39:55', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2274, 1, '2014-03-02 23:41:07', '2014-03-02 23:41:07', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 23:41:07', '2014-03-02 23:41:07', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2275, 1, '2014-03-02 23:51:26', '2014-03-02 23:51:26', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="first_name"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-02 23:51:26', '2014-03-02 23:51:26', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2276, 1, '2014-03-03 00:10:28', '2014-03-03 00:10:28', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-03 00:10:28', '2014-03-03 00:10:28', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2277, 1, '2014-03-03 00:11:28', '2014-03-03 00:11:28', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-03 00:11:28', '2014-03-03 00:11:28', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2278, 1, '2014-03-03 00:16:34', '2014-03-03 00:16:34', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-03 00:16:34', '2014-03-03 00:16:34', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2279, 1, '2014-03-03 00:20:15', '2014-03-03 00:20:15', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio:[userinfo field="biographical_info"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-03 00:20:15', '2014-03-03 00:20:15', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2280, 1, '2014-03-03 00:21:22', '2014-03-03 00:21:22', '<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio:[userinfo field="description"]{{empty}}[/userinfo]</p>

<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-03 00:21:22', '2014-03-03 00:21:22', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2295, 1, '2014-03-05 16:09:26', '2014-03-05 16:09:26', '', 'logo2', '', 'inherit', 'open', 'open', '', 'logo2', '', '', '2014-03-05 16:09:26', '2014-03-05 16:09:26', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo2.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2296, 1, '2014-03-05 16:09:48', '2014-03-05 16:09:48', 'http://capstone.jonny.me/wp-content/uploads/2014/03/copy-logo2.png', 'copy-logo2.png', '', 'inherit', 'open', 'open', '', 'copy-logo2-png', '', '', '2014-03-05 16:09:48', '2014-03-05 16:09:48', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/copy-logo2.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2290, 1, '2014-03-04 23:20:10', '2014-03-04 23:20:10', '', 'NSCC Mission Statement', 'NSCC\'s Mission Statement', 'inherit', 'open', 'open', '', 'nscc_mission', '', '', '2014-03-04 23:20:10', '2014-03-04 23:20:10', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/nscc_mission.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (2297, 1, '2014-03-06 18:29:12', '2014-03-06 18:29:12', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div class="upload_job_info">
<p style="text-align: justify;">Hi..</p>

<div>
<div class="company_information">
<h2>Company Information</h2>
[user-meta type=\'profile\' form=\'company_profile\']
<h2>Upload Job Information</h2>
[nm-wp-repo]

&nbsp;
<div></div>
&nbsp;

</div>
</div>
</div>', 'Company Profile', '', 'publish', 'closed', 'closed', '', 'your-company-profile', '', '', '2014-04-17 19:36:26', '2014-04-17 19:36:26', '', 0, 'http://capstone.jonny.me/?page_id=2297', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2298, 1, '2014-03-06 18:29:12', '2014-03-06 18:29:12', '', 'Your Company Profile', '', 'inherit', 'open', 'open', '', '2297-revision-v1', '', '', '2014-03-06 18:29:12', '2014-03-06 18:29:12', '', 2297, 'http://capstone.jonny.me/2297-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2344, 1, '2014-03-20 14:48:05', '2014-03-20 14:48:05', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div class="upload_job_info">
<h2 style="text-align: justify;">Upload Job Information</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="company_information">
<h2>Company Information</h2>
[user-meta type=\'profile\' form=\'company_profile\']

&nbsp;
</div>', 'Your Company Profile', '', 'inherit', 'open', 'open', '', '2297-revision-v1', '', '', '2014-03-20 14:48:05', '2014-03-20 14:48:05', '', 2297, 'http://capstone.jonny.me/2297-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2299, 1, '2014-03-06 18:37:12', '2014-03-06 18:37:12', '<h2>Current Information</h2>
[userinfo field="user_login" if="admin"]You are the admin[/userinfo]

Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]

Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]

First Name: [userinfo field="first_name"]{{empty}}[/userinfo]

Email: [userinfo field="user_email"]{{empty}}[/userinfo]

Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]

Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]

User Bio:[userinfo field="description"]{{empty}}[/userinfo]
<h2>Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']', 'Your Company Profile', '', 'inherit', 'open', 'open', '', '2297-revision-v1', '', '', '2014-03-06 18:37:12', '2014-03-06 18:37:12', '', 2297, 'http://capstone.jonny.me/2297-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2300, 1, '2014-03-06 18:44:55', '2014-03-06 18:44:55', '', 'Log In', '', 'publish', 'open', 'open', '', '2300', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2300', 13, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2302, 1, '2014-03-07 15:21:26', '2014-03-07 15:21:26', '<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:21:26', '2014-03-07 15:21:26', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2303, 1, '2014-03-07 15:27:57', '2014-03-07 15:27:57', 'bLAH


<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:27:57', '2014-03-07 15:27:57', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2304, 1, '2014-03-07 15:29:55', '2014-03-07 15:29:55', 'The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:29:55', '2014-03-07 15:29:55', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2305, 1, '2014-03-07 15:31:01', '2014-03-07 15:31:01', 'The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:31:01', '2014-03-07 15:31:01', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2382, 1, '2014-04-03 18:15:33', '2014-04-03 18:15:33', '', 'mobileMarketingYellow', '', 'inherit', 'open', 'open', '', 'mobilemarketingyellow', '', '', '2014-04-03 18:15:33', '2014-04-03 18:15:33', '', 2249, 'http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (2307, 1, '2014-03-07 15:32:39', '2014-03-07 15:32:39', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 239px; height: 225px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="300" height="300" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:32:39', '2014-03-07 15:32:39', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2308, 1, '2014-03-07 15:33:08', '2014-03-07 15:33:08', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:33:08', '2014-03-07 15:33:08', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2381, 1, '2014-04-03 18:12:39', '2014-04-03 18:12:39', '<p style="text-align: justify;">The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span></p>
<p style="text-align: justify;"></p>
&nbsp;

&nbsp;
<h1 style="text-align: center;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 18:12:39', '2014-04-03 18:12:39', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2309, 1, '2014-03-07 15:36:30', '2014-03-07 15:36:30', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching!

<a href="http://d">Sign Up »</a>

&nbsp;

&nbsp;', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:36:30', '2014-03-07 15:36:30', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2310, 1, '2014-03-07 15:36:52', '2014-03-07 15:36:52', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching! <a href="http://d">Sign Up »</a>

&nbsp;

&nbsp;', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:36:52', '2014-03-07 15:36:52', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2383, 1, '2014-04-03 18:16:07', '2014-04-03 18:16:07', '', 'bizSolutionsYellow', '', 'inherit', 'open', 'open', '', 'bizsolutionsyellow', '', '', '2014-04-03 18:16:07', '2014-04-03 18:16:07', '', 2249, 'http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (2312, 1, '2014-03-07 15:40:04', '2014-03-07 15:40:04', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching! <a href="http://d">Sign Up »</a>

<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon.gif"><img class="size-full wp-image-2311 aligncenter" alt="employment_icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon-e1394206724708.gif" width="270" height="215" /></a>

&nbsp;', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:40:04', '2014-03-07 15:40:04', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2313, 1, '2014-03-07 15:40:36', '2014-03-07 15:40:36', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching!

<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon.gif"><img class="size-full wp-image-2311 aligncenter" alt="employment_icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon-e1394206724708.gif" width="270" height="215" /></a>
<h1 style="text-align: center;"> <a href="http://d">Sign Up »</a></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:40:36', '2014-03-07 15:40:36', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2380, 1, '2014-04-03 18:11:15', '2014-04-03 18:11:15', 'The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching!

&nbsp;
<h1 style="text-align: center;"><span style="color: #1a1a4f;"> <a href="http://d"><span style="color: #1a1a4f;">Sign Up »</span></a></span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 18:11:15', '2014-04-03 18:11:15', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2314, 1, '2014-03-07 15:41:23', '2014-03-07 15:41:23', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching!

<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon.gif"><img class="size-full wp-image-2311 aligncenter" alt="employment_icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon-e1394206724708.gif" width="270" height="215" /></a>
<h1 style="text-align: center;"><span style="color: #1a1a4f;"> <a href="http://d"><span style="color: #1a1a4f;">Sign Up »</span></a></span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-07 15:41:23', '2014-03-07 15:41:23', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2315, 1, '2014-03-07 15:50:43', '2014-03-07 15:50:43', '', 'logo', '', 'inherit', 'open', 'open', '', 'logo', '', '', '2014-03-07 15:50:43', '2014-03-07 15:50:43', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2316, 1, '2014-03-07 15:52:25', '2014-03-07 15:52:25', 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo1.png', 'logo1.png', '', 'inherit', 'closed', 'open', '', 'logo1-png', '', '', '2014-03-07 15:52:25', '2014-03-07 15:52:25', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo1.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2317, 1, '2014-03-07 15:53:24', '2014-03-07 15:53:24', 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo3.png', 'logo3.png', '', 'inherit', 'closed', 'open', '', 'logo3-png', '', '', '2014-03-07 15:53:24', '2014-03-07 15:53:24', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo3.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2318, 1, '2014-03-07 16:16:25', '2014-03-07 16:16:25', '<div class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio:[userinfo field="description"]{{empty}}[/userinfo]</p>
</div>
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<h2></h2>
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;

Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-07 16:16:25', '2014-03-07 16:16:25', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2319, 1, '2014-05-13 14:24:37', '2014-05-13 14:24:37', '<h3>Contact Information:</h3>
Marc Scarfone

Faculty, Information Technology Program

IT Campus, Halifax, Nova Scotia, Canada
<h3>Phone:  Phone: (902) 491-5112</h3>
<h3>Send us an E-Mail!</h3>
[contact-form-7 id="2324" title="Main Contact"]', 'Contact', '', 'inherit', 'open', 'open', '', '1882-autosave-v1', '', '', '2014-05-13 14:24:37', '2014-05-13 14:24:37', '', 1882, 'http://capstone.jonny.me/1882-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2329, 1, '2014-03-17 13:32:36', '2014-03-17 13:32:36', '<div class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio:[userinfo field="description"]{{empty}}[/userinfo]</p>
</div>
<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;
</div>', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-17 13:32:36', '2014-03-17 13:32:36', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2322, 1, '2014-03-07 16:23:54', '2014-03-07 16:23:54', '<div class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio:[userinfo field="description"]{{empty}}[/userinfo]</p>
</div>
<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;
</div>
Portfolio URL

Ultimately Looking for Work in (Select one or many)
<ul>
	<li>Management</li>
	<li>Front-end</li>
	<li>Back-end</li>
	<li>QA</li>
	<li>Web</li>
	<li>Big Data</li>
	<li>Phone Apps</li>
	<li>Game Programming</li>
	<li>What I finds, I keeps!</li>
</ul>
Program Stream

Year of Graduation

Current Employer

What do You Believe is Your Most Useful Skill?

What is Something You Would Like to Improve About Yourself?

Describe an Event Where you Demonstrated Leadership

Describe an Event in Which you feel you Learned an Important Lesson
<h2>Personal Information</h2>
City

Province

Willing to Relocate?

Citizenship

Additional Languages

Age

&nbsp;
<h2>Additional Information</h2>
Write a Short Description About Yourself

Hobbies/Passions

Favorite Part About NSCC IT?

Favorite Programming Language

Least Favorite Programming Language

&nbsp;', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-07 16:23:54', '2014-03-07 16:23:54', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2323, 1, '2014-03-07 16:24:07', '2014-03-07 16:24:07', 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo4.png', 'logo4.png', '', 'inherit', 'closed', 'open', '', 'logo4-png', '', '', '2014-03-07 16:24:07', '2014-03-07 16:24:07', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/03/logo4.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2324, 1, '2014-03-07 16:24:11', '2014-03-07 16:24:11', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message (required)<br />
    [textarea* your-message] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)
maceachern.jonny@gmail.com




[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on  (http://capstone.jonny.me)
[your-email]



Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.
Your entered code is incorrect.
Number format seems invalid.
This number is too small.
This number is too large.
Email address seems invalid.
URL seems invalid.
Telephone number seems invalid.
Your answer is not correct.
Date format seems invalid.
This date is too early.
This date is too late.
Failed to upload file.
This file type is not allowed.
This file is too large.
Failed to upload file. Error occurred.', 'Main Contact', '', 'publish', 'open', 'open', '', 'main-contact', '', '', '2014-03-07 16:26:08', '2014-03-07 16:26:08', '', 0, 'http://capstone.jonny.me/?post_type=wpcf7_contact_form&#038;p=2324', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2424, 1, '2014-05-13 14:24:46', '2014-05-13 14:24:46', '<h3>Contact Information:</h3>
Marc Scarfone

Faculty, Information Technology Program

IT Campus, Halifax, Nova Scotia, Canada
<h3>Phone:   (902) 491-5112</h3>
<h3>Send us an E-Mail!  [contact-form-7 id="2324" title="Main Contact"]</h3>', 'Contact', '', 'inherit', 'open', 'open', '', '1882-revision-v1', '', '', '2014-05-13 14:24:46', '2014-05-13 14:24:46', '', 1882, 'http://capstone.jonny.me/1882-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2325, 1, '2014-03-07 16:24:21', '2014-03-07 16:24:21', '<h3>Contact Information:</h3>

Full Name: Scarfone, Marc
Business Title: NSCC Faculty
Department: InfoTechY2SysMgmt Network

<h3>Phone:</h3>
Need to speak with someone?

Phone: (902) 491-5112

<h3>Send us an E-Mail!</h3>

[contact-form-7 id="2324" title="Main Contact"]', 'Contact', '', 'inherit', 'open', 'open', '', '1882-revision-v1', '', '', '2014-03-07 16:24:21', '2014-03-07 16:24:21', '', 1882, 'http://capstone.jonny.me/1882-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2328, 22, '2014-03-16 16:40:33', '2014-03-16 16:40:33', '<p>Looking for a web programmer to program some awesome websites for small time clients.</p>', 'Web Developer', '', 'expired', 'closed', 'open', '', 'web-developer', '', '', '2014-08-11 15:32:50', '2014-08-11 15:32:50', '', 0, 'http://capstone.jonny.me/job/webgirl-dartmouth-ns-web-programming-web-developer/', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2419, 1, '2014-04-17 18:49:58', '2014-04-17 18:49:58', 'This job entails....', 'Web Programming', '', 'inherit', 'open', 'open', '', '2418-autosave-v1', '', '', '2014-04-17 18:49:58', '2014-04-17 18:49:58', '', 2418, 'http://capstone.jonny.me/2418-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2342, 1, '2014-03-20 14:44:42', '2014-03-20 14:44:42', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream:[userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio:[userinfo field="description"]{{empty}}[/userinfo]</p>
</div>
<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;
</div>', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 14:44:42', '2014-03-20 14:44:42', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2343, 1, '2014-04-17 19:18:53', '2014-04-17 19:18:53', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div class="upload_job_info">
<h2 style="text-align: justify;">Upload Job Information</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="company_information">
<h2>Company Information</h2>
[user-meta type=\'profile\' form=\'company_profile\']

&nbsp;

</div>
</div>
</div>', 'Company Profile', '', 'inherit', 'open', 'open', '', '2297-autosave-v1', '', '', '2014-04-17 19:18:53', '2014-04-17 19:18:53', '', 2297, 'http://capstone.jonny.me/2297-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2350, 1, '2014-03-20 15:53:34', '2014-03-20 15:53:34', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p>
<br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p>
</div>
<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;
</div>', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:53:34', '2014-03-20 15:53:34', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2351, 1, '2014-03-20 15:53:55', '2014-03-20 15:53:55', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>
<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']

&nbsp;
</div>', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:53:55', '2014-03-20 15:53:55', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2352, 1, '2014-03-20 15:57:02', '2014-03-20 15:57:02', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>

<div class="job_seeker_information">
<h2>Job-Seeker Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']
</div>

<h2><hr></h2>

<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>

', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:57:02', '2014-03-20 15:57:02', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2353, 1, '2014-03-20 15:58:03', '2014-03-20 15:58:03', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>

<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>

<h2><hr></h2>

<div class="job_seeker_information">
<h2>Profile Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']
</div>


', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:58:03', '2014-03-20 15:58:03', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2384, 1, '2014-04-03 18:16:24', '2014-04-03 18:16:24', '', 'netYellow', '', 'inherit', 'open', 'open', '', 'netyellow', '', '', '2014-04-03 18:16:24', '2014-04-03 18:16:24', '', 2249, 'http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (2355, 1, '2014-03-20 15:58:23', '2014-03-20 15:58:23', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>


<div class="job_seeker_information">
<h2>Profile Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']
</div>


<h2><hr></h2>

<div class="upload_resume">
<h2 style="text-align: justify;">Upload Resume</h2>
[nm-wp-repo]
<div>
', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:58:23', '2014-03-20 15:58:23', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2356, 1, '2014-03-20 15:59:00', '2014-03-20 15:59:00', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>


<div class="job_seeker_information">
<h2>Profile Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']
</div>


<h2><hr></h2>

<div class="upload_resume">
<h2 style="text-align: justify;">Attach a Resume</h2>
[nm-wp-repo]
<div>
', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:59:00', '2014-03-20 15:59:00', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2357, 1, '2014-03-20 15:59:03', '2014-03-20 15:59:03', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching!

<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon.png"><img class="size-full wp-image-2311 aligncenter" alt="employment_icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/employment_icon-e1394206724708.png" width="270" height="215" /></a>
<h1 style="text-align: center;"><span style="color: #1a1a4f;"> <a href="http://d"><span style="color: #1a1a4f;">Sign Up »</span></a></span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-20 15:59:03', '2014-03-20 15:59:03', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2358, 1, '2014-03-20 15:59:50', '2014-03-20 15:59:50', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>


<div class="job_seeker_information">
<h2>Profile Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']
</div>


<h2><hr></h2>

<div class="upload_resume">
<h2 style="text-align: justify;">Attach a Resume Files</h2>
This can include ie. Resumes, Cover Letters, Reference Letters, etc.
[nm-wp-repo]
<div>
', 'Your Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 15:59:50', '2014-03-20 15:59:50', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2359, 1, '2014-03-20 16:01:20', '2014-03-20 16:01:20', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div style="display:none;" class="current_information">
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify; padding:10px;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>
<h2 style="text-align: justify;">Current Information</h2>
<p style="text-align: justify;">Display Name: [userinfo field="display_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Last Name: [userinfo field="last_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">First Name: [userinfo field="first_name"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Email: [userinfo field="user_email"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Profile URL: [userinfo field="user_url"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">Program Stream: [userinfo field="program_stream"]{{empty}}[/userinfo]</p><br><br>
<p style="text-align: justify;">User Bio: [userinfo field="description"]{{empty}}[/userinfo]</p><br><br>
</div>


<div class="job_seeker_information">
<h2>Profile Information</h2>
[user-meta type=\'profile\' form=\'seeker_profile\']
</div>


<h2><hr></h2>

<div class="upload_resume">
<h2 style="text-align: justify;">Attach a Resume Files</h2>
This can include ie. Resumes, Cover Letters, Reference Letters, etc.
[nm-wp-repo]
<div>
', 'Edit Profile', '', 'inherit', 'open', 'open', '', '2235-revision-v1', '', '', '2014-03-20 16:01:20', '2014-03-20 16:01:20', '', 2235, 'http://capstone.jonny.me/2235-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2360, 1, '2014-03-20 16:02:48', '2014-03-20 16:02:48', '<a href="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg.png"><img class=" wp-image-2306 alignleft" style="width: 195px; height: 191px;" alt="Job Connect Icon" src="http://capstone.jonny.me/wp-content/uploads/2014/02/icon_job_lg-300x300.png" width="239" height="225" /></a>The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year graduate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.

<span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span>

Are you looking for a career in your field? Are you a current student of NSCC or Alumni Graduate of NSCC? If so, sign up now and start job searching!

<a href="http://capstone.jonny.me/wp-content/uploads/2014/03/employment-icon.png"><img class="size-full wp-image-2311 aligncenter" alt="employment_icon" src="http://capstone.jonny.me/wp-content/uploads/2014/03/employment-icon.png" width="270" height="215" /></a>
<h1 style="text-align: center;"><span style="color: #1a1a4f;"> <a href="http://d"><span style="color: #1a1a4f;">Sign Up »</span></a></span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-03-20 16:02:48', '2014-03-20 16:02:48', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2361, 1, '2014-03-20 16:03:48', '2014-03-20 16:03:48', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div class="upload_job_info">
<h2 style="text-align: justify;">Upload Job Information</h2>
[nm-wp-repo]
<div>
<h2></h2>
<div class="company_information">
<h2>Company Information</h2>
[user-meta type=\'profile\' form=\'company_profile\']

&nbsp;
</div>', 'Company Profile', '', 'inherit', 'open', 'open', '', '2297-revision-v1', '', '', '2014-03-20 16:03:48', '2014-03-20 16:03:48', '', 2297, 'http://capstone.jonny.me/2297-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2363, 1, '2014-03-20 16:07:48', '2014-03-20 16:07:48', '<h1>Need help posting a job?</h1>
1. Click on Employer and then post a job.
2. If you have an account, sign in. If not start filling out the form. A password will be emailed to you upon submission of the form.
3. Enter the job title
4. It is recommended that you add the job location unless the job can be performed from any location
5. Select the job type from the dropdown menu
6. Enter a Job description. Take mind to put as much detail as possible to make sure you are matched up to the right candidate.
7. Next you can either enter an email to where you would like to have the applications sent or provide a website URL that will take candidates to an online application site.
8. Optionally, add your social media details and upload your company logo.
9. Now you will enter in your company details including your company name, description and tagline (if your company has one).
10. Preview then submit your job listing.

<hr />

<h1>Want to Find a Job?</h1>
1. Click on Find a Job
2. You can search by job, location, or by clicking on a job type or multiple job types.
3. Click on a job that you are interested in and after reviewing the post, either choose to apply.

<hr />

<h1>Posting a Resume?</h1>
1. It is recommended that you log in or sign up before posting your resume.
2. You can click the “Post a Resume” button on the home page. The post a resume will link to a file input that allows the user to post a .doc or .pdf of their resume.
3. You will be prompted to log in if already registered or sign up if you have not registered.
4. See below screenshots!
5. Once you have a basic profile, go to My Profile and update your job seekers info.
6. Enter your First, Last Name and Program Stream.
7. If you have a website make sure to add the URL to your site.
8. You can also change your password here as well.
9. You can add your Portfolio URL, select as many types of work you are looking for. (The more specific your profile is, the more connections with employers you will make)
10. Fill in the other details requested.', 'FAQs', '', 'inherit', 'open', 'open', '', '2362-revision-v1', '', '', '2014-03-20 16:07:48', '2014-03-20 16:07:48', '', 2362, 'http://capstone.jonny.me/2362-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2364, 1, '2014-03-20 16:08:16', '2014-03-20 16:08:16', ' ', '', '', 'publish', 'open', 'open', '', '2364', '', '', '2014-03-20 16:29:01', '2014-03-20 16:29:01', '', 0, 'http://capstone.jonny.me/?p=2364', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2365, 1, '2014-03-20 16:09:37', '2014-03-20 16:09:37', '<div>
<h1>Terms of Use for Members (Pop-Up Box on First Launch)</h1>
</div>
<div>
<h2>General Terms</h2>
</div>
Members invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Member Priviliges</h2>
</div>
By accepting this agreement the member gains the following privileges:
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment</li>
</ul>
<div>
<h2>Member Restricted Priviliges</h2>
</div>
It is important to remember that members may only deactivate their accounts through Student Services.
<div>
<h2>Member Liabilities</h2>
</div>
All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>
<div>
<h1>Term of Use for Employers (Pop-Up Box on First Launch)</h1>
</div>
<div>
<h2>General Terms</h2>
</div>
Employers invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Employer Priviliges</h2>
</div>
By accepting this agreement the employer gains the following privileges:
<ul>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
<h3></h3>
&nbsp;
<div>
<h2>Employer RESTRICTED PRIVILIGES</h2>
</div>
<b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>', 'Terms and Conditions', '', 'inherit', 'open', 'open', '', '1760-revision-v1', '', '', '2014-03-20 16:09:37', '2014-03-20 16:09:37', '', 1760, 'http://capstone.jonny.me/1760-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2366, 1, '2014-03-20 16:09:50', '2014-03-20 16:09:50', '<div>
<h1>Terms of Use for Members</h1>
</div>
<div>
<h2>General Terms</h2>
</div>
Members invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Member Priviliges</h2>
</div>
By accepting this agreement the member gains the following privileges:
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment</li>
</ul>
<div>
<h2>Member Restricted Priviliges</h2>
</div>
It is important to remember that members may only deactivate their accounts through Student Services.
<div>
<h2>Member Liabilities</h2>
</div>
All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>
<div>
<h1>Term of Use for Employers (Pop-Up Box on First Launch)</h1>
</div>
<div>
<h2>General Terms</h2>
</div>
Employers invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Employer Priviliges</h2>
</div>
By accepting this agreement the employer gains the following privileges:
<ul>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
<h3></h3>
&nbsp;
<div>
<h2>Employer RESTRICTED PRIVILIGES</h2>
</div>
<b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>', 'Terms and Conditions', '', 'inherit', 'open', 'open', '', '1760-revision-v1', '', '', '2014-03-20 16:09:50', '2014-03-20 16:09:50', '', 1760, 'http://capstone.jonny.me/1760-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2367, 1, '2014-03-20 16:10:13', '2014-03-20 16:10:13', '<div>
<h1>Terms of Use for Members</h1>
By using our website you automatically agree to the following terms.

</div>
<div>
<h2>General Terms</h2>
</div>
Members invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Member Priviliges</h2>
</div>
By accepting this agreement the member gains the following privileges:
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment</li>
</ul>
<div>
<h2>Member Restricted Priviliges</h2>
</div>
It is important to remember that members may only deactivate their accounts through Student Services.
<div>
<h2>Member Liabilities</h2>
</div>
All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>
<div>
<h1>Term of Use for Employers (Pop-Up Box on First Launch)</h1>
</div>
<div>
<h2>General Terms</h2>
</div>
Employers invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">Computer Resource Usage Policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.
<div>
<h2>Employer Priviliges</h2>
</div>
By accepting this agreement the employer gains the following privileges:
<ul>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
<h3></h3>
&nbsp;
<div>
<h2>Employer RESTRICTED PRIVILIGES</h2>
</div>
<b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>', 'Terms and Conditions', '', 'inherit', 'open', 'open', '', '1760-revision-v1', '', '', '2014-03-20 16:10:13', '2014-03-20 16:10:13', '', 1760, 'http://capstone.jonny.me/1760-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2423, 1, '2014-05-13 14:22:55', '2014-05-13 14:22:55', '<div>

<i>Last Updated:  3/20/2014</i>

&nbsp;

</div>
<div>
<h1>Security</h1>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .

&nbsp;
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<h1>Use of Information</h1>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-revision-v1', '', '', '2014-05-13 14:22:55', '2014-05-13 14:22:55', '', 1762, 'http://capstone.jonny.me/1762-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2371, 1, '2014-03-20 16:11:45', '2014-03-20 16:11:45', '<div>

<i>Last Updated:  3/20/2014</i>

</div>
<div>
<h2>Security</h2>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<div>
<h2>Terms of Use</h2>
</div>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="729">
<p align="center"><b>Privileges</b></p>
</td>
</tr>
<tr>
<td width="365">
<p align="center"><b>Members</b></p>
</td>
<td width="365">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="365">
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment<b></b></li>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
</td>
<td valign="top" width="365"></td>
</tr>
</tbody>
</table>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="734">
<p align="center"><b>Restricted Privileges &amp; Liabilities</b></p>
</td>
</tr>
<tr>
<td width="366">
<p align="center"><b>Members</b></p>
</td>
<td width="368">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="366"><b>It is important to remember that members may only deactivate their accounts through Student Services.</b> All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under Consequences of Policy Violation for further information.

&nbsp;</td>
<td valign="top" width="368"><b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b></td>
</tr>
</tbody>
</table>
<div>
<h2>Use of Information</h2>
</div>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-revision-v1', '', '', '2014-03-20 16:11:45', '2014-03-20 16:11:45', '', 1762, 'http://capstone.jonny.me/1762-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2369, 1, '2014-03-20 16:11:19', '2014-03-20 16:11:19', '<div>
<h1>Privacy POLICY</h1>
</div>
<i>Updated Last:  3/20/2014</i>
<div>
<h2>Security</h2>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<div>
<h2>Terms of Use</h2>
</div>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="729">
<p align="center"><b>Privileges</b></p>
</td>
</tr>
<tr>
<td width="365">
<p align="center"><b>Members</b></p>
</td>
<td width="365">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="365">
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment<b></b></li>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
</td>
<td valign="top" width="365"></td>
</tr>
</tbody>
</table>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="734">
<p align="center"><b>Restricted Privileges &amp; Liabilities</b></p>
</td>
</tr>
<tr>
<td width="366">
<p align="center"><b>Members</b></p>
</td>
<td width="368">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="366"><b>It is important to remember that members may only deactivate their accounts through Student Services.</b> All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under Consequences of Policy Violation for further information.

&nbsp;</td>
<td valign="top" width="368"><b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>

&nbsp;</td>
</tr>
</tbody>
</table>
<div>
<h2>Use of Information</h2>
</div>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-revision-v1', '', '', '2014-03-20 16:11:19', '2014-03-20 16:11:19', '', 1762, 'http://capstone.jonny.me/1762-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2368, 1, '2014-03-20 16:11:08', '2014-03-20 16:11:08', '<div>
<h1>Privacy POLICY (link @ Footer for Member’s Safety Reasons)</h1>
</div>
<i>Updated Last:  3/20/2014</i>
<div>
<h2>Security</h2>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<div>
<h2>Terms of Use</h2>
</div>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="729">
<p align="center"><b>Privileges</b></p>
</td>
</tr>
<tr>
<td width="365">
<p align="center"><b>Members</b></p>
</td>
<td width="365">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="365">
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment<b></b></li>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
</td>
<td valign="top" width="365"></td>
</tr>
</tbody>
</table>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="734">
<p align="center"><b>Restricted Privileges &amp; Liabilities</b></p>
</td>
</tr>
<tr>
<td width="366">
<p align="center"><b>Members</b></p>
</td>
<td width="368">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="366"><b>It is important to remember that members may only deactivate their accounts through Student Services.</b> All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under Consequences of Policy Violation for further information.

&nbsp;</td>
<td valign="top" width="368"><b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>

&nbsp;</td>
</tr>
</tbody>
</table>
<div>
<h2>Use of Information</h2>
</div>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-revision-v1', '', '', '2014-03-20 16:11:08', '2014-03-20 16:11:08', '', 1762, 'http://capstone.jonny.me/1762-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2370, 1, '2014-03-20 16:11:27', '2014-03-20 16:11:27', '<div>
<h1>Privacy Policy</h1>
</div>
<i>Updated Last:  3/20/2014</i>
<div>
<h2>Security</h2>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<div>
<h2>Terms of Use</h2>
</div>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="729">
<p align="center"><b>Privileges</b></p>
</td>
</tr>
<tr>
<td width="365">
<p align="center"><b>Members</b></p>
</td>
<td width="365">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="365">
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment<b></b></li>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
</td>
<td valign="top" width="365"></td>
</tr>
</tbody>
</table>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="734">
<p align="center"><b>Restricted Privileges &amp; Liabilities</b></p>
</td>
</tr>
<tr>
<td width="366">
<p align="center"><b>Members</b></p>
</td>
<td width="368">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="366"><b>It is important to remember that members may only deactivate their accounts through Student Services.</b> All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under Consequences of Policy Violation for further information.

&nbsp;</td>
<td valign="top" width="368"><b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b>&nbsp;</td>
</tr>
</tbody>
</table>
<div>
<h2>Use of Information</h2>
</div>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-revision-v1', '', '', '2014-03-20 16:11:27', '2014-03-20 16:11:27', '', 1762, 'http://capstone.jonny.me/1762-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2385, 1, '2014-04-03 18:16:52', '2014-04-03 18:16:52', '<script>



</script>', 'Find A Job', '', 'inherit', 'open', 'open', '', '2069-autosave-v1', '', '', '2014-04-03 18:16:52', '2014-04-03 18:16:52', '', 2069, 'http://capstone.jonny.me/2069-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2386, 1, '2014-04-03 18:17:21', '2014-04-03 18:17:21', '', 'profile2Yellow', '', 'inherit', 'open', 'open', '', 'profile2yellow', '', '', '2014-04-03 18:17:21', '2014-04-03 18:17:21', '', 2249, 'http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (2387, 1, '2014-04-03 18:17:29', '2014-04-03 18:17:29', '', 'securityYellow', '', 'inherit', 'open', 'open', '', 'securityyellow', '', '', '2014-04-03 18:17:29', '2014-04-03 18:17:29', '', 2249, 'http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (2416, 1, '2014-04-11 14:58:00', '2014-04-11 14:58:00', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.</span></p>

<div><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></div>
<img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" />
&nbsp;
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-11 14:58:00', '2014-04-11 14:58:00', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2388, 1, '2014-04-03 18:21:42', '2014-04-03 18:21:42', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span></p>
&nbsp;

&nbsp;
<h1 style="text-align: center;"><span style="color: #1a1a4f;"><img class="alignnone size-medium wp-image-2383" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2382" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /><a style="font-size: 14px; line-height: 1.5em; text-align: justify;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a></span><span style="color: #1a1a4f;"> </span><a style="line-height: 1.5em; font-size: 14px; text-align: justify;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="alignnone size-medium wp-image-2387" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a><img class="alignnone size-medium wp-image-2384" style="line-height: 1.5em; font-size: 14px;" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 18:21:42', '2014-04-03 18:21:42', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2390, 1, '2014-04-03 18:31:27', '2014-04-03 18:31:27', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span></p>
&nbsp;

&nbsp;
<h1 style="text-align: left;"><span style="color: #1a1a4f;"><img class="alignnone size-medium wp-image-2383" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2382" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /><a style="font-size: 14px; line-height: 1.5em; text-align: justify;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a></span><span style="color: #1a1a4f;"> </span><a style="line-height: 1.5em; font-size: 14px; text-align: justify;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="size-medium wp-image-2387" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a><img class="size-medium wp-image-2384" style="line-height: 1.5em; font-size: 14px;" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 18:31:27', '2014-04-03 18:31:27', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2389, 1, '2014-04-03 18:27:19', '2014-04-03 18:27:19', '', 'itjobs', '', 'inherit', 'open', 'open', '', 'itjobs', '', '', '2014-04-03 18:27:19', '2014-04-03 18:27:19', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/04/itjobs.png', 3, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2397, 1, '2014-04-03 19:04:22', '2014-04-03 19:04:22', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span></p>
&nbsp;

&nbsp;
<h1 style="text-align: left;"><span style="color: #1a1a4f;"><img class="alignnone size-medium wp-image-2383 promo1" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="alignnone size-medium wp-image-2387" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a></span><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif"><img class="alignnone size-medium wp-image-2384" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif"><img class="alignnone size-medium wp-image-2382" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></a></h1>
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 19:04:22', '2014-04-03 19:04:22', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2415, 1, '2014-04-11 14:56:42', '2014-04-11 14:56:42', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.</span></p>

<div><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></div>
<p style="text-align: justify;"><img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></p>
&nbsp;
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-11 14:56:42', '2014-04-11 14:56:42', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2392, 1, '2014-04-03 18:32:52', '2014-04-03 18:32:52', '', 'learninggrowing', '', 'inherit', 'open', 'open', '', 'learninggrowing', '', '', '2014-04-03 18:32:52', '2014-04-03 18:32:52', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/04/learninggrowing.png', 4, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2393, 1, '2014-04-03 18:34:51', '2014-04-03 18:34:51', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span></p>
&nbsp;

&nbsp;
<h1 style="text-align: left;"><span style="color: #1a1a4f;"><img class="alignnone size-medium wp-image-2383" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /></span></h1>
<h1 style="text-align: left;"><a href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="alignnone size-medium wp-image-2387" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a></h1>
<h1 style="text-align: left;"><a href="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif"><img class="alignnone size-medium wp-image-2384" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></a></h1>
<h1 style="text-align: left;"><a href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a></h1>
<h1 style="text-align: left;"><a href="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif"><img class="alignnone size-medium wp-image-2382" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></a></h1>
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 18:34:51', '2014-04-03 18:34:51', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2394, 1, '2014-04-03 18:44:23', '2014-04-03 18:44:23', '', 'globe', '', 'inherit', 'open', 'open', '', 'globe', '', '', '2014-04-03 18:44:23', '2014-04-03 18:44:23', '', 0, 'http://capstone.jonny.me/wp-content/uploads/2014/04/globe.png', 7, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (2395, 1, '2014-04-03 18:50:50', '2014-04-03 18:50:50', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span></p>
&nbsp;

&nbsp;
<h1 style="text-align: left;"><span style="color: #1a1a4f;"><img class="alignnone size-medium wp-image-2383" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="alignnone size-medium wp-image-2387" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a></span><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif"><img class="alignnone size-medium wp-image-2384" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif"><img class="alignnone size-medium wp-image-2382" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></a></h1>
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 18:50:50', '2014-04-03 18:50:50', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2407, 1, '2014-04-11 13:56:38', '2014-04-11 13:56:38', '', 'Home', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2014-04-11 13:56:38', '2014-04-11 13:56:38', '', 25, 'http://capstone.jonny.me/25-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2404, 1, '2014-04-11 12:06:58', '2014-04-11 12:06:58', '[maxbutton id="1"]', 'Home', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2014-04-11 12:06:58', '2014-04-11 12:06:58', '', 25, 'http://capstone.jonny.me/25-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2432, 1, '2014-07-02 12:02:56', '0000-00-00 00:00:00', '', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-07-02 12:02:56', '0000-00-00 00:00:00', '', 2431, 'http://capstone.jonny.me/?post_type=sidebar_group&p=2432', 0, 'sidebar_group', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2433, 1, '2014-07-02 12:09:34', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2014-07-02 12:09:34', '0000-00-00 00:00:00', '', 0, 'http://capstone.jonny.me/?p=2433', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2408, 43, '2014-04-11 14:40:20', '2014-04-11 14:40:20', '<p>We are currently seeking an experienced front-end web developer with extensive HTML, JavaScript, and CSS experience for a contract assignment.  This project will consist of re-writing web applications to securely interface with the already built REST API.</p>', 'WEB DEVELOPER (FRONT-END)', '', 'expired', 'closed', 'open', '', 'web-developer-front-end', '', '', '2014-08-11 15:32:50', '2014-08-11 15:32:50', '', 0, 'http://capstone.jonny.me/job/acme-design-co-halifax-ns-computer-electronics-technician-web-developer-front-end/', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2411, 1, '2014-04-11 14:53:27', '2014-04-11 14:53:27', '<div>

<i>Last Updated:  3/20/2014</i>

</div>
<div>
<h2>Security</h2>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<div>
<h2>Terms of Use</h2>
</div>
&nbsp;
<h1 style="text-align: left;" align="center"><b>Privileges</b></h1>
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment<b></b></li>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
<h1 style="text-align: left;" align="center"><b>Restricted Privileges &amp; Liabilities</b></h1>
<p style="text-align: left;" align="center"><b>Members</b></p>
<p style="text-align: left;" align="center"><b>It is important to remember that members may only deactivate their accounts through Student Services.</b> All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:</p>

<ul>
	<li>Appropriate and professional profile pictures</li>
	<li>Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the Computer Resource Usage Policy under Consequences of Policy Violation for further information.
<p style="text-align: left;" align="center"><b>Employers</b></p>
<p style="text-align: left;" align="center"><b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the Computer Resource Usage Policy under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b></p>

<h1 style="text-align: left;" align="center">Use of Information</h1>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-revision-v1', '', '', '2014-04-11 14:53:27', '2014-04-11 14:53:27', '', 1762, 'http://capstone.jonny.me/1762-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2409, 1, '2014-04-11 14:51:30', '2014-04-11 14:51:30', '<div>

<i>Last Updated:  3/20/2014</i>

</div>
<div>
<h2>Security</h2>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<div>
<h2>Terms of Use</h2>
</div>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="729">
<p align="center"><b>Privileges</b></p>
</td>
</tr>
<tr>
<td width="365">
<p align="center"><b>Members</b></p>
</td>
<td width="365">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td valign="top" width="365">
<ul>
	<li>Create and update their own member profile</li>
	<li>Access to the job board</li>
	<li>View potential and trusted employers</li>
	<li>Be matched with potential and trusted employers</li>
	<li>Ability to apply to and print job postings</li>
	<li>Have a secure and safe environment<b></b></li>
	<li>Have their own employer account</li>
	<li>Post and modify job opportunities</li>
	<li>View other employers’ accounts</li>
	<li>View member profiles and content provided on said profiles</li>
	<li>Be matched with potential members</li>
	<li>View/Print/Save member documentation, but not alter them</li>
	<li>Have a secure and safe environment</li>
</ul>
</td>
<td valign="top" width="365"></td>
</tr>
</tbody>
</table>
&nbsp;
<table border="1" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td colspan="2" width="734">
<p align="center"><b>Restricted Privileges &amp; Liabilities</b></p>
</td>
</tr>
<tr>
<td width="366">
<p align="center"><b>Members</b></p>
</td>
<td width="368">
<p align="center"><b>Employers</b></p>
</td>
</tr>
<tr>
<td style="padding-left: 30px;" valign="top" width="366"><b>It is important to remember that members may only deactivate their accounts through Student Services.</b> All members of the College are reminded to think carefully about how they portray themselves or others and/or represent the College in communication and social networking sites such as YouTube, Facebook, Twitter, or blogs to which employers and the general public have access. Social network privacy settings are available through the provider and recommended to be used to ensure a member’s privacy. The member’s profile will always be monitored through Nova Scotia Community College to ensure appropriate behavior and content:
<ul style="padding-left: 30px;">
	<li style="padding-left: 30px;">Appropriate and professional profile pictures</li>
	<li style="padding-left: 30px;">Language Use (no profanity, disrespect, discrimination, or harassment)</li>
</ul>
<p style="padding-left: 30px;">All members are also accountable to Canadian law, ethical practices, and common sense.  Members are responsible for the disclosure of their login credentials and the authentication of any and all content provided on their individual profile as well as any attached documentation including but not limited to resumes, certificates, reference letters etc.. The administrator of this provided environment has the privilege to remove anything deemed inappropriate only.  Any issues regarding to the removal of certain content or incident reports filed against the member are to be addressed through Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under Consequences of Policy Violation for further information.</p>
&nbsp;</td>
<td style="padding-left: 30px;" valign="top" width="368"><b>It is important to remember that Employers may only deactivate their accounts through Student Services. </b>All employers are bounded to NSCC and the student through an official contract process that requires some type of official signature.  This contract will be provided in this exchange environment, as well as on the official <a href="http://www.nscc.ca/">www.nscc.ca</a> (Press the “Programs &amp; Courses” tab on the official NSCC site, and then press “Work Experience &amp; CO-OP” tab on the left side bar at <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">http://www.nscc.ca/learning_programs/programs/default.aspx</a> ).  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.The administrator of this work placement has the privilege to remove anything deemed inappropriate only.  Employers are accountable for the disclosure of their login credentials and the authentication of any content provided in the job market. Any issues regarding to certain removals or incident reports of can be addressed to the Student Services of any NSCC campus.  NSCC follows a dispute resolution model focused on mediation.  In all cases the informal procedures must be followed prior to filing a formal appeal.  Academic integrity will also be taking seriously at NSCC.  For further information about the academic policies and procedures under which the College operates, or to find out more about the Appeal Policy, please contact Student Services at the nearest convenient NSCC location. You may also refer to the <span style="text-decoration: underline;">Computer Resource Usage Policy</span> under <b>Consequences of Policy Violation </b>for further<b> </b>information<b>.</b></td>
</tr>
</tbody>
</table>
<div>
<h2>Use of Information</h2>
</div>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-revision-v1', '', '', '2014-04-11 14:51:30', '2014-04-11 14:51:30', '', 1762, 'http://capstone.jonny.me/1762-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2399, 1, '2014-04-03 19:30:33', '2014-04-03 19:30:33', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.</span></p>
<p style="text-align: justify;"><span style="color: #1a1a4f;"><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a></span><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif"><img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif"><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></a></p>

<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 19:30:33', '2014-04-03 19:30:33', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2398, 1, '2014-04-03 19:07:48', '2014-04-03 19:07:48', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.
</span></p>
&nbsp;

&nbsp;
<h1 style="text-align: left;"><span style="color: #1a1a4f;"><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a></span><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif"><img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif"><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></a></h1>
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-03 19:07:48', '2014-04-03 19:07:48', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2401, 1, '2014-04-04 14:31:26', '2014-04-04 14:31:26', '', 'Reset Password', '', 'inherit', 'open', 'open', '', '2199-revision-v1', '', '', '2014-04-04 14:31:26', '2014-04-04 14:31:26', '', 2199, 'http://capstone.jonny.me/2199-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2413, 1, '2014-04-11 14:55:17', '2014-04-11 14:55:17', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.</span></p>

<div><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a></div>
<p style="text-align: justify;"><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif"><img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif"><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></p>
&nbsp;
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-11 14:55:17', '2014-04-11 14:55:17', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2402, 1, '2014-04-04 14:52:10', '2014-04-04 14:52:10', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.</span></p>
<p style="text-align: justify;"><span style="color: #1a1a4f;"><div><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow.gif"><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></a></span><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow.gif"><img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow.gif"><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /></a><a style="font-size: 2em; line-height: 1.5em;" href="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow.gif"><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" /></div></a></p>

<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-revision-v1', '', '', '2014-04-04 14:52:10', '2014-04-04 14:52:10', '', 2249, 'http://capstone.jonny.me/2249-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2403, 1, '2014-05-16 17:39:36', '2014-05-16 17:39:36', '<p style="text-align: justify;">    The job community website is based around connecting employers with students in the hunt for a job in our community. Students each year grad<span style="line-height: 1.5em;">uate and are looking for a career in their field. By registering with us we will allow students to search for jobs and apply right online and allow employers to post the jobs of their choosing. So let us connect you and find a career you\'ll love.</span></p>
<p style="text-align: justify;"><span class="spanAbout">Nova Scotia Community College (NSCC) is committed in building Nova Scotia’s economy and quality of life through education and innovation. Each year, more than 25,000 members choose to grow and learn with us in several different types of <a href="http://www.nscc.ca/learning_programs/programs/default.aspx">programs and courses</a>. We do our best to make dreams a reality, because we believe that education has power for positive growth and decision-making. However, our members could not have produced worthy results without potential employers like you. Let us work together to make each generation an opportunity in helping communities like yours prosper and thrive.</span></p>

<div><img class="alignnone size-medium wp-image-2383 promo" style="color: #333333; font-size: 14px; line-height: 1.5em;" alt="Business Solutions" src="http://capstone.jonny.me/wp-content/uploads/2014/04/bizSolutionsYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2387 promo" alt="Secured" src="http://capstone.jonny.me/wp-content/uploads/2014/04/securityYellow-300x300.gif" width="300" height="300" /></div>
<img class="alignnone size-medium wp-image-2384 promo" alt="Networking Opportunities" src="http://capstone.jonny.me/wp-content/uploads/2014/04/netYellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2386 promo" alt="Customizable Profile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/profile2Yellow-300x300.gif" width="300" height="300" /><img class="alignnone size-medium wp-image-2382 promo" alt="Mobile" src="http://capstone.jonny.me/wp-content/uploads/2014/04/mobileMarketingYellow-300x300.gif" width="300" height="300" />
<h1 style="text-align: left;"></h1>
<h1 style="text-align: left;"><span style="color: #1a1a4f;"> </span></h1>', 'About', '', 'inherit', 'open', 'open', '', '2249-autosave-v1', '', '', '2014-05-16 17:39:36', '2014-05-16 17:39:36', '', 2249, 'http://capstone.jonny.me/2249-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2410, 1, '2014-05-13 14:19:47', '2014-05-13 14:19:47', '<div>

<i>Last Updated:  3/20/2014</i>

</div>
<div>
<h1>Security</h1>
</div>
The web software used to build this communicative platform is WordPress.  WordPress as a software takes on <span style="text-decoration: underline;">security </span>(hyperlinks to <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> ) very seriously.  The NSCC web developers and the administrator are confident that they will be implementing best security practices mentioned at <a href="http://codex.wordpress.org/Hardening_WordPress">http://codex.wordpress.org/Hardening_WordPress</a> .

&nbsp;
<div>
<h1>Sharing Profile Policy</h1>
</div>
Anyone invited to participate in this environment will adhere to ethical practices by following the laws and Criminal Code of Canada under proper jurisdiction.  Complementary to the laws of Canada, Nova Scotia, and local governments, NSCC has a <span style="text-decoration: underline;">computer resources usage policy</span> (hyperlink to <a href="http://www.nscc.ca/it/policies/computer_usage_policy.asp">http://www.nscc.ca/it/policies/computer_usage_policy.asp</a> ) that strives to make this experience secure and professional as possible and in conjunction is to be followed at all times.

&nbsp;
<h1>Use of Information</h1>
The administrator has only the rights to delete inappropriate content, but has no rights to modify any appropriate content.  For future growth within the community, the employer’s contact information will always be kept as a record at NSCC, unless notified that the employer’s company no longer completely exists.

The information provided within each activated account will be used to privately match employers to members under NSCC. To facilitate your use of NSCC services further and addressing improvements, NSCC will also be gathering statistical data on every activated account by using “cookies”.  The cookies implemented in this collaborative platform cannot damage or read any information from the hard drive of your electronic device.  NSCC will only be collecting specific information regarding to performance, visiting, and demographic measures.  At no time does this collection of information compromise your personal information or privacy rights.  Passwords will always be encrypted.

&nbsp;', 'Privacy Policy', '', 'inherit', 'open', 'open', '', '1762-autosave-v1', '', '', '2014-05-13 14:19:47', '2014-05-13 14:19:47', '', 1762, 'http://capstone.jonny.me/1762-autosave-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2412, 45, '2014-04-11 14:54:06', '2014-04-11 14:54:06', '<p style="margin: 0px 0px 1em;color: #000000;font-family: Arial, sans-serif;font-size: 13px;line-height: 17.333332061767578px">Some of the main duties are:</p><p style="margin: 0px 0px 1em;color: #000000;font-family: Arial, sans-serif;font-size: 13px;line-height: 17.333332061767578px">· Oversee day-to-day activities of the IT Infrastructure organization<br />· Analyze performance of core IT systems, deliver solutions to enhance service, and to prevent problems<br />· Manage and monitor server and storage hardware and in-house data centers<br />· Design, administrate, and monitor Active Directory as well as storage (iSCSI)<br />· Administrate Microsoft Servers, including Exchange 2010, SQL Server, and SharePoint (2010, 2013).<br />· Manage the enterprise infrastructure team who oversee many critical backend systems, such as email, Active Directory, monitoring etc.<br />· Participate as an integral part of the IT Management team and be directly involved in decision-making that affects the IT environment<br />· Develop, maintain, and continuously update all enterprise IT security policies and programs to ensure compliance with internal and external controls<br />· Accountable for maintenance of data backups and Disaster Recovery Plans</p>', 'System Management', '', 'expired', 'closed', 'open', '', 'system-management', '', '', '2014-08-11 15:32:50', '2014-08-11 15:32:50', '', 0, 'http://capstone.jonny.me/job/generic-company-systems-managementnetworking-system-management/', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2418, 47, '2014-04-17 18:47:12', '2014-04-17 18:47:12', 'This job entails....', 'Web Programming', '', 'expired', 'closed', 'closed', '', 'nscc-halifax-web-programming-web-programming', '', '', '2014-08-11 15:32:50', '2014-08-11 15:32:50', '', 0, 'http://capstone.jonny.me/job/nscc-halifax-web-programming-web-programming/', 0, 'job_listing', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2420, 1, '2014-04-17 19:27:41', '2014-04-17 19:27:41', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div class="upload_job_info">
<h2 style="text-align: justify;"></h2>
<div>
<div class="company_information">
<h2>Company Information</h2>
[user-meta type=\'profile\' form=\'company_profile\']
<h2>Upload Job Information</h2>
[nm-wp-repo]

&nbsp;
<div></div>
&nbsp;

</div>
</div>
</div>', 'Company Profile', '', 'inherit', 'open', 'open', '', '2297-revision-v1', '', '', '2014-04-17 19:27:41', '2014-04-17 19:27:41', '', 2297, 'http://capstone.jonny.me/2297-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2421, 1, '2014-04-17 19:36:26', '2014-04-17 19:36:26', '<p style="text-align: justify;">[userinfo field="user_login" if="admin"]You are the admin[/userinfo]</p>

<div class="upload_job_info">
<p style="text-align: justify;">Hi..</p>

<div>
<div class="company_information">
<h2>Company Information</h2>
[user-meta type=\'profile\' form=\'company_profile\']
<h2>Upload Job Information</h2>
[nm-wp-repo]

&nbsp;
<div></div>
&nbsp;

</div>
</div>
</div>', 'Company Profile', '', 'inherit', 'open', 'open', '', '2297-revision-v1', '', '', '2014-04-17 19:36:26', '2014-04-17 19:36:26', '', 2297, 'http://capstone.jonny.me/2297-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------


#
# Delete any existing table `wp_smooth_slider`
#

DROP TABLE IF EXISTS `wp_smooth_slider`;


#
# Table structure of table `wp_smooth_slider`
#

CREATE TABLE `wp_smooth_slider` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `slider_id` int(5) NOT NULL DEFAULT '1',
  `slide_order` int(5) NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_smooth_slider (0 records)
#

#
# End of data contents of table wp_smooth_slider
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_meta`
# --------------------------------------------------------


#
# Delete any existing table `wp_smooth_slider_meta`
#

DROP TABLE IF EXISTS `wp_smooth_slider_meta`;


#
# Table structure of table `wp_smooth_slider_meta`
#

CREATE TABLE `wp_smooth_slider_meta` (
  `slider_id` int(5) NOT NULL AUTO_INCREMENT,
  `slider_name` varchar(100) NOT NULL DEFAULT '',
  UNIQUE KEY `slider_id` (`slider_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_smooth_slider_meta (1 records)
#
 
INSERT INTO `wp_smooth_slider_meta` VALUES (1, 'Smooth Slider') ;
#
# End of data contents of table wp_smooth_slider_meta
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_smooth_slider_postmeta`
#

DROP TABLE IF EXISTS `wp_smooth_slider_postmeta`;


#
# Table structure of table `wp_smooth_slider_postmeta`
#

CREATE TABLE `wp_smooth_slider_postmeta` (
  `post_id` int(11) NOT NULL,
  `slider_id` int(5) NOT NULL DEFAULT '1',
  UNIQUE KEY `post_id` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_smooth_slider_postmeta (0 records)
#

#
# End of data contents of table wp_smooth_slider_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (79 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2224, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2412, 18, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2428, 19, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2248, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2242, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2243, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2378, 25, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2225, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2328, 14, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2240, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2241, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2364, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2245, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2244, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2337, 20, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2333, 20, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2300, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2225, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2389, 20, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2168, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2169, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2170, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2171, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2172, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2173, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2174, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2175, 12, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2176, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2177, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2178, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2179, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2180, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2251, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2182, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2183, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1684, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1687, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1689, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1691, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1693, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1712, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1713, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1806, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1767, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1767, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1799, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1799, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1806, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1806, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1862, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1862, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1862, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1863, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1863, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1863, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1864, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1864, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1864, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1714, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1715, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1759, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1793, 10, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2023, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2184, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2185, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2186, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2187, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2192, 11, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2225, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2254, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2260, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2347, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2346, 13, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2408, 19, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2379, 20, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2392, 20, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2427, 15, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2418, 14, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (20 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (18, 18, 'job_listing_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (16, 16, 'job_listing_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (14, 14, 'job_listing_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (9, 9, 'testimonial-category', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (10, 10, 'testimonial-category', '', 0, 6) ; 
INSERT INTO `wp_term_taxonomy` VALUES (11, 11, 'nav_menu', '', 0, 13) ; 
INSERT INTO `wp_term_taxonomy` VALUES (12, 12, 'nav_menu', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (15, 15, 'job_listing_type', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (17, 17, 'job_listing_type', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (13, 13, 'nav_menu', '', 0, 14) ; 
INSERT INTO `wp_term_taxonomy` VALUES (19, 19, 'job_listing_type', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (20, 20, 'ml-slider', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (21, 21, 'ml-slider', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (22, 22, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (23, 23, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (24, 24, 'category', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (25, 25, 'ml-slider', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (20 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (16, 'Database Developer', 'database-development', 0) ; 
INSERT INTO `wp_terms` VALUES (15, 'Programming', 'programming', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'Developement', 'developement', 0) ; 
INSERT INTO `wp_terms` VALUES (8, 'News', 'news', 0) ; 
INSERT INTO `wp_terms` VALUES (9, 'company', 'company', 0) ; 
INSERT INTO `wp_terms` VALUES (10, 'Individual', 'individual', 0) ; 
INSERT INTO `wp_terms` VALUES (11, 'Main menu', 'main-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (12, 'Social Links', 'social-links', 0) ; 
INSERT INTO `wp_terms` VALUES (13, 'main_v2', 'main_v2', 0) ; 
INSERT INTO `wp_terms` VALUES (14, 'Web Programming', 'web-programming', 0) ; 
INSERT INTO `wp_terms` VALUES (17, 'Database Admin', 'database-administration', 0) ; 
INSERT INTO `wp_terms` VALUES (18, 'Systems Management', 'systems-managementnetworking', 0) ; 
INSERT INTO `wp_terms` VALUES (19, 'Comp. Electronics Tech', 'computer-electronics-technician', 0) ; 
INSERT INTO `wp_terms` VALUES (20, '2230', '2230', 0) ; 
INSERT INTO `wp_terms` VALUES (21, '2236', '2236', 0) ; 
INSERT INTO `wp_terms` VALUES (22, 'General Information', 'general-information', 0) ; 
INSERT INTO `wp_terms` VALUES (23, 'Employers', 'employers', 0) ; 
INSERT INTO `wp_terms` VALUES (24, 'Applicants', 'applicants', 0) ; 
INSERT INTO `wp_terms` VALUES (25, '2332', '2332', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=722 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (599 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', 'Administrator') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_user-settings', 'hidetb=1&editor=html&libraryContent=upload&mfold=o&ed_size=853') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_user-settings-time', '1403887966') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_dashboard_quick_press_last_post_id', '2430') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'nav_menu_recently_edited', '13') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'managenav-menuscolumnshidden', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (150, 11, 'wp_aam_activity', 'a:1:{i:1392926258;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_nav-menus', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (148, 11, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (147, 11, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'jobify-hide-plugin-notice', '1') ; 
INSERT INTO `wp_usermeta` VALUES (272, 22, 'nickname', 'Diana Turple') ; 
INSERT INTO `wp_usermeta` VALUES (271, 22, 'last_name', 'Turple') ; 
INSERT INTO `wp_usermeta` VALUES (270, 22, 'first_name', 'Diana') ; 
INSERT INTO `wp_usermeta` VALUES (269, 21, 'wp_aam_activity', 'a:1:{i:1392994761;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (268, 21, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (267, 21, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (266, 21, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (263, 21, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (264, 21, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (265, 21, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (33, 1, 'wporg_favorites', 'jonnymaceachern') ; 
INSERT INTO `wp_usermeta` VALUES (262, 21, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (261, 21, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (260, 21, 'nickname', 'Keila Mak') ; 
INSERT INTO `wp_usermeta` VALUES (259, 21, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (258, 21, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (39, 3, 'first_name', 'test') ; 
INSERT INTO `wp_usermeta` VALUES (40, 3, 'last_name', 'test') ; 
INSERT INTO `wp_usermeta` VALUES (41, 3, 'nickname', 'test') ; 
INSERT INTO `wp_usermeta` VALUES (42, 3, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (43, 3, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (44, 3, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (45, 3, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (46, 3, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (47, 3, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (48, 3, 'wp_capabilities', 'a:1:{s:6:"author";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (49, 3, 'wp_user_level', '2') ; 
INSERT INTO `wp_usermeta` VALUES (50, 3, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (320, 26, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (321, 26, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (327, 25, '_company_name', 'Titz\'n Glitz') ; 
INSERT INTO `wp_usermeta` VALUES (326, 26, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (325, 26, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (324, 26, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (323, 26, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (62, 1, 'wp_aam_activity', 'a:19:{i:1403877180;a:1:{s:6:"action";s:5:"login";}i:1403877188;a:1:{s:6:"action";s:6:"logout";}i:1403877569;a:1:{s:6:"action";s:5:"login";}i:1403878242;a:1:{s:6:"action";s:6:"logout";}i:1403880898;a:1:{s:6:"action";s:5:"login";}i:1403890012;a:1:{s:6:"action";s:6:"logout";}i:1403890037;a:1:{s:6:"action";s:5:"login";}i:1403890043;a:1:{s:6:"action";s:6:"logout";}i:1403890077;a:1:{s:6:"action";s:5:"login";}i:1403890099;a:1:{s:6:"action";s:5:"login";}i:1403890101;a:1:{s:6:"action";s:5:"login";}i:1403890907;a:1:{s:6:"action";s:5:"login";}i:1403890909;a:1:{s:6:"action";s:5:"login";}i:1403892903;a:1:{s:6:"action";s:6:"logout";}i:1404265156;a:1:{s:6:"action";s:5:"login";}i:1404301992;a:1:{s:6:"action";s:5:"login";}i:1404319221;a:1:{s:6:"action";s:5:"login";}i:1404405930;a:1:{s:6:"action";s:5:"login";}i:1404407394;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (714, 1, 'metaboxhidden_sidebar', 'a:2:{i:0;s:13:"pageparentdiv";i:1;s:7:"slugdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (715, 1, 'closedpostboxes_sidebar', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (708, 31, 'wp_aam_activity', 'a:1:{i:1401122934;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (709, 31, 'program_stream', '1st Year') ; 
INSERT INTO `wp_usermeta` VALUES (660, 50, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (661, 50, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (662, 50, 'nickname', 'Anthony Scarfone') ; 
INSERT INTO `wp_usermeta` VALUES (663, 50, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (664, 50, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (665, 50, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (666, 50, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (667, 50, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (668, 50, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (669, 50, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (63, 1, 'closedpostboxes_page', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (64, 1, 'metaboxhidden_page', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (65, 1, 'closedpostboxes_nav-menus', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (149, 11, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (146, 11, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (145, 11, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (144, 11, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (143, 11, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (142, 11, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (141, 11, 'nickname', 'RFP - KNOX UNITED CHURCH') ; 
INSERT INTO `wp_usermeta` VALUES (140, 11, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (139, 11, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (78, 6, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (79, 6, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (80, 6, 'nickname', 'Irving Shipyards') ; 
INSERT INTO `wp_usermeta` VALUES (81, 6, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (82, 6, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (83, 6, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (84, 6, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (85, 6, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (86, 6, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (87, 6, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (88, 6, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (89, 6, 'wp_aam_activity', 'a:7:{i:1392924788;a:1:{s:6:"action";s:6:"logout";}i:1393097678;a:1:{s:6:"action";s:5:"login";}i:1393098466;a:1:{s:6:"action";s:6:"logout";}i:1393098691;a:1:{s:6:"action";s:5:"login";}i:1393099981;a:1:{s:6:"action";s:6:"logout";}i:1393100597;a:1:{s:6:"action";s:5:"login";}i:1394124073;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (90, 7, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (91, 7, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (92, 7, 'nickname', 'Frontier Technologies') ; 
INSERT INTO `wp_usermeta` VALUES (93, 7, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (94, 7, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (95, 7, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (96, 7, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (97, 7, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (98, 7, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (99, 7, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (100, 7, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (101, 7, 'wp_aam_activity', 'a:3:{i:1392925079;a:1:{s:6:"action";s:6:"logout";}i:1392925490;a:1:{s:6:"action";s:5:"login";}i:1392925509;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (138, 10, 'wp_aam_activity', 'a:1:{i:1392926092;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (137, 10, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (136, 10, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (133, 10, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (134, 10, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (135, 10, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (132, 10, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (131, 10, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (114, 1, 'soliloquy_dismissed_notice', '1') ; 
INSERT INTO `wp_usermeta` VALUES (130, 10, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (127, 10, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (128, 10, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (129, 10, 'nickname', 'RFP - City of the Dead Halifax and the Titanic Disaster') ; 
INSERT INTO `wp_usermeta` VALUES (151, 12, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (152, 12, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (153, 12, 'nickname', 'Department of National Defenses') ; 
INSERT INTO `wp_usermeta` VALUES (154, 12, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (155, 12, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (156, 12, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (157, 12, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (158, 12, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (159, 12, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (160, 12, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (161, 12, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (162, 12, 'wp_aam_activity', 'a:3:{i:1392926785;a:1:{s:6:"action";s:6:"logout";}i:1392998064;a:1:{s:6:"action";s:5:"login";}i:1392998128;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (163, 13, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (164, 13, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (165, 13, 'nickname', 'Esterline') ; 
INSERT INTO `wp_usermeta` VALUES (166, 13, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (167, 13, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (168, 13, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (169, 13, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (170, 13, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (171, 13, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (172, 13, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (173, 13, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (174, 13, 'wp_aam_activity', 'a:19:{i:1392928484;a:1:{s:6:"action";s:6:"logout";}i:1392928502;a:1:{s:6:"action";s:5:"login";}i:1392928520;a:1:{s:6:"action";s:5:"login";}i:1392928595;a:1:{s:6:"action";s:6:"logout";}i:1392928633;a:1:{s:6:"action";s:5:"login";}i:1392928900;a:1:{s:6:"action";s:5:"login";}i:1392929119;a:1:{s:6:"action";s:5:"login";}i:1392929123;a:1:{s:6:"action";s:5:"login";}i:1392929128;a:1:{s:6:"action";s:5:"login";}i:1392929131;a:1:{s:6:"action";s:5:"login";}i:1392929137;a:1:{s:6:"action";s:6:"logout";}i:1392929176;a:1:{s:6:"action";s:5:"login";}i:1392929189;a:1:{s:6:"action";s:6:"logout";}i:1392929312;a:1:{s:6:"action";s:5:"login";}i:1392929549;a:1:{s:6:"action";s:5:"login";}i:1392929609;a:1:{s:6:"action";s:5:"login";}i:1392929660;a:1:{s:6:"action";s:6:"logout";}i:1392929673;a:1:{s:6:"action";s:5:"login";}i:1392929730;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (175, 14, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (176, 14, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (177, 14, 'nickname', 'student') ; 
INSERT INTO `wp_usermeta` VALUES (178, 14, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (179, 14, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (180, 14, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (181, 14, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (182, 14, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (183, 14, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (184, 14, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (185, 14, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (186, 14, 'wp_aam_activity', 'a:2:{i:1399997192;a:1:{s:6:"action";s:5:"login";}i:1399997194;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (187, 15, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (188, 15, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (189, 15, 'nickname', 'Colin Sampson') ; 
INSERT INTO `wp_usermeta` VALUES (190, 15, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (191, 15, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (192, 15, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (193, 15, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (194, 15, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (195, 15, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (196, 15, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (197, 15, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (198, 15, 'wp_aam_activity', 'a:4:{i:1392994360;a:1:{s:6:"action";s:6:"logout";}i:1392998140;a:1:{s:6:"action";s:5:"login";}i:1392998175;a:1:{s:6:"action";s:5:"login";}i:1392998280;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (199, 16, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (200, 16, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (201, 16, 'nickname', 'Ryan Mahoney') ; 
INSERT INTO `wp_usermeta` VALUES (202, 16, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (203, 16, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (204, 16, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (205, 16, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (206, 16, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (207, 16, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (208, 16, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (209, 16, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (210, 16, 'wp_aam_activity', 'a:1:{i:1392994407;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (211, 17, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (212, 17, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (213, 17, 'nickname', 'Corey MacMullin') ; 
INSERT INTO `wp_usermeta` VALUES (214, 17, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (215, 17, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (216, 17, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (217, 17, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (218, 17, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (219, 17, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (220, 17, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (221, 17, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (222, 17, 'wp_aam_activity', 'a:2:{i:1392994507;a:1:{s:6:"action";s:6:"logout";}i:1392998610;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (223, 18, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (224, 18, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (225, 18, 'nickname', 'Lawrence Lelo') ; 
INSERT INTO `wp_usermeta` VALUES (226, 18, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (227, 18, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (228, 18, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (229, 18, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (230, 18, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (231, 18, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (232, 18, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (233, 18, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (234, 18, 'wp_aam_activity', 'a:1:{i:1392994576;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (235, 19, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (236, 19, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (237, 19, 'nickname', 'Cameron Evans') ; 
INSERT INTO `wp_usermeta` VALUES (238, 19, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (239, 19, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (240, 19, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (241, 19, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (242, 19, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (243, 19, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (468, 19, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (246, 20, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (247, 20, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (248, 20, 'nickname', 'Jonny MacEachern') ; 
INSERT INTO `wp_usermeta` VALUES (249, 20, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (250, 20, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (251, 20, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (252, 20, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (253, 20, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (254, 20, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (255, 20, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (256, 20, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (257, 20, 'wp_aam_activity', 'a:1:{i:1392994677;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (273, 22, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (274, 22, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (275, 22, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (276, 22, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (277, 22, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (278, 22, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (279, 22, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (280, 22, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (281, 22, 'wp_aam_activity', 'a:6:{i:1392994850;a:1:{s:6:"action";s:6:"logout";}i:1394205685;a:1:{s:6:"action";s:5:"login";}i:1394709845;a:1:{s:6:"action";s:5:"login";}i:1394987502;a:1:{s:6:"action";s:5:"login";}i:1394991571;a:1:{s:6:"action";s:6:"logout";}i:1394992992;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (322, 26, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (319, 26, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (318, 26, 'nickname', 'Jonny') ; 
INSERT INTO `wp_usermeta` VALUES (304, 25, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (305, 25, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (306, 25, 'nickname', 'Titzn Glitz On The Front Line Society') ; 
INSERT INTO `wp_usermeta` VALUES (307, 25, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (308, 25, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (309, 25, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (310, 25, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (311, 25, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (312, 25, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (313, 25, 'wp_capabilities', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (314, 25, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (316, 26, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (317, 26, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (328, 25, '_company_website', '') ; 
INSERT INTO `wp_usermeta` VALUES (329, 25, '_company_tagline', '') ; 
INSERT INTO `wp_usermeta` VALUES (330, 25, '_company_twitter', '') ; 
INSERT INTO `wp_usermeta` VALUES (331, 25, '_company_logo', '') ; 
INSERT INTO `wp_usermeta` VALUES (332, 25, 'wp_aam_activity', 'a:1:{i:1392997652;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (333, 6, '_company_name', 'Irving Shipyards') ; 
INSERT INTO `wp_usermeta` VALUES (334, 6, '_company_website', '') ; 
INSERT INTO `wp_usermeta` VALUES (335, 6, '_company_tagline', '') ; 
INSERT INTO `wp_usermeta` VALUES (336, 6, '_company_twitter', '') ; 
INSERT INTO `wp_usermeta` VALUES (337, 6, '_company_logo', '') ; 
INSERT INTO `wp_usermeta` VALUES (338, 19, 'wp_aam_activity', 'a:19:{i:1395242115;a:1:{s:6:"action";s:5:"login";}i:1395327176;a:1:{s:6:"action";s:5:"login";}i:1395327437;a:1:{s:6:"action";s:6:"logout";}i:1395327547;a:1:{s:6:"action";s:5:"login";}i:1396545123;a:1:{s:6:"action";s:5:"login";}i:1396545926;a:1:{s:6:"action";s:6:"logout";}i:1396546034;a:1:{s:6:"action";s:5:"login";}i:1397072904;a:1:{s:6:"action";s:5:"login";}i:1397072932;a:1:{s:6:"action";s:6:"logout";}i:1397073229;a:1:{s:6:"action";s:5:"login";}i:1397076832;a:1:{s:6:"action";s:6:"logout";}i:1397224107;a:1:{s:6:"action";s:5:"login";}i:1397228233;a:1:{s:6:"action";s:5:"login";}i:1397230437;a:1:{s:6:"action";s:5:"login";}i:1397230442;a:1:{s:6:"action";s:6:"logout";}i:1397230926;a:1:{s:6:"action";s:5:"login";}i:1397231311;a:1:{s:6:"action";s:6:"logout";}i:1397231438;a:1:{s:6:"action";s:5:"login";}i:1397696033;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (339, 26, 'wp_aam_activity', 'a:1:{i:1393563673;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (340, 27, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (341, 27, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (342, 27, 'nickname', 'Test Company') ; 
INSERT INTO `wp_usermeta` VALUES (343, 27, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (344, 27, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (345, 27, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (346, 27, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (347, 27, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (348, 27, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (349, 27, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (350, 27, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (351, 27, 'wp_aam_activity', 'a:1:{i:1393595820;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (352, 28, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (353, 28, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (354, 28, 'nickname', 'test1') ; 
INSERT INTO `wp_usermeta` VALUES (355, 28, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (356, 28, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (357, 28, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (358, 28, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (359, 28, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (360, 28, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (361, 28, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (362, 28, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (363, 28, 'wp_aam_activity', 'a:19:{i:1395269696;a:1:{s:6:"action";s:5:"login";}i:1395269731;a:1:{s:6:"action";s:6:"logout";}i:1395269732;a:1:{s:6:"action";s:6:"logout";}i:1395332471;a:1:{s:6:"action";s:5:"login";}i:1395332480;a:1:{s:6:"action";s:6:"logout";}i:1395332525;a:1:{s:6:"action";s:5:"login";}i:1395332823;a:1:{s:6:"action";s:5:"login";}i:1395332858;a:1:{s:6:"action";s:6:"logout";}i:1395332964;a:1:{s:6:"action";s:5:"login";}i:1395333353;a:1:{s:6:"action";s:6:"logout";}i:1395334038;a:1:{s:6:"action";s:5:"login";}i:1395334055;a:1:{s:6:"action";s:6:"logout";}i:1395335301;a:1:{s:6:"action";s:5:"login";}i:1395335353;a:1:{s:6:"action";s:6:"logout";}i:1395335417;a:1:{s:6:"action";s:5:"login";}i:1395335716;a:1:{s:6:"action";s:6:"logout";}i:1397227191;a:1:{s:6:"action";s:5:"login";}i:1397227201;a:1:{s:6:"action";s:6:"logout";}i:1397229239;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (364, 29, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (365, 29, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (366, 29, 'nickname', 'test2') ; 
INSERT INTO `wp_usermeta` VALUES (367, 29, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (368, 29, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (369, 29, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (370, 29, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (371, 29, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (372, 29, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (373, 29, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (374, 29, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (375, 29, 'wp_aam_activity', 'a:3:{i:1393599201;a:1:{s:6:"action";s:6:"logout";}i:1395332494;a:1:{s:6:"action";s:5:"login";}i:1395332508;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (376, 30, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (377, 30, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (378, 30, 'nickname', 'test21') ; 
INSERT INTO `wp_usermeta` VALUES (379, 30, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (380, 30, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (381, 30, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (382, 30, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (383, 30, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (384, 30, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (385, 30, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (386, 30, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (387, 30, 'wp_aam_activity', 'a:5:{i:1395332593;a:1:{s:6:"action";s:5:"login";}i:1395332607;a:1:{s:6:"action";s:6:"logout";}i:1397227243;a:1:{s:6:"action";s:5:"login";}i:1397228972;a:1:{s:6:"action";s:5:"login";}i:1397229233;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (388, 31, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (389, 31, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (390, 31, 'nickname', 'aaa') ; 
INSERT INTO `wp_usermeta` VALUES (391, 31, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (392, 31, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (393, 31, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (394, 31, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (395, 31, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (396, 31, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (397, 31, 'wp_capabilities', 'a:2:{s:9:"candidate";b:1;s:21:"aamrole_532b177d52ab8";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (398, 31, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (536, 19, 'dismissed_wp_pointers', 'wp330_toolbar') ; 
INSERT INTO `wp_usermeta` VALUES (399, 1, 'program_stream', 'Systems Management/Networking') ; 
INSERT INTO `wp_usermeta` VALUES (670, 50, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (400, 19, 'program_stream', 'Database Development') ; 
INSERT INTO `wp_usermeta` VALUES (401, 32, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (402, 32, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (403, 32, 'nickname', 'test3') ; 
INSERT INTO `wp_usermeta` VALUES (404, 32, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (405, 32, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (406, 32, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (407, 32, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (408, 32, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (409, 32, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (410, 32, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (411, 32, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (412, 32, 'wp_aam_activity', 'a:1:{i:1394031683;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (702, 46, '_company_name', 'Fake company') ; 
INSERT INTO `wp_usermeta` VALUES (703, 46, '_company_website', '') ; 
INSERT INTO `wp_usermeta` VALUES (704, 46, '_company_tagline', '') ; 
INSERT INTO `wp_usermeta` VALUES (705, 46, '_company_twitter', '') ; 
INSERT INTO `wp_usermeta` VALUES (706, 46, '_company_logo', '') ; 
INSERT INTO `wp_usermeta` VALUES (547, 42, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (548, 42, 'wp_aam_activity', 'a:9:{i:1397078099;a:1:{s:6:"action";s:6:"logout";}i:1397224002;a:1:{s:6:"action";s:5:"login";}i:1397224055;a:1:{s:6:"action";s:6:"logout";}i:1397231331;a:1:{s:6:"action";s:5:"login";}i:1397231339;a:1:{s:6:"action";s:6:"logout";}i:1397755734;a:1:{s:6:"action";s:5:"login";}i:1397755748;a:1:{s:6:"action";s:6:"logout";}i:1397761645;a:1:{s:6:"action";s:5:"login";}i:1397761883;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (544, 42, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (545, 42, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (546, 42, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (541, 42, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (542, 42, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (543, 42, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (540, 42, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (539, 42, 'nickname', 'candidate') ; 
INSERT INTO `wp_usermeta` VALUES (413, 33, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (414, 33, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (415, 33, 'nickname', 'Bob Jones') ; 
INSERT INTO `wp_usermeta` VALUES (416, 33, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (417, 33, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (418, 33, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (419, 33, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (420, 33, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (421, 33, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (422, 33, 'wp_capabilities', 'a:1:{i:10;b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (423, 33, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (424, 34, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (425, 34, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (426, 34, 'nickname', 'CompanyTest') ; 
INSERT INTO `wp_usermeta` VALUES (427, 34, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (428, 34, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (429, 34, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (430, 34, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (431, 34, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (432, 34, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (433, 34, 'wp_capabilities', 'a:1:{i:10;b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (434, 34, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (435, 34, 'wp_aam_activity', 'a:5:{i:1394135316;a:1:{s:6:"action";s:6:"logout";}i:1394135429;a:1:{s:6:"action";s:5:"login";}i:1394135436;a:1:{s:6:"action";s:6:"logout";}i:1394135589;a:1:{s:6:"action";s:5:"login";}i:1394135824;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (707, 52, 'wp_aam_activity', 'a:2:{i:1400262219;a:1:{s:6:"action";s:5:"login";}i:1401106016;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (537, 42, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (538, 42, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (555, 43, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (526, 41, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (527, 41, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (528, 41, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (529, 41, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (530, 41, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (531, 41, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (532, 41, 'wp_aam_activity', 'a:1:{i:1396545809;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (549, 43, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (583, 45, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (581, 44, 'wp_aam_activity', 'a:1:{i:1397227441;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (582, 45, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (436, 3, 'wp_aam_activity', 'a:1:{i:1394209227;a:1:{s:6:"action";s:5:"login";}}') ; 
INSERT INTO `wp_usermeta` VALUES (579, 44, 'skills', '') ; 
INSERT INTO `wp_usermeta` VALUES (580, 44, 'education', '') ; 
INSERT INTO `wp_usermeta` VALUES (577, 44, 'program_stream', '1st Year') ; 
INSERT INTO `wp_usermeta` VALUES (578, 44, 'phone_number', '123 456 7890') ; 
INSERT INTO `wp_usermeta` VALUES (572, 44, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (573, 44, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (574, 44, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (437, 22, '_company_name', 'WebGirl') ; 
INSERT INTO `wp_usermeta` VALUES (438, 22, '_company_website', '') ; 
INSERT INTO `wp_usermeta` VALUES (439, 22, '_company_tagline', '') ; 
INSERT INTO `wp_usermeta` VALUES (440, 22, '_company_twitter', '') ; 
INSERT INTO `wp_usermeta` VALUES (441, 22, '_company_logo', 'http://capstone.jonny.me/wp-content/uploads/job_listings/pink-pearl-my-computer.png') ; 
INSERT INTO `wp_usermeta` VALUES (442, 22, 'program_stream', 'Database Development') ; 
INSERT INTO `wp_usermeta` VALUES (575, 44, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (576, 44, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (558, 43, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (559, 43, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (568, 44, 'nickname', 'John Smith1') ; 
INSERT INTO `wp_usermeta` VALUES (569, 44, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (570, 44, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (571, 44, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (443, 35, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (444, 35, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (445, 35, 'nickname', 'John Smith') ; 
INSERT INTO `wp_usermeta` VALUES (446, 35, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (447, 35, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (448, 35, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (449, 35, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (450, 35, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (451, 35, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (452, 35, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (453, 35, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (454, 35, 'wp_aam_activity', 'a:1:{i:1395287813;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (455, 36, 'first_name', 'Bob') ; 
INSERT INTO `wp_usermeta` VALUES (456, 36, 'last_name', 'Jones') ; 
INSERT INTO `wp_usermeta` VALUES (457, 36, 'nickname', 'Bob Jones1') ; 
INSERT INTO `wp_usermeta` VALUES (458, 36, 'description', 'This is the users bio. Test 123.') ; 
INSERT INTO `wp_usermeta` VALUES (459, 36, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (460, 36, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (461, 36, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (462, 36, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (463, 36, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (464, 36, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (465, 36, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (471, 1, 'skills', '') ; 
INSERT INTO `wp_usermeta` VALUES (466, 36, 'program_stream', 'Programming') ; 
INSERT INTO `wp_usermeta` VALUES (467, 36, 'wp_aam_activity', 'a:6:{i:1395289009;a:1:{s:6:"action";s:5:"login";}i:1395320796;a:1:{s:6:"action";s:5:"login";}i:1395321147;a:1:{s:6:"action";s:5:"login";}i:1395331386;a:1:{s:6:"action";s:5:"login";}i:1395332094;a:1:{s:6:"action";s:5:"login";}i:1395332098;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (587, 45, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (588, 45, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (556, 43, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (557, 43, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (469, 19, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (554, 43, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (533, 19, 'phone_number', '123-345-3456') ; 
INSERT INTO `wp_usermeta` VALUES (534, 19, 'skills', '') ; 
INSERT INTO `wp_usermeta` VALUES (535, 19, 'education', '') ; 
INSERT INTO `wp_usermeta` VALUES (550, 43, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (551, 43, 'nickname', 'Acme Design Co.') ; 
INSERT INTO `wp_usermeta` VALUES (552, 43, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (553, 43, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (470, 1, 'phone_number', '') ; 
INSERT INTO `wp_usermeta` VALUES (589, 45, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (590, 45, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (472, 1, 'education', '') ; 
INSERT INTO `wp_usermeta` VALUES (585, 45, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (586, 45, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (473, 37, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (474, 37, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (475, 37, 'nickname', 'Test Employer') ; 
INSERT INTO `wp_usermeta` VALUES (476, 37, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (477, 37, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (478, 37, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (479, 37, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (480, 37, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (481, 37, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (482, 37, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (483, 37, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (584, 45, 'nickname', 'Generic Company') ; 
INSERT INTO `wp_usermeta` VALUES (484, 38, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (485, 38, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (486, 38, 'nickname', 'nicole') ; 
INSERT INTO `wp_usermeta` VALUES (487, 38, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (488, 38, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (489, 38, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (490, 38, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (491, 38, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (492, 38, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (493, 38, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (494, 38, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (495, 38, 'wp_aam_activity', 'a:11:{i:1395332692;a:1:{s:6:"action";s:6:"logout";}i:1395332802;a:1:{s:6:"action";s:5:"login";}i:1395332813;a:1:{s:6:"action";s:6:"logout";}i:1395332908;a:1:{s:6:"action";s:5:"login";}i:1395332915;a:1:{s:6:"action";s:6:"logout";}i:1395334062;a:1:{s:6:"action";s:5:"login";}i:1395334237;a:1:{s:6:"action";s:6:"logout";}i:1395335372;a:1:{s:6:"action";s:5:"login";}i:1395335411;a:1:{s:6:"action";s:6:"logout";}i:1396545626;a:1:{s:6:"action";s:5:"login";}i:1396545665;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (496, 39, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (497, 39, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (498, 39, 'nickname', 'Test Company 3') ; 
INSERT INTO `wp_usermeta` VALUES (499, 39, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (500, 39, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (501, 39, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (502, 39, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (503, 39, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (504, 39, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (505, 39, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (506, 39, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (507, 39, 'wp_aam_activity', 'a:1:{i:1395333076;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (508, 40, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (509, 40, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (510, 40, 'nickname', 'Test Employee') ; 
INSERT INTO `wp_usermeta` VALUES (511, 40, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (512, 40, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (513, 40, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (514, 40, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (515, 40, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (516, 40, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (517, 40, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (518, 40, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (566, 44, 'first_name', 'John') ; 
INSERT INTO `wp_usermeta` VALUES (567, 44, 'last_name', 'Smith') ; 
INSERT INTO `wp_usermeta` VALUES (564, 43, '_company_logo', '') ; 
INSERT INTO `wp_usermeta` VALUES (565, 43, 'wp_aam_activity', 'a:1:{i:1397227233;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (562, 43, '_company_tagline', '') ; 
INSERT INTO `wp_usermeta` VALUES (563, 43, '_company_twitter', '') ; 
INSERT INTO `wp_usermeta` VALUES (521, 41, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (522, 41, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (560, 43, '_company_name', 'Acme Design Co.') ; 
INSERT INTO `wp_usermeta` VALUES (561, 43, '_company_website', '') ; 
INSERT INTO `wp_usermeta` VALUES (519, 1, 'closedpostboxes_job_listing', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (520, 1, 'metaboxhidden_job_listing', 'a:1:{i:0;s:7:"slugdiv";}') ; 
INSERT INTO `wp_usermeta` VALUES (523, 41, 'nickname', 'nicole1') ; 
INSERT INTO `wp_usermeta` VALUES (524, 41, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (525, 41, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (591, 45, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (592, 45, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (593, 45, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (594, 45, '_company_name', 'Generic Company') ; 
INSERT INTO `wp_usermeta` VALUES (595, 45, '_company_website', '') ; 
INSERT INTO `wp_usermeta` VALUES (596, 45, '_company_tagline', '') ; 
INSERT INTO `wp_usermeta` VALUES (597, 45, '_company_twitter', '') ; 
INSERT INTO `wp_usermeta` VALUES (598, 45, '_company_logo', '') ; 
INSERT INTO `wp_usermeta` VALUES (599, 45, 'wp_aam_activity', 'a:1:{i:1397228094;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (600, 46, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (601, 46, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (602, 46, 'nickname', 'company') ; 
INSERT INTO `wp_usermeta` VALUES (603, 46, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (604, 46, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (605, 46, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (606, 46, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (607, 46, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (608, 46, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (609, 46, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (610, 46, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (701, 46, 'wp_aam_activity', 'a:6:{i:1400178920;a:1:{s:6:"action";s:5:"login";}i:1400179006;a:1:{s:6:"action";s:6:"logout";}i:1400260214;a:1:{s:6:"action";s:5:"login";}i:1400260288;a:1:{s:6:"action";s:6:"logout";}i:1400262189;a:1:{s:6:"action";s:5:"login";}i:1400262209;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (698, 52, 'wp_capabilities', 'a:1:{s:11:"candidateid";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (696, 52, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (697, 52, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (694, 52, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (695, 52, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (693, 52, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (692, 52, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (671, 50, 'wp_aam_activity', 'a:10:{i:1400092247;a:1:{s:6:"action";s:6:"logout";}i:1400092630;a:1:{s:6:"action";s:5:"login";}i:1400092801;a:1:{s:6:"action";s:6:"logout";}i:1400093011;a:1:{s:6:"action";s:5:"login";}i:1400093031;a:1:{s:6:"action";s:6:"logout";}i:1400093071;a:1:{s:6:"action";s:5:"login";}i:1400093310;a:1:{s:6:"action";s:5:"login";}i:1400093437;a:1:{s:6:"action";s:6:"logout";}i:1400093538;a:1:{s:6:"action";s:5:"login";}i:1400095461;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (691, 52, 'nickname', 'student') ; 
INSERT INTO `wp_usermeta` VALUES (690, 52, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (689, 52, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (628, 42, 'program_stream', '1st Year') ; 
INSERT INTO `wp_usermeta` VALUES (629, 42, 'phone_number', '') ; 
INSERT INTO `wp_usermeta` VALUES (630, 42, 'skills', '') ; 
INSERT INTO `wp_usermeta` VALUES (631, 42, 'education', '') ; 
INSERT INTO `wp_usermeta` VALUES (632, 48, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (633, 48, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (634, 48, 'nickname', 'This Test') ; 
INSERT INTO `wp_usermeta` VALUES (635, 48, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (636, 48, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (637, 48, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (638, 48, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (639, 48, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (640, 48, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (641, 48, 'wp_capabilities', 'a:1:{s:10:"subscriber";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (642, 48, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (643, 48, 'wp_aam_activity', 'a:1:{i:1397763517;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (644, 49, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (645, 49, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (646, 49, 'nickname', 'This Test1') ; 
INSERT INTO `wp_usermeta` VALUES (647, 49, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (648, 49, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (649, 49, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (650, 49, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (651, 49, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (652, 49, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (653, 49, 'wp_capabilities', 'a:1:{s:9:"candidate";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (654, 49, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (655, 49, 'wp_aam_activity', 'a:1:{i:1397763651;a:1:{s:6:"action";s:6:"logout";}}') ; 
INSERT INTO `wp_usermeta` VALUES (699, 52, 'wp_user_level', '0') ; 
INSERT INTO `wp_usermeta` VALUES (700, 52, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks') ; 
INSERT INTO `wp_usermeta` VALUES (684, 50, '_company_name', 'Scarfone Incorporated') ; 
INSERT INTO `wp_usermeta` VALUES (685, 50, '_company_website', '') ; 
INSERT INTO `wp_usermeta` VALUES (686, 50, '_company_tagline', '') ; 
INSERT INTO `wp_usermeta` VALUES (687, 50, '_company_twitter', '') ; 
INSERT INTO `wp_usermeta` VALUES (688, 50, '_company_logo', '') ; 
INSERT INTO `wp_usermeta` VALUES (710, 31, 'phone_number', '') ; 
INSERT INTO `wp_usermeta` VALUES (711, 31, 'phone_cell', 'hello world') ; 
INSERT INTO `wp_usermeta` VALUES (712, 31, 'skills', '') ; 
INSERT INTO `wp_usermeta` VALUES (713, 31, 'education', '') ; 
INSERT INTO `wp_usermeta` VALUES (716, 53, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (717, 53, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (718, 53, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (719, 53, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (720, 53, 'nickname', 'jbaikie') ; 
INSERT INTO `wp_usermeta` VALUES (721, 53, 'wp_aam_activity', 'a:1:{i:1407771186;a:1:{s:6:"action";s:5:"login";}}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost/itworks MySQL database backup
#
# Generated: Monday 11. August 2014 15:33 UTC
# Hostname: localhost
# Database: `database`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_duplicator_packages`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_filemeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_maxbuttons_buttons`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_layouts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nextend_smartslider_storage`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_nm_repositories`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_optinrev`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_meta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_smooth_slider_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (44 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'admin', '$P$BTyPLuM/jxjgD229H.g9knTX24doC0/', 'admin', 'marc.scarfone@nscc.ca', 'http://capstone.nscc.ca', '2014-02-13 19:12:17', 'hoI0eqrq6CoLesxJRlUQ', 0, 'admin') ; 
INSERT INTO `wp_users` VALUES (21, 'Keila Mak', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'keila-mak', 'W0218748@nscc.ca', '', '2014-02-21 14:59:02', '', 0, 'Keila Mak') ; 
INSERT INTO `wp_users` VALUES (3, 'test', '$P$B7g6fGA8vBBYHjAnGFvB06Otbec6N./', 'test', 'test@test.com', 'http://test@test.ca', '2014-02-14 15:20:46', '', 0, 'test test') ; 
INSERT INTO `wp_users` VALUES (26, 'Jonny', '$P$BPGXqDGZvarusLSEaJx8evKsNtrEKR0', 'jonny', 'jonnymaceachern@gmail.com', '', '2014-02-21 15:44:52', '', 0, 'Jonny') ; 
INSERT INTO `wp_users` VALUES (11, 'RFP - KNOX UNITED CHURCH', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'rfp-knox-united-church', 'minister@knoxsackville.ca', '', '2014-02-20 19:57:03', '', 0, 'RFP - KNOX UNITED CHURCH') ; 
INSERT INTO `wp_users` VALUES (6, 'Irving Shipyards', '$P$BmtqhQXiSfsbJ1kAwKMrH/z9gAqp/4/', 'irving-shipyards', 'Sloan.Erin@halifaxshipyard.com', '', '2014-02-20 19:32:40', '', 0, 'Irving Shipyards') ; 
INSERT INTO `wp_users` VALUES (7, 'Frontier Technologies', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'frontier-technologies', 'itm@kerrgroup.ca', '', '2014-02-20 19:37:54', '', 0, 'Frontier Technologies') ; 
INSERT INTO `wp_users` VALUES (10, 'RFP - City of the Dead Halifax and the Titanic Disaster', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'rfp-city-of-the-dead-halifax-and-the-titanic-disas', 'novajodik@eastlink.ca', '', '2014-02-20 19:54:28', '', 0, 'RFP - City of the Dead Halifax and the Titanic Disaster') ; 
INSERT INTO `wp_users` VALUES (12, 'Department of National Defenses', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'department-of-national-defenses', 'Diane.Dow@forces.gc.ca', '', '2014-02-20 20:05:27', '', 0, 'Department of National Defenses') ; 
INSERT INTO `wp_users` VALUES (13, 'Esterline', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'esterline', 'Anthony.johnstone@cmcelectronics.ca', '', '2014-02-20 20:21:33', '', 0, 'Esterline') ; 
INSERT INTO `wp_users` VALUES (14, 'Nicole Sawler', '$P$BHXpjEg0RwcJB3obYqfQlEVL88kDZX.', 'nicole-sawler', 'W0252620@nscc.ca', '', '2014-02-21 14:51:03', '', 0, 'student') ; 
INSERT INTO `wp_users` VALUES (15, 'Colin Sampson', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'colin-sampson', 'W0234389@nscc.ca', '', '2014-02-21 14:52:25', '', 0, 'Colin Sampson') ; 
INSERT INTO `wp_users` VALUES (16, 'Ryan Mahoney', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'ryan-mahoney', 'W0252629@nscc.ca', '', '2014-02-21 14:53:18', '', 0, 'Ryan Mahoney') ; 
INSERT INTO `wp_users` VALUES (17, 'Corey MacMullin', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'corey-macmullin', 'W0247424@nscc.ca', '', '2014-02-21 14:54:26', '', 0, 'Corey MacMullin') ; 
INSERT INTO `wp_users` VALUES (18, 'Ayoub Lawrence', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'ayoub-lawrence', 'W0224075@nscc.ca', '', '2014-02-21 14:55:48', '', 0, 'Ayoub Lawrence') ; 
INSERT INTO `wp_users` VALUES (19, 'Cameron Evans', '$P$Bd3WeM9uHyuybqAr./DQqOrBIxS.Uz/', 'cameron-evans', 'W0253840@nscc.ca', 'http://camevans.ca', '2014-02-21 14:56:56', 'ooom5ahfpT3KeP4OelxW', 0, 'Cameron Evans') ; 
INSERT INTO `wp_users` VALUES (20, 'Jonny MacEachern', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'jonny-maceachern', 'W0200331@nscc.ca', '', '2014-02-21 14:57:38', '', 0, 'Jonny MacEachern') ; 
INSERT INTO `wp_users` VALUES (22, 'Diana Turple', '$P$Bdh4vD9ghUH.nPaDF/8s1ioB3wq4Oj.', 'diana-turple', 'W0255925@nscc.ca', 'http://www.dianaturple.com', '2014-02-21 14:59:57', '', 0, 'Diana Turple') ; 
INSERT INTO `wp_users` VALUES (25, 'Titzn Glitz On The Front Line Society', 'c1d9154a79ca8fda7bd0cecddc25d17f', 'titzn-glitz-on-the-front-line-society', 'dummy@email.com', '', '2014-02-21 15:37:20', '', 0, 'Titzn Glitz On The Front Line Society') ; 
INSERT INTO `wp_users` VALUES (27, 'Test Company', '$P$BNmmH4TeRf1GwwBVFlvDXxCA05CSsi0', 'test-company', 'recruiter@company.com', '', '2014-02-28 13:56:25', '', 0, 'Test Company') ; 
INSERT INTO `wp_users` VALUES (28, 'test1', '$P$BZ0Husr95OV0XPQX9.RDqtGkISvJD50', 'test1', 'test@test.ca', '', '2014-02-28 14:45:29', '', 0, 'test1') ; 
INSERT INTO `wp_users` VALUES (29, 'test2', '$P$Bzk1YQ6jw0FwTYEyWEVvTl4fHG9ddD1', 'test2', 'test@testc.ca', '', '2014-02-28 14:46:47', '', 0, 'test2') ; 
INSERT INTO `wp_users` VALUES (30, 'test21', '$P$BSf4SvAC9xE9skVafIS/k4BnlxZxqY1', 'test21', 'test@nscc.ca', '', '2014-02-28 14:54:31', '', 0, 'test21') ; 
INSERT INTO `wp_users` VALUES (31, 'aaa', '$P$BHcmISJ3FTCkPllDrDniomsuu3jPCq/', 'aaa', 'aaa@aaa.com', '', '2014-02-28 14:57:04', '', 0, 'aaa') ; 
INSERT INTO `wp_users` VALUES (32, 'test3', '$P$BQe/YG8Wwfrmf9qwm70IYJoEOo8TPB1', 'test3', 'test@new.com', '', '2014-03-05 14:59:17', '', 0, 'test3') ; 
INSERT INTO `wp_users` VALUES (33, 'Bob Jones', '$P$BUxlder2wMulzX4QCGzICIpUnjv.jF/', 'bob-jones', 'bob@gmail.com', '', '2014-03-06 19:47:42', '', 0, 'Bob Jones') ; 
INSERT INTO `wp_users` VALUES (34, 'CompanyTest', '$P$BdMb1cM1nflAfkQzByniQGu1.8u5/41', 'companytest', 'company@test.ca', '', '2014-03-06 19:48:20', '', 0, 'CompanyTest') ; 
INSERT INTO `wp_users` VALUES (35, 'John Smith', '$P$BabP2zzA3Xrf3X/mgumS6jgq6LzWuP0', 'john-smith', 'test@gmail.com', '', '2014-03-20 02:56:53', '', 0, 'John Smith') ; 
INSERT INTO `wp_users` VALUES (36, 'Bob Jones1', '$P$B.L87MqelYK7A0cpa2hlq1n2kI/ACS0', 'bob-jones1', 'bobjones@gmail.com', 'http://helloworld.com', '2014-03-20 03:57:15', '', 0, 'Bob Jones1') ; 
INSERT INTO `wp_users` VALUES (37, 'Test Employer', '$P$BlW.3jjSFFs8e/KetpW/afwaqZofkE.', 'test-employer', 'testemployer@gmail.com', '', '2014-03-20 16:15:20', '', 0, 'Test Employer') ; 
INSERT INTO `wp_users` VALUES (38, 'nicole', '$P$B/x7HBM/J07FoNooujPpH1xqRds3dy0', 'nicole', 'nicolesawler@gmail.com', '', '2014-03-20 16:24:26', '', 0, 'nicole') ; 
INSERT INTO `wp_users` VALUES (39, 'Test Company 3', '$P$BaEWkirzFV7bwkXTEstMpl/YvFXkGF/', 'test-company-3', 'testcompany3@gmail.com', '', '2014-03-20 16:30:42', '', 0, 'Test Company 3') ; 
INSERT INTO `wp_users` VALUES (40, 'Test Employee', '$P$Baybo.D34eqXMFY5D0/0.Bh9htpxHM.', 'test-employee', 'testemployee@gmail.com', '', '2014-03-20 16:31:38', '', 0, 'Test Employee') ; 
INSERT INTO `wp_users` VALUES (41, 'nicole1', '$P$B11DYKCQpZYJuR87mthYltN9xDCe../', 'nicole1', 'blah@blah.com', '', '2014-04-03 17:22:40', '', 0, 'nicole1') ; 
INSERT INTO `wp_users` VALUES (42, 'candidate', '$P$B4gRAfmckGL.Lv7PrOQofbx6rqcQYc/', 'candidate', 'candidate@test.com', '', '2014-04-09 21:12:57', '', 0, 'candidate') ; 
INSERT INTO `wp_users` VALUES (43, 'Acme Design Co.', '$P$B.iLPWaQ67veJuHxltKRoiWGbk0XwP/', 'acme-design-co', 'acmedesignco@acme.com', '', '2014-04-11 14:28:08', '', 0, 'Acme Design Co.') ; 
INSERT INTO `wp_users` VALUES (44, 'John Smith1', '$P$B9oWU1uay6sRURsmnOcOmbjYQscZCD.', 'john-smith1', 'johnsmith@fakeemail.com', '', '2014-04-11 14:41:41', '', 0, 'John Smith1') ; 
INSERT INTO `wp_users` VALUES (45, 'Generic Company', '$P$BUsBXfnQHp4K7OFyj6cXoUw96vU76x0', 'generic-company', 'gencomp@gen.com', '', '2014-04-11 14:46:21', '', 0, 'Generic Company') ; 
INSERT INTO `wp_users` VALUES (46, 'company', '$P$BhoV15PUTSoKsIUbPWP0ycE5YXywJV0', 'company', 'company@company.com', '', '2014-04-11 15:15:09', '', 0, 'company') ; 
INSERT INTO `wp_users` VALUES (50, 'Anthony Scarfone', '$P$ByXV3Z.GZE.OBAlNfmQfMK0ne0ihXH0', 'anthony-scarfone', 'scarfone.marc@gmail.com', '', '2014-05-14 18:28:48', '', 0, 'Anthony Scarfone') ; 
INSERT INTO `wp_users` VALUES (48, 'This Test', '$P$BYDnJJAgWNBIdGPJYxZYfrHtm0.T6N.', 'this-test', 'lawrence.lelo@gmail.com', '', '2014-04-17 19:38:28', '', 0, 'This Test') ; 
INSERT INTO `wp_users` VALUES (49, 'This Test1', '$P$B/4EC/6cZ5AiGbD.0Mcj1ZYTCppZsU/', 'this-test1', 'lawrence.saiyan@hotmail.com', '', '2014-04-17 19:40:34', '', 0, 'This Test1') ; 
INSERT INTO `wp_users` VALUES (52, 'student', '$P$BMQQJaWKYjfIK1X5c0/DVAwuk/qe.d0', 'student', 'marc.scarfone@yahoo.ca', '', '2014-05-14 19:27:47', '', 0, 'student') ; 
INSERT INTO `wp_users` VALUES (53, 'jbaikie', '$P$BZ8LhmDN34FilH9i8qOaVMpid6WgIw0', 'jbaikie', '', '', '2014-08-11 17:32:45', '', 0, 'jbaikie') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

